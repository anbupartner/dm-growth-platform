import { Document, Page, Text, View, StyleSheet, Svg, Circle, Path } from "@react-pdf/renderer";
import type { ProposalData } from "./proposal-types";
import { formatCurrency, formatNumber } from "@/lib/calculations";

const COLORS = {
  ink: "#111827",
  sub: "#4b5563",
  faint: "#9ca3af",
  brand: "#4f46e5",
  brandSoft: "#eef2ff",
  line: "#e5e7eb",
  good: "#059669",
  goodSoft: "#ecfdf5",
  slateSoft: "#f1f5f9",
};

const s = StyleSheet.create({
  page: { padding: 40, fontSize: 10, color: COLORS.ink, fontFamily: "Helvetica" },
  headerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 16 },
  brandTitle: { fontSize: 10, color: COLORS.brand, fontFamily: "Helvetica-Bold" },
  pageTitle: { fontSize: 20, fontFamily: "Helvetica-Bold", marginBottom: 4 },
  pageSubtitle: { fontSize: 10, color: COLORS.sub, marginBottom: 16 },
  sectionLabel: { fontSize: 12, fontFamily: "Helvetica-Bold", marginTop: 16, marginBottom: 8, color: COLORS.brand },
  bodyText: { fontSize: 10, color: COLORS.ink, lineHeight: 1.5 },
  calloutCard: { borderRadius: 6, padding: 10, marginBottom: 8 },
  calloutLabel: { fontSize: 9, fontFamily: "Helvetica-Bold", marginBottom: 3 },
  footer: { position: "absolute", bottom: 24, left: 40, right: 40, fontSize: 8, color: COLORS.faint, flexDirection: "row", justifyContent: "space-between" },
  packagesRow: { flexDirection: "row" },
  packageCard: { flex: 1, borderWidth: 1, borderColor: COLORS.line, borderRadius: 10, marginRight: 10, overflow: "hidden" },
  packageCardLast: { marginRight: 0 },
  packageCardRecommended: { borderColor: COLORS.brand, borderWidth: 2 },
  packageRibbon: { backgroundColor: COLORS.brand, paddingVertical: 3, alignItems: "center" },
  packageRibbonText: { fontSize: 7.5, fontFamily: "Helvetica-Bold", color: "#fff" },
  packageHead: { padding: 12, borderBottomWidth: 1, borderBottomColor: COLORS.line },
  packageLabel: { fontSize: 12, fontFamily: "Helvetica-Bold", marginBottom: 6 },
  packagePrice: { fontSize: 20, fontFamily: "Helvetica-Bold", color: COLORS.brand },
  packagePriceSub: { fontSize: 7, color: COLORS.sub, marginTop: 1 },
  packageBody: { padding: 12 },
  packageDesc: { fontSize: 8.5, color: COLORS.sub, lineHeight: 1.4, marginBottom: 8 },
  statRow: { flexDirection: "row", flexWrap: "wrap" },
  statItem: { width: "50%", marginBottom: 8 },
  statLabel: { fontSize: 6.5, color: COLORS.sub },
  statValue: { fontSize: 10.5, fontFamily: "Helvetica-Bold" },
  termsBlock: { borderWidth: 1, borderColor: COLORS.line, borderRadius: 8, padding: 14, marginBottom: 16 },
  termsText: { fontSize: 9.5, lineHeight: 1.6, color: COLORS.ink },
  acceptRow: { flexDirection: "row", marginTop: 30 },
  acceptCol: { flex: 1, marginRight: 20 },
  acceptColLast: { marginRight: 0 },
  acceptLine: { borderBottomWidth: 1, borderBottomColor: COLORS.ink, height: 30 },
  acceptLabel: { fontSize: 8, color: COLORS.sub, marginTop: 4 },
});

// Small check-mark badge, drawn as an SVG path rather than a Unicode glyph —
// react-pdf's built-in Helvetica font is WinAnsi/CP1252-only, so a text "✓"
// character silently renders as a garbled glyph (the same bug class fixed
// throughout ReportDocument.tsx — see its comments for the full history).
function CheckBadge({ color = COLORS.brand, size = 16 }: { color?: string; size?: number }) {
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: color, alignItems: "center", justifyContent: "center" }}>
      <Svg width={size * 0.6} height={size * 0.6} viewBox="0 0 24 24">
        <Path d="M4 12 L10 18 L20 6" stroke="#fff" strokeWidth={3.5} fill="none" strokeLinecap="round" strokeLinejoin="round" />
      </Svg>
    </View>
  );
}

function Header({ consultant }: { consultant: ProposalData["consultant"] }) {
  return (
    <View style={s.headerRow} fixed>
      <Text style={s.brandTitle}>{consultant.companyName}</Text>
      <Text style={{ fontSize: 8, color: COLORS.faint }}>{consultant.consultantName}</Text>
    </View>
  );
}

function Footer({ page, total, consultant }: { page: number; total: number; consultant: ProposalData["consultant"] }) {
  return (
    <View style={s.footer} fixed>
      <Text>
        {consultant.companyName} · {consultant.website ?? consultant.email ?? ""}
      </Text>
      <Text>Page {page} of {total}</Text>
    </View>
  );
}

export function ProposalDocument({ data }: { data: ProposalData }) {
  const { consultant, business, summary, packages, termsText, validUntil, generatedDate, version } = data;
  const totalPages = 2;

  return (
    <Document title={`${business.businessName} — Growth Proposal v${version}`} author={consultant.companyName}>
      {/* PAGE 1 — THE OFFER */}
      <Page size="A4" style={s.page}>
        <Header consultant={consultant} />
        <Text style={s.pageTitle}>Growth Proposal</Text>
        <Text style={s.pageSubtitle}>
          Prepared for {business.customerName} · {business.businessName} · {generatedDate}
          {validUntil ? ` · Valid until ${validUntil}` : ""}
        </Text>

        <View style={[s.calloutCard, { backgroundColor: COLORS.goodSoft }]}>
          <Text style={[s.calloutLabel, { color: COLORS.good }]}>The Opportunity</Text>
          <Text style={s.bodyText}>{summary.opportunity}</Text>
        </View>

        <View style={[s.calloutCard, { backgroundColor: COLORS.brandSoft }]}>
          <Text style={[s.calloutLabel, { color: COLORS.brand }]}>Our Approach</Text>
          <Text style={s.bodyText}>{summary.approach}</Text>
        </View>

        <Text style={s.sectionLabel}>Choose Your Plan</Text>
        <View style={s.packagesRow}>
          {packages.map((pkg, i) => (
            <View
              key={pkg.key || i}
              style={[
                s.packageCard,
                i === packages.length - 1 ? s.packageCardLast : undefined,
                pkg.recommended ? s.packageCardRecommended : undefined,
              ]}
            >
              {pkg.recommended ? (
                <View style={s.packageRibbon}>
                  <Text style={s.packageRibbonText}>RECOMMENDED</Text>
                </View>
              ) : null}
              <View style={s.packageHead}>
                <Text style={s.packageLabel}>{pkg.label}</Text>
                <Text style={s.packagePrice}>{formatCurrency(pkg.price, pkg.currency)}</Text>
                <Text style={s.packagePriceSub}>per month</Text>
              </View>
              <View style={s.packageBody}>
                {pkg.description ? <Text style={s.packageDesc}>{pkg.description}</Text> : null}
                {pkg.customers != null || pkg.revenue != null || pkg.roi != null ? (
                  <View style={s.statRow}>
                    {pkg.customers != null ? (
                      <View style={s.statItem}>
                        <Text style={s.statLabel}>Est. Customers/mo</Text>
                        <Text style={s.statValue}>{formatNumber(Math.round(pkg.customers))}</Text>
                      </View>
                    ) : null}
                    {pkg.revenue != null ? (
                      <View style={s.statItem}>
                        <Text style={s.statLabel}>Est. Revenue/mo</Text>
                        <Text style={s.statValue}>{formatCurrency(Math.round(pkg.revenue), pkg.currency)}</Text>
                      </View>
                    ) : null}
                    {pkg.roi != null ? (
                      <View style={s.statItem}>
                        <Text style={s.statLabel}>Est. ROI</Text>
                        <Text style={s.statValue}>{Math.round(pkg.roi)}%</Text>
                      </View>
                    ) : null}
                  </View>
                ) : null}
              </View>
            </View>
          ))}
        </View>

        <Text style={{ fontSize: 7.5, color: COLORS.faint, marginTop: 10 }}>
          Estimates shown are scenario-based projections carried over from the growth report — see the full report for assumptions and methodology.
        </Text>

        <Footer page={1} total={totalPages} consultant={consultant} />
      </Page>

      {/* PAGE 2 — TERMS & ACCEPTANCE */}
      <Page size="A4" style={s.page}>
        <Header consultant={consultant} />
        <Text style={s.pageTitle}>Terms &amp; Next Steps</Text>
        <Text style={s.pageSubtitle}>{business.businessName}{validUntil ? ` · Proposal valid until ${validUntil}` : ""}</Text>

        <View style={s.termsBlock}>
          <Text style={s.termsText}>{termsText}</Text>
        </View>

        <View style={{ flexDirection: "row", marginBottom: 4 }}>
          <CheckBadge />
          <Text style={{ marginLeft: 8, fontSize: 9.5, color: COLORS.ink, flex: 1 }}>
            Pick a plan above and confirm by reply, call, or WhatsApp — work begins within 2 business days of confirmation.
          </Text>
        </View>

        <View style={s.acceptRow}>
          <View style={s.acceptCol}>
            <View style={s.acceptLine} />
            <Text style={s.acceptLabel}>Client signature</Text>
          </View>
          <View style={[s.acceptCol, s.acceptColLast]}>
            <View style={s.acceptLine} />
            <Text style={s.acceptLabel}>Date</Text>
          </View>
        </View>

        <View style={{ marginTop: 40, alignItems: "center" }}>
          <Text style={{ fontSize: 14, fontFamily: "Helvetica-Bold", textAlign: "center", marginBottom: 12 }}>
            {consultant.ctaText}
          </Text>
          <Text style={{ fontSize: 10, fontFamily: "Helvetica-Bold" }}>{consultant.consultantName}</Text>
          <Text style={{ fontSize: 9, color: COLORS.sub }}>{consultant.companyName}</Text>
          {consultant.phone ? <Text style={{ fontSize: 9, color: COLORS.sub }}>{consultant.phone}</Text> : null}
          {consultant.whatsapp ? <Text style={{ fontSize: 9, color: COLORS.sub }}>WhatsApp: {consultant.whatsapp}</Text> : null}
          {consultant.email ? <Text style={{ fontSize: 9, color: COLORS.sub }}>{consultant.email}</Text> : null}
          {consultant.website ? <Text style={{ fontSize: 9, color: COLORS.sub }}>{consultant.website}</Text> : null}
        </View>

        <Footer page={2} total={totalPages} consultant={consultant} />
      </Page>
    </Document>
  );
}
