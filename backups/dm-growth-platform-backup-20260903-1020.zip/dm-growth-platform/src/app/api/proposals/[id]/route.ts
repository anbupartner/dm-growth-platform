import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { proposals } from "@/lib/db/schema";
import { eq } from "drizzle-orm";

export async function GET(_req: NextRequest, ctx: RouteContext<"/api/proposals/[id]">) {
  const { id } = await ctx.params;
  const row = await db.query.proposals.findFirst({ where: eq(proposals.id, id) });
  if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json(row);
}
