# Restore point — dm-growth-platform-backup-20260903-1019

This zip is a full, self-contained snapshot of the Growth Platform app — source code, config, and live data — taken on **2026-09-03 10:19 UTC**. Use it to roll the whole project back to exactly this state if something goes wrong later.

## What's inside

- All app source code (`src/`), scripts, and config (`package.json`, `tsconfig.json`, `next.config.ts`, etc.)
- `.env` (your local environment settings) and `.env.example`
- `data/app.db`, `data/app.db-shm`, `data/app.db-wal` — the live SQLite database: every lead, assessment, proposal, and report you've entered
- `data/benchmarks/*.json` — the seeded ad-platform benchmark data (Google Ads, Meta, Instagram, LinkedIn, Microsoft Ads, WhatsApp, YouTube)
- `data/reports/*.pdf` and `data/proposals/*.pdf` — every generated report and proposal PDF that existed at backup time

Not included (regenerated automatically, no need to back up): `node_modules/`, `.next/`.

## How to restore

1. Close the app if it's running (stop `npm run dev` / `npm start`).
2. Rename or move your current `dm-growth-platform` folder aside (e.g. to `dm-growth-platform-old`) so you don't lose anything by accident.
3. Unzip this backup — it extracts as a `dm-growth-platform/` folder. Place it where your project normally lives (e.g. `E:\My Project\Dm Project\`).
4. Open a terminal in the restored folder and run:
   ```
   npm install
   npm run dev
   ```
   (`npm install` rebuilds `node_modules` from `package-lock.json`, so the exact same dependency versions come back.)
5. Your data, leads, reports, and settings will be exactly as they were at backup time — nothing from after 2026-09-03 10:19 UTC will be present, since this is a point-in-time snapshot.

## Notes

- This backup contains your `.env` file, which may hold local settings — keep this zip somewhere private, the same as you would the live project.
- Previous backups are kept alongside this one in the `backups/` folder for older restore points.
