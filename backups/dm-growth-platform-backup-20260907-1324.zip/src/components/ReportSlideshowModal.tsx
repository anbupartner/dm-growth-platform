"use client";

import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { api } from "@/lib/api-client";
import { buildPitchSlides, formatCurrency, formatNumber, formatPercent, type PitchSlide } from "@/lib/pitch-slides";
import { buildPitchPptx } from "@/lib/build-pitch-pptx";
import type { ReportData } from "@/lib/pdf/types";
import { Spinner } from "@/components/ui";
import {
  ChevronLeft,
  ChevronRight,
  Maximize,
  Minimize,
  Download,
  Loader2,
  X,
  AlertTriangle,
  Target,
  TrendingUp,
  Search,
  MessageCircle,
  Share2,
  PlayCircle,
  Megaphone,
  Users,
  Phone,
  Mail,
  Globe,
  Image as ImageIcon,
  Quote,
  MapPin,
  UserCheck,
  Activity,
  Sparkles,
  DollarSign,
  Compass,
  Layers,
  Gauge,
  type LucideIcon,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  Legend,
} from "recharts";

interface ReportSnapshotRow {
  id: string;
  pdfFileName?: string | null;
  reportData?: string | null;
}

// The app's existing chart accent colors (see the Dashboard's own charts in
// src/app/page.tsx) — reused here so the slideshow's charts match the rest
// of the app instead of introducing a new palette.
const INDIGO = "#4f46e5";
const CYAN = "#06b6d4";
const BLUE = "#2563eb";

// Every slide is designed against this fixed reference canvas (matches the
// popup's normal, non-fullscreen size: max-w-5xl = 1024px at a 16:9 ratio)
// and then scaled as a whole via CSS transform to exactly fill however big
// the actual slide surface turns out to be — see the "Slide surface" render
// below. This is the same "design at one resolution, scale to fit" approach
// real slide viewers (Google Slides, PowerPoint Online) use, and it's what
// makes fullscreen actually fill the screen: without it, every slide's
// text/chart/icon sizes are fixed pixel values tuned for this 1024x576
// canvas, so a much bigger fullscreen box left them pinned at their normal
// size with dead space around them instead of growing to fill it.
const SLIDE_CANVAS_WIDTH = 1024;
const SLIDE_CANVAS_HEIGHT = 576;

// Every slide "topic" (Situation, Opportunity, Audience, ...) gets its own
// consistent accent color, used for that slide's eyebrow, icon badges, and
// small decorative touches (the top color bar, card icons) — the same
// structural pattern repeats on every slide (eyebrow -> heading -> content),
// only the hue changes with the topic, so the deck reads as colorful *and*
// uniform rather than randomly colored or uniformly monochrome.
const ACCENTS: Record<
  PitchSlide["type"],
  { bar: string; text: string; iconBg: string; iconText: string }
> = {
  title: { bar: "bg-indigo-500", text: "text-indigo-500", iconBg: "bg-indigo-50 dark:bg-indigo-500/10", iconText: "text-indigo-500" },
  situation: { bar: "bg-rose-500", text: "text-rose-500", iconBg: "bg-rose-50 dark:bg-rose-500/10", iconText: "text-rose-500" },
  opportunity: { bar: "bg-indigo-500", text: "text-indigo-500", iconBg: "bg-indigo-50 dark:bg-indigo-500/10", iconText: "text-indigo-500" },
  auditScores: { bar: "bg-blue-500", text: "text-blue-500", iconBg: "bg-blue-50 dark:bg-blue-500/10", iconText: "text-blue-500" },
  audienceProfile: { bar: "bg-violet-500", text: "text-violet-500", iconBg: "bg-violet-50 dark:bg-violet-500/10", iconText: "text-violet-500" },
  platforms: { bar: "bg-cyan-500", text: "text-cyan-600", iconBg: "bg-cyan-50 dark:bg-cyan-500/10", iconText: "text-cyan-600" },
  plan: { bar: "bg-emerald-500", text: "text-emerald-600", iconBg: "bg-emerald-50 dark:bg-emerald-500/10", iconText: "text-emerald-600" },
  sampleAds: { bar: "bg-amber-500", text: "text-amber-600", iconBg: "bg-amber-50 dark:bg-amber-500/10", iconText: "text-amber-600" },
  forecast: { bar: "bg-teal-500", text: "text-teal-600", iconBg: "bg-teal-50 dark:bg-teal-500/10", iconText: "text-teal-600" },
  cta: { bar: "bg-indigo-500", text: "text-indigo-500", iconBg: "bg-indigo-50 dark:bg-indigo-500/10", iconText: "text-indigo-500" },
};

// A visual, client-facing slideshow view of a report — meant to be popped
// open in front of a client and presented slide by slide, rather than
// reading the dense PDF together. Pulls its content from the same
// ReportData the PDF was generated from (see reportSnapshots.reportData);
// older report versions saved before that field existed don't have it, so
// this shows a plain explanation instead of a broken/empty deck.
export function ReportSlideshowModal({ reportId, onClose }: { reportId: string; onClose: () => void }) {
  const [row, setRow] = useState<ReportSnapshotRow | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [index, setIndex] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [exporting, setExporting] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const surfaceRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);

  // Recomputes the scale factor that fits the fixed SLIDE_CANVAS_WIDTH x
  // SLIDE_CANVAS_HEIGHT canvas into whatever size the slide surface actually
  // renders at — on every resize and, critically, every fullscreen toggle
  // (a ResizeObserver on the surface itself, not just a window resize
  // listener, so it also fires purely from the fullscreen layout change).
  useLayoutEffect(() => {
    const el = surfaceRef.current;
    if (!el) return;
    const measure = () => {
      const { width, height } = el.getBoundingClientRect();
      if (width > 0 && height > 0) {
        setScale(Math.min(width / SLIDE_CANVAS_WIDTH, height / SLIDE_CANVAS_HEIGHT));
      }
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    let cancelled = false;
    api
      .get<ReportSnapshotRow>(`/api/reports/${reportId}`)
      .then((r) => {
        if (!cancelled) setRow(r);
      })
      .catch((e) => {
        if (!cancelled) setLoadError((e as Error).message);
      });
    return () => {
      cancelled = true;
    };
  }, [reportId]);

  const reportData = useMemo<ReportData | null>(() => {
    if (!row?.reportData) return null;
    try {
      return JSON.parse(row.reportData) as ReportData;
    } catch {
      return null;
    }
  }, [row]);

  const slides = useMemo<PitchSlide[]>(() => (reportData ? buildPitchSlides(reportData) : []), [reportData]);

  const goNext = () => setIndex((i) => Math.min(i + 1, slides.length - 1));
  const goPrev = () => setIndex((i) => Math.max(i - 1, 0));

  // Keyboard navigation — arrows move slides, Escape closes the popup (when
  // not fullscreen; in fullscreen the browser's own Escape exits fullscreen
  // first, and the fullscreenchange listener below picks that up).
  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === "ArrowRight") goNext();
      else if (e.key === "ArrowLeft") goPrev();
      else if (e.key === "Escape" && !document.fullscreenElement) onClose();
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [slides.length, onClose]);

  useEffect(() => {
    function onFsChange() {
      setIsFullscreen(document.fullscreenElement === containerRef.current);
    }
    document.addEventListener("fullscreenchange", onFsChange);
    return () => document.removeEventListener("fullscreenchange", onFsChange);
  }, []);

  async function toggleFullscreen() {
    if (!containerRef.current) return;
    if (document.fullscreenElement) {
      await document.exitFullscreen();
    } else {
      await containerRef.current.requestFullscreen();
    }
  }

  // The Download button exports this same slide deck as a real .pptx —
  // not the audit PDF (that's still available from the report row's own
  // Download button outside this popup) — so it needs actual slide content
  // to export from.
  async function handleDownloadPptx() {
    if (slides.length === 0 || exporting) return;
    setExporting(true);
    try {
      const base = (row?.pdfFileName ?? "presentation").replace(/\.pdf$/i, "");
      await buildPitchPptx(slides, `${base}-presentation.pptx`);
    } finally {
      setExporting(false);
    }
  }

  const slide = slides[index];
  const accent = slide ? ACCENTS[slide.type] : ACCENTS.title;

  // requestFullscreen() is called on containerRef — the browser's own
  // fullscreen UA styles force that element to position:fixed;inset:0
  // (filling the whole screen) regardless of our own width classes, which
  // is what previously left the card pinned flush to the left edge with
  // empty space on the right (its max-width capped the box below 100% of
  // the screen, but the UA-forced inset:0 had no auto margins to center the
  // leftover space with). Making containerRef itself just a flex-centering
  // wrapper — full screen, centered content — and moving the actual card
  // (the white rounded box with its own max-width) into a child div sidesteps
  // this entirely: centering that child is ordinary in-flow flexbox layout,
  // untouched by the fullscreen UA rules, so it centers correctly in both
  // fullscreen and normal display.
  return (
    <div
      ref={containerRef}
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-8 ${
        isFullscreen ? "bg-slate-900" : "bg-slate-900/70"
      }`}
    >
      <div
        className={`relative flex w-full flex-col overflow-hidden rounded-xl bg-white shadow-2xl dark:bg-slate-900 ${
          // Fullscreen: fill the actual available height (not just cap it)
          // and drop the width cap entirely, so the card — and with it, the
          // slide surface below — genuinely fills the screen instead of
          // leaving the fixed max-w-[1600px] box with dead space to its
          // right on wider monitors. Normal popup: unchanged from before.
          isFullscreen ? "h-full" : "max-w-5xl"
        }`}
      >
        {/* Top color bar — the topic accent, repeated on every slide so the
            deck reads as one colorful, consistently-themed system rather
            than flat/monochrome. */}
        <div className={`h-1.5 w-full shrink-0 ${accent.bar}`} />

        {/* Top bar */}
        <div className="flex items-center justify-between gap-3 border-b border-slate-100 px-4 py-2.5 dark:border-slate-800">
          <p className="truncate text-xs font-medium text-slate-500 dark:text-slate-400">
            {row?.pdfFileName ?? "Report presentation"}
          </p>
          <div className="flex items-center gap-1.5 shrink-0">
            {slides.length > 0 && (
              <span className="mr-1.5 text-xs tabular-nums text-slate-400">
                {index + 1} / {slides.length}
              </span>
            )}
            <button
              type="button"
              onClick={toggleFullscreen}
              title={isFullscreen ? "Exit full screen" : "Full screen"}
              className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
            >
              {isFullscreen ? <Minimize size={15} /> : <Maximize size={15} />}
            </button>
            <button
              type="button"
              onClick={handleDownloadPptx}
              disabled={slides.length === 0 || exporting}
              title={slides.length === 0 ? "No slides to export yet" : "Download presentation (.pptx)"}
              className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100 disabled:opacity-40 disabled:pointer-events-none dark:text-slate-400 dark:hover:bg-slate-800"
            >
              {exporting ? <Loader2 size={15} className="animate-spin" /> : <Download size={15} />}
            </button>
            <button
              type="button"
              onClick={onClose}
              title="Close"
              className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
            >
              <X size={15} />
            </button>
          </div>
        </div>

        {/* Slide surface — the reference canvas below is scaled to fill
            whichever of these two modes is active: a fixed 16:9 box at
            normal popup size (aspect-video, matching SLIDE_CANVAS's own
            ratio so scale computes to ~1 there — i.e. no visual change from
            before), or the full available height in fullscreen (flex-1,
            filling the now h-full card) so the canvas scales UP to match
            instead of staying pinned at its normal size with empty space
            around it. */}
        <div
          ref={surfaceRef}
          className={`relative flex w-full items-center justify-center overflow-hidden bg-white dark:bg-slate-900 ${
            isFullscreen ? "min-h-0 flex-1" : "aspect-video"
          }`}
        >
          <div className="relative shrink-0" style={{ width: SLIDE_CANVAS_WIDTH * scale, height: SLIDE_CANVAS_HEIGHT * scale }}>
            <div
              className="absolute left-0 top-0 origin-top-left overflow-y-auto"
              style={{ width: SLIDE_CANVAS_WIDTH, height: SLIDE_CANVAS_HEIGHT, transform: `scale(${scale})` }}
            >
              {!row && !loadError && (
                <div className="flex h-full items-center justify-center">
                  <Spinner />
                </div>
              )}
              {loadError && (
                <div className="flex h-full flex-col items-center justify-center gap-1 px-8 text-center">
                  <p className="text-sm font-medium text-slate-700 dark:text-slate-200">Couldn't load this report</p>
                  <p className="text-xs text-slate-400">{loadError}</p>
                </div>
              )}
              {row && !loadError && !reportData && (
                <div className="flex h-full flex-col items-center justify-center gap-1 px-8 text-center">
                  <p className="text-sm font-medium text-slate-700 dark:text-slate-200">
                    Presentation view isn't available for this report version
                  </p>
                  <p className="max-w-sm text-xs text-slate-400">
                    This version was generated before slide data was saved with reports. Close this and use the
                    Download button on the report list for the PDF instead, or regenerate the report to get a
                    version you can present from.
                  </p>
                </div>
              )}
              {slide && <SlideView slide={slide} />}
            </div>
          </div>

          {slides.length > 1 && (
            <>
              <button
                type="button"
                onClick={goPrev}
                disabled={index === 0}
                aria-label="Previous slide"
                className="absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-white/90 p-2 text-slate-600 shadow disabled:opacity-30 dark:bg-slate-800/90 dark:text-slate-300"
              >
                <ChevronLeft size={18} />
              </button>
              <button
                type="button"
                onClick={goNext}
                disabled={index === slides.length - 1}
                aria-label="Next slide"
                className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-white/90 p-2 text-slate-600 shadow disabled:opacity-30 dark:bg-slate-800/90 dark:text-slate-300"
              >
                <ChevronRight size={18} />
              </button>
            </>
          )}
        </div>

        {/* Slide dots */}
        {slides.length > 1 && (
          <div className="flex items-center justify-center gap-1.5 border-t border-slate-100 py-2.5 dark:border-slate-800">
            {slides.map((_, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setIndex(i)}
                aria-label={`Go to slide ${i + 1}`}
                className={`h-1.5 rounded-full transition-all ${
                  i === index ? "w-5 bg-indigo-600" : "w-1.5 bg-slate-300 dark:bg-slate-700"
                }`}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function SlideView({ slide }: { slide: PitchSlide }) {
  switch (slide.type) {
    case "title":
      return (
        <SlideFrame>
          <SlideEyebrow icon={Sparkles} color={ACCENTS.title.text}>
            Digital Growth Audit &amp; Strategy
          </SlideEyebrow>
          <h1 className="mt-4 max-w-2xl text-4xl font-bold text-slate-900 dark:text-white sm:text-5xl">
            {slide.businessName}
          </h1>
          <p className="mt-4 text-sm text-slate-400">
            Prepared for {slide.customerName} · {slide.generatedDate}
          </p>
          {slide.companyName && <p className="mt-1 text-xs text-slate-300 dark:text-slate-600">{slide.companyName}</p>}
        </SlideFrame>
      );

    case "situation":
      return (
        <SlideFrame align="left">
          <SlideEyebrow icon={AlertTriangle} color={ACCENTS.situation.text}>
            Issues already affecting your business — easy to miss until now
          </SlideEyebrow>
          <SlideHeading>Where You Stand Today</SlideHeading>
          {slide.currentSituation && (
            <p className="mt-3 max-w-2xl text-sm text-slate-600 dark:text-slate-300">{slide.currentSituation}</p>
          )}
          {slide.problems.length > 0 && (
            <div className="mt-4 grid w-full max-w-3xl grid-cols-1 gap-2.5 sm:grid-cols-2">
              {slide.problems.map((p, i) => (
                <div
                  key={i}
                  className="rounded-lg border border-rose-100 bg-rose-50/60 px-3.5 py-2.5 dark:border-rose-900/40 dark:bg-rose-950/20"
                >
                  <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wide text-rose-500">
                    <AlertTriangle size={11} /> Issue {i + 1}
                  </span>
                  <p className="mt-1 text-sm text-slate-700 dark:text-slate-200">{p}</p>
                </div>
              ))}
            </div>
          )}
        </SlideFrame>
      );

    case "opportunity":
      return (
        <SlideFrame align="left">
          <SlideEyebrow icon={Target} color={ACCENTS.opportunity.text}>
            The Big Opportunity
          </SlideEyebrow>
          {/* A short opportunity statement reads well huge and bold; a long
              one (some reports write a full paragraph here) would overflow
              at that size, so the heading scales down with length instead
              of being truncated — the full real text always shows. */}
          <h2 className={`mt-2 max-w-2xl font-bold leading-snug text-slate-900 dark:text-white ${headlineSize(slide.biggestOpportunity)}`}>
            {slide.biggestOpportunity}
          </h2>
          {slide.directionSections ? (
            <div className="mt-5 w-full max-w-2xl space-y-3">
              {slide.directionIntro && (
                <p className="text-sm text-slate-500 dark:text-slate-400">{slide.directionIntro}</p>
              )}
              {slide.directionSections.map((s, i) => (
                <LabeledSection
                  key={i}
                  label={s.label}
                  text={s.text}
                  iconBg={ACCENTS.opportunity.iconBg}
                  iconText={ACCENTS.opportunity.iconText}
                  labelText={ACCENTS.opportunity.text}
                />
              ))}
            </div>
          ) : (
            slide.recommendedDirection && (
              <p className="mt-4 max-w-2xl text-base text-slate-500 dark:text-slate-400">{slide.recommendedDirection}</p>
            )
          )}
        </SlideFrame>
      );

    case "auditScores":
      return (
        <SlideFrame align="left">
          <SlideEyebrow icon={Gauge} color={ACCENTS.auditScores.text}>Website Health Check</SlideEyebrow>
          <SlideHeading>Where Your Website Stands</SlideHeading>
          <div className="mt-5 flex w-full max-w-4xl flex-col items-center gap-6 sm:flex-row sm:items-stretch">
            <div className="flex shrink-0 flex-col items-center justify-center gap-2">
              <ScoreRing value={slide.overall} />
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Overall Audit Score</p>
            </div>
            <div className="h-56 w-full flex-1">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={slide.scores} layout="vertical" margin={{ left: 8, right: 24, top: 4, bottom: 4 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
                  <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 10 }} />
                  <YAxis type="category" dataKey="label" width={110} tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Bar dataKey="value" fill={BLUE} radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </SlideFrame>
      );

    case "audienceProfile":
      return (
        <SlideFrame align="left">
          <SlideEyebrow icon={Users} color={ACCENTS.audienceProfile.text}>
            Who We&apos;ll Target
          </SlideEyebrow>
          <h2 className="mt-2 text-2xl font-bold text-slate-900 dark:text-white sm:text-3xl">Your Ideal Customer</h2>
          {slide.audienceSections ? (
            <div className="mt-5 w-full max-w-2xl space-y-3">
              {slide.audienceIntro && (
                <p className="text-sm text-slate-500 dark:text-slate-400">{slide.audienceIntro}</p>
              )}
              <div className="grid grid-cols-1 gap-x-6 gap-y-3.5 sm:grid-cols-2">
                {slide.audienceSections.map((s, i) => (
                  <LabeledSection
                    key={i}
                    label={s.label}
                    text={s.text}
                    iconBg={ACCENTS.audienceProfile.iconBg}
                    iconText={ACCENTS.audienceProfile.iconText}
                    labelText={ACCENTS.audienceProfile.text}
                  />
                ))}
              </div>
            </div>
          ) : (
            slide.targetAudience && (
              <div className="mt-4 w-full max-w-2xl">
                <LabeledSection
                  label="Target Audience"
                  text={slide.targetAudience}
                  iconBg={ACCENTS.audienceProfile.iconBg}
                  iconText={ACCENTS.audienceProfile.iconText}
                  labelText={ACCENTS.audienceProfile.text}
                />
              </div>
            )
          )}
        </SlideFrame>
      );

    case "platforms":
      return (
        <SlideFrame align="left">
          <SlideEyebrow icon={Megaphone} color={ACCENTS.platforms.text}>Media Plan</SlideEyebrow>
          <SlideHeading>Where We&apos;ll Reach Them</SlideHeading>
          <div className="mt-5 grid w-full max-w-4xl grid-cols-1 gap-3 sm:grid-cols-2">
            {slide.platforms.map((p, i) => {
              const { Icon, color } = platformVisual(p.platform);
              return (
                <div
                  key={i}
                  className="flex items-start gap-3 rounded-lg border border-slate-100 px-3.5 py-3 dark:border-slate-800"
                >
                  <span
                    className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full"
                    style={{ backgroundColor: `${color}1a` }}
                  >
                    <Icon size={16} style={{ color }} />
                  </span>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">
                      {p.platform}
                      {p.budgetAllocation && (
                        <span className="ml-2 text-xs font-normal text-slate-400">{p.budgetAllocation}</span>
                      )}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{p.adType}</p>
                    {p.expectedResult && (
                      <p className="mt-0.5 text-xs text-slate-400 dark:text-slate-500">{p.expectedResult}</p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </SlideFrame>
      );

    case "plan":
      return (
        <SlideFrame align="center">
          <SlideEyebrow icon={Compass} color={ACCENTS.plan.text}>Your Roadmap</SlideEyebrow>
          <RoadmapDiagram heading="Our Recommended Plan" items={slide.items} />
        </SlideFrame>
      );

    case "sampleAds":
      return (
        <SlideFrame align="left">
          <SlideEyebrow icon={ImageIcon} color={ACCENTS.sampleAds.text}>Creative Preview</SlideEyebrow>
          <SlideHeading>What Your Ads Could Look Like</SlideHeading>
          <div className="mt-5 grid w-full max-w-4xl grid-cols-1 gap-3.5 sm:grid-cols-2">
            {slide.ads.map((ad, i) => {
              const { Icon: FormatIcon } = formatVisual(ad.format);
              return (
                <div key={i} className="overflow-hidden rounded-xl border border-slate-200 shadow-sm dark:border-slate-700">
                  <div className="flex items-center gap-2 border-b border-slate-100 bg-slate-50 px-3.5 py-1.5 dark:border-slate-800 dark:bg-slate-800/60">
                    <FormatIcon size={13} className="text-amber-600" />
                    <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">{ad.platform}</span>
                    {ad.format && <span className="ml-auto text-[10px] text-slate-400">{ad.format}</span>}
                  </div>
                  <div className="space-y-2 px-3.5 py-3">
                    <p className="text-sm font-bold leading-snug text-slate-900 dark:text-white">{ad.headline}</p>
                    {ad.benefit && <p className="text-xs text-slate-500 dark:text-slate-400">{ad.benefit}</p>}
                    <span className="inline-flex items-center rounded-md bg-amber-600 px-2.5 py-1 text-[11px] font-semibold text-white">
                      {ad.cta}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </SlideFrame>
      );

    case "forecast": {
      const chartData = slide.scenarios.map((sc) => ({ name: sc.label, Budget: sc.budget, Revenue: sc.revenue }));
      const statGridCols =
        slide.scenarios.length === 1 ? "sm:grid-cols-1" : slide.scenarios.length === 2 ? "sm:grid-cols-2" : "sm:grid-cols-3";
      return (
        <SlideFrame align="left">
          <SlideEyebrow icon={TrendingUp} color={ACCENTS.forecast.text}>The Numbers</SlideEyebrow>
          <SlideHeading>Projected Results</SlideHeading>
          <div className="mt-3 h-44 w-full max-w-4xl">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ left: 8, right: 8, top: 4, bottom: 4 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 10 }} tickFormatter={compactNumber} width={44} />
                <Tooltip formatter={(v) => formatCurrency(Number(v) || 0, slide.currency)} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="Budget" fill={CYAN} radius={[4, 4, 0, 0]} />
                <Bar dataKey="Revenue" fill={INDIGO} radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className={`mt-3 grid w-full max-w-4xl grid-cols-1 gap-3 ${statGridCols}`}>
            {slide.scenarios.map((sc, i) => (
              <div key={i} className="rounded-lg border border-slate-100 px-3.5 py-2.5 dark:border-slate-800">
                <p className="flex items-center gap-1.5 text-xs font-semibold text-teal-600 dark:text-teal-400">
                  <Target size={12} /> {sc.label}
                </p>
                <div className="mt-1.5 grid grid-cols-2 gap-x-2 gap-y-1.5">
                  <StatBlock label="Revenue" value={formatCurrency(sc.revenue, slide.currency)} />
                  <StatBlock
                    label="ROI"
                    value={formatPercent(sc.roi)}
                    accent={sc.roi < 0 ? "text-red-600 dark:text-red-400" : "text-teal-600 dark:text-teal-400"}
                  />
                  <StatBlock label="Leads" value={formatNumber(sc.leads)} />
                  <StatBlock label="Customers" value={formatNumber(sc.customers)} />
                </div>
              </div>
            ))}
          </div>
        </SlideFrame>
      );
    }

    case "cta":
      return (
        <SlideFrame>
          <Quote size={22} className="text-indigo-400" />
          <h2 className="mt-3 text-2xl font-bold text-slate-900 dark:text-white sm:text-3xl">
            Let&apos;s Build This Together
          </h2>
          {slide.ctaText && <p className="mt-4 max-w-xl text-lg text-slate-600 dark:text-slate-300">{slide.ctaText}</p>}
          <div className="mt-6 flex flex-wrap items-center justify-center gap-2.5">
            {slide.contacts.map((c, i) => {
              const Icon = c.label === "Phone" ? Phone : c.label === "Email" ? Mail : c.label === "WhatsApp" ? MessageCircle : Globe;
              return (
                <span
                  key={i}
                  className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 px-3 py-1.5 text-xs text-slate-600 dark:border-slate-700 dark:text-slate-300"
                >
                  <Icon size={13} className="text-indigo-500" />
                  {c.value}
                </span>
              );
            })}
          </div>
          {(slide.companyName || slide.consultantName) && (
            <p className="mt-6 text-xs text-slate-300 dark:text-slate-600">
              {slide.companyName}
              {slide.companyName && slide.consultantName && " · "}
              {slide.consultantName}
            </p>
          )}
        </SlideFrame>
      );
  }
}

// Overall audit score shown as a colored ring (conic-gradient) with the
// number in the middle — a quick visual read on where the score lands
// rather than just printing "62 / 100" as plain text.
function ScoreRing({ value }: { value: number }) {
  const pct = Math.max(0, Math.min(100, value));
  const color = pct >= 70 ? "#16a34a" : pct >= 40 ? "#f59e0b" : "#dc2626";
  return (
    <div
      className="relative flex h-28 w-28 shrink-0 items-center justify-center rounded-full"
      style={{ background: `conic-gradient(${color} ${pct * 3.6}deg, #e2e8f0 0deg)` }}
    >
      <div className="flex h-[88px] w-[88px] flex-col items-center justify-center rounded-full bg-white dark:bg-slate-900">
        <span className="text-2xl font-bold text-slate-900 dark:text-white tabular-nums">{Math.round(pct)}</span>
        <span className="text-[10px] text-slate-400">/ 100</span>
      </div>
    </div>
  );
}

// No brand icons (Facebook/Instagram/etc.) ship in this app's icon set, so
// platforms are matched by keyword to a generic icon + accent color instead
// — close enough to read at a glance without pretending to be an official
// brand mark.
function platformVisual(platform: string): { Icon: LucideIcon; color: string } {
  const p = platform.toLowerCase();
  if (p.includes("whatsapp")) return { Icon: MessageCircle, color: "#16a34a" };
  if (p.includes("google") || p.includes("search")) return { Icon: Search, color: "#4285F4" };
  if (p.includes("youtube") || p.includes("video")) return { Icon: PlayCircle, color: "#dc2626" };
  if (p.includes("linkedin")) return { Icon: Users, color: "#0a66c2" };
  if (p.includes("facebook") || p.includes("instagram") || p.includes("social")) return { Icon: Share2, color: "#ec4899" };
  return { Icon: Megaphone, color: INDIGO };
}

// Small labeled stat used inside the Forecast slide's scenario cards. Every
// other card type in this deck (Situation's issues, Platforms, Plan phases,
// Sample Ads) pairs its label with an icon — this brings the Forecast
// stats in line with that same visual language instead of being bare text.
// Each stat also gets its own semantic icon color (money = green, leads =
// blue, customers = violet, ...) rather than every stat sharing one flat
// gray icon, so the numbers-heavy slide reads with the same color variety
// as the rest of the deck.
// A plain label-over-value stat cell, deliberately without an icon — the
// Forecast slide's Revenue/ROI/Leads/Customers grid packs 4 of these into
// each scenario card, and an icon per cell there read as cramped/cluttered
// rather than helpful. ROI still carries a color (teal for positive, red
// for negative via `accent`) so the one number that has a "good/bad" read
// keeps a visual signal without needing an icon to carry it.
function StatBlock({ label, value, accent }: { label: string; value: string; accent?: string }) {
  return (
    <div>
      <p className="text-[10px] uppercase tracking-wide text-slate-400">{label}</p>
      <p className={`text-sm font-semibold tabular-nums text-slate-800 dark:text-slate-100 ${accent ?? ""}`}>{value}</p>
    </div>
  );
}

// A small uppercase icon + label row shown above a slide's main heading —
// the same eyebrow pattern every slide now uses, colored per-topic via
// ACCENTS so each slide type has a consistent, recognizable hue.
function SlideEyebrow({ icon: Icon, color, children }: { icon: LucideIcon; color: string; children: React.ReactNode }) {
  return (
    <p className={`flex items-center gap-1.5 text-xs font-semibold uppercase tracking-widest ${color}`}>
      <Icon size={13} /> {children}
    </p>
  );
}

// Maps a report-generated section label (e.g. "Buyer type", "Organic/SEO",
// "Local targeting") to a relevant icon by keyword, matching a small,
// consistent set of concepts these labels tend to use across reports. Falls
// back to a generic marker icon for any label that doesn't match — the
// label/description text itself is always the real, unaltered report text;
// this only ever picks how it's illustrated, never changes what it says.
function sectionIcon(label: string): LucideIcon {
  const l = label.toLowerCase();
  if (l.includes("buyer")) return UserCheck;
  if (l.includes("demographic")) return Users;
  if (l.includes("interest") || l.includes("behaviour") || l.includes("behavior")) return Activity;
  if (l.includes("example") || l.includes("customer")) return Sparkles;
  if (l.includes("local")) return MapPin;
  if (l.includes("organic") || l.includes("seo")) return Search;
  if (l.includes("paid") || l.includes("budget")) return DollarSign;
  return Layers;
}

// A labeled block of report text with a small icon badge — used for the
// Opportunity slide's parsed direction sections and the Audience slide's
// parsed audience sections (and their plain-paragraph fallbacks), so both
// read as icon-coded cards instead of bare uppercase-label-over-text pairs.
// Takes the host slide's accent so the badge/label color matches that
// slide's topic color (indigo on Opportunity, violet on Audience) rather
// than every labeled card in the deck being the same hue.
function LabeledSection({
  label,
  text,
  iconBg = "bg-indigo-50 dark:bg-indigo-500/10",
  iconText = "text-indigo-500",
  labelText = "text-indigo-500",
}: {
  label: string;
  text: string;
  iconBg?: string;
  iconText?: string;
  labelText?: string;
}) {
  const Icon = sectionIcon(label);
  return (
    <div className="flex items-start gap-2.5">
      <span className={`mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full ${iconBg}`}>
        <Icon size={13} className={iconText} />
      </span>
      <div className="min-w-0">
        <p className={`text-[11px] font-semibold uppercase tracking-wide ${labelText}`}>{label}</p>
        <p className="mt-0.5 text-sm text-slate-600 dark:text-slate-300">{text}</p>
      </div>
    </div>
  );
}

// The Opportunity slide's headline is normally a short, punchy one-liner
// ("Move to a mobile-first, conversion-focused website") that reads great
// huge and bold — but some reports write a fuller sentence there. Scaling
// the font down as the real text gets longer keeps it from overflowing the
// slide instead of truncating or hiding any of it.
function headlineSize(text: string): string {
  if (!text) return "text-2xl sm:text-3xl";
  if (text.length > 220) return "text-base sm:text-lg";
  if (text.length > 140) return "text-lg sm:text-xl";
  if (text.length > 80) return "text-xl sm:text-2xl";
  return "text-2xl sm:text-3xl";
}

// Chart-axis-only formatting (1,200 -> "1.2K") — a display convenience for
// keeping the Y axis readable; the real precise figure is always shown in
// the Tooltip and the stat cards below via formatCurrency/formatNumber.
function compactNumber(value: number): string {
  return new Intl.NumberFormat(undefined, { notation: "compact", maximumFractionDigits: 1 }).format(value);
}

function formatVisual(format?: string): { Icon: LucideIcon } {
  if (!format) return { Icon: Megaphone };
  const f = format.toLowerCase();
  if (f.includes("video")) return { Icon: PlayCircle };
  if (f.includes("image")) return { Icon: ImageIcon };
  if (f.includes("search")) return { Icon: Search };
  return { Icon: Megaphone };
}

function SlideFrame({ children, align = "center" }: { children: React.ReactNode; align?: "center" | "left" }) {
  return (
    <div
      className={`flex min-h-full flex-1 flex-col justify-center px-10 py-10 sm:px-16 ${
        align === "center" ? "items-center text-center" : "items-start text-left"
      }`}
    >
      {children}
    </div>
  );
}

function SlideHeading({ children }: { children: React.ReactNode }) {
  return <h2 className="text-2xl font-bold text-slate-900 dark:text-white sm:text-3xl">{children}</h2>;
}

// A distinct color per roadmap phase card — cycles if there are more than 5
// phases (buildPlanItems caps at 5). `line` is a hex value because it feeds
// an SVG stroke, which can't take a Tailwind class; it's kept in step with
// the matching `header` background class.
const PHASE_COLORS: { header: string; ring: string; line: string }[] = [
  { header: "bg-slate-600", ring: "border-slate-200 dark:border-slate-700", line: "#475569" },
  { header: "bg-amber-500", ring: "border-amber-200 dark:border-amber-900", line: "#d97706" },
  { header: "bg-teal-600", ring: "border-teal-200 dark:border-teal-900", line: "#0d9488" },
  { header: "bg-indigo-600", ring: "border-indigo-200 dark:border-indigo-900", line: "#4f46e5" },
  { header: "bg-rose-600", ring: "border-rose-200 dark:border-rose-900", line: "#e11d48" },
];

/**
 * A flowchart-style roadmap: a pill-shaped hub at the top (the plan
 * headline) with a curved connector line running down to each phase card
 * below it — modeled on a reference slide template the user shared. The
 * card count and each card's title/bullets come straight from the real
 * growth-plan phases (`items`); nothing here is invented, only laid out.
 *
 * The connector curves are drawn as an SVG overlay whose path coordinates
 * are measured from the actual rendered positions of the hub and each card
 * (via getBoundingClientRect, in a useLayoutEffect + ResizeObserver) rather
 * than assumed from a fixed layout — so the lines still land exactly on
 * each box whether there are 2 phases or 5, and stay correct across a
 * window resize or the fullscreen toggle.
 */
function RoadmapDiagram({ heading, items }: { heading: string; items: { title: string; detail: string[] }[] }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const hubRef = useRef<HTMLDivElement>(null);
  const itemRefs = useRef<(HTMLDivElement | null)[]>([]);
  const [geo, setGeo] = useState<{ w: number; h: number; hub: { x: number; y: number }; points: ({ x: number; y: number } | null)[] } | null>(
    null
  );

  useLayoutEffect(() => {
    const container = containerRef.current;
    const hub = hubRef.current;
    if (!container || !hub) return;

    const measure = () => {
      const cRect = container.getBoundingClientRect();
      // The whole slide deck is scaled as a unit (see ReportSlideshowModal's
      // SLIDE_CANVAS_WIDTH/HEIGHT scaling) so it fills the fullscreen popup
      // — which means this diagram itself renders inside a CSS-transformed
      // ancestor. getBoundingClientRect() reports post-transform (visual)
      // coordinates, but the SVG we're about to draw isn't independently
      // transformed — it inherits the same ambient scale as everything else
      // in the tree, so drawing at those raw visual coordinates would apply
      // the scale a second time and throw the lines off. `scale` here is
      // the ambient transform factor (visual width vs. untransformed layout
      // width), and dividing every measured coordinate by it converts back
      // to the local/untransformed pixel space the SVG actually draws in.
      const scale = container.offsetWidth > 0 ? cRect.width / container.offsetWidth : 1;
      const hRect = hub.getBoundingClientRect();
      const hubPoint = {
        x: (hRect.left + hRect.width / 2 - cRect.left) / scale,
        y: (hRect.bottom - cRect.top) / scale,
      };
      const points = itemRefs.current.map((el) => {
        if (!el) return null;
        const r = el.getBoundingClientRect();
        return { x: (r.left + r.width / 2 - cRect.left) / scale, y: (r.top - cRect.top) / scale };
      });
      setGeo({ w: container.offsetWidth, h: container.offsetHeight, hub: hubPoint, points });
    };

    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(container);
    return () => ro.disconnect();
  }, [items.length]);

  return (
    <div ref={containerRef} className="relative mt-2 w-full max-w-4xl">
      {geo && (
        <svg className="pointer-events-none absolute inset-0" width={geo.w} height={geo.h} viewBox={`0 0 ${geo.w} ${geo.h}`}>
          {geo.points.map((p, i) => {
            if (!p) return null;
            const midY = (geo.hub.y + p.y) / 2;
            const color = PHASE_COLORS[i % PHASE_COLORS.length].line;
            return (
              <g key={i}>
                <path
                  d={`M ${geo.hub.x} ${geo.hub.y} C ${geo.hub.x} ${midY}, ${p.x} ${midY}, ${p.x} ${p.y}`}
                  fill="none"
                  stroke={color}
                  strokeWidth={1.5}
                />
                <circle cx={p.x} cy={p.y} r={3.5} fill="white" stroke={color} strokeWidth={1.5} />
              </g>
            );
          })}
          <circle cx={geo.hub.x} cy={geo.hub.y} r={3.5} fill="white" stroke="#059669" strokeWidth={1.5} />
        </svg>
      )}

      <div className="flex justify-center">
        <div ref={hubRef} className="relative rounded-full bg-emerald-600 px-6 py-2.5 text-sm font-bold text-white shadow-sm">
          {heading}
        </div>
      </div>

      <div className="relative mt-9 flex flex-wrap justify-center gap-4">
        {items.map((item, i) => {
          const c = PHASE_COLORS[i % PHASE_COLORS.length];
          return (
            <div
              key={i}
              ref={(el) => {
                itemRefs.current[i] = el;
              }}
              className={`w-56 overflow-hidden rounded-xl border bg-white text-left shadow-sm dark:bg-slate-900 ${c.ring}`}
            >
              <div className={`px-3 py-2 text-xs font-bold leading-snug text-white ${c.header}`}>{item.title}</div>
              {item.detail.length > 0 && (
                <ul className="space-y-1.5 px-3 py-3">
                  {item.detail.map((d, j) => (
                    <li key={j} className="flex items-start gap-1.5 text-xs text-slate-600 dark:text-slate-300">
                      <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-slate-400" />
                      {d}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
