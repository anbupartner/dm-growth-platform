import type { ReportData, ReportAuditScores } from "@/lib/pdf/types";
import { formatCurrency, formatNumber, formatPercent } from "@/lib/calculations";

// A client-facing slide deck built from the same ReportData used for the
// full PDF report. This is a curated, visual highlight reel meant for
// walking a client through the audit live in a meeting — not a
// slide-per-section dump of the whole report, so it still leaves out the
// most granular detail (raw competitor site metrics, every sample ad, the
// full assumptions table) that belongs in the PDF instead. Within that, it
// aims to be as visual as the underlying data allows — charts and icon
// cards over paragraphs — and includes every section that has real data to
// show, rather than just the bare minimum.
//
// Every value shown here is read directly from ReportData — nothing is
// invented, estimated, or picked "on Claude's behalf" beyond straightforward
// truncation (e.g. showing the first few growth-plan items) and taking
// items in the order they were already saved in. A slide is simply omitted
// when the report doesn't have the data it would need (e.g. no Forecast
// slide when no scenarios were saved for this report).

export interface TextSection {
  label: string;
  text: string;
}

export type PitchSlide =
  | { type: "title"; businessName: string; customerName: string; companyName: string; generatedDate: string }
  | { type: "situation"; currentSituation: string; problems: string[] }
  | {
      type: "opportunity";
      biggestOpportunity: string;
      recommendedDirection: string;
      // When recommendedDirection already reads as "Label: detail. Label:
      // detail...", these are the parsed-out pieces so the slide can show a
      // clean list instead of one dense paragraph. Null when the text isn't
      // structured that way — the slide then falls back to
      // recommendedDirection as plain text.
      directionIntro: string | null;
      directionSections: TextSection[] | null;
    }
  | { type: "auditScores"; overall: number; scores: { label: string; value: number }[] }
  | {
      type: "audienceProfile";
      targetAudience: string;
      audienceIntro: string | null;
      audienceSections: TextSection[] | null;
    }
  | {
      type: "platforms";
      platforms: { platform: string; adType: string; expectedResult: string; budgetAllocation?: string }[];
    }
  | { type: "plan"; items: { title: string; detail: string[] }[] }
  | {
      type: "sampleAds";
      ads: { platform: string; format?: string; headline: string; benefit?: string; cta: string }[];
    }
  | {
      type: "forecast";
      currency: string;
      scenarios: { label: string; budget: number; revenue: number; leads: number; customers: number; roi: number }[];
    }
  | { type: "cta"; ctaText: string; companyName: string; consultantName: string; contacts: { label: string; value: string }[] };

// Canonical scenario display order — mirrors the tierOrder used in
// ReportDocument.tsx (PDF) and the proposal builder, so every place the app
// shows scenarios side by side (PDF, proposal, presentation deck, PPTX
// export) reads the same "conservative to growth" story left to right.
const SCENARIO_TIER_ORDER = ["conservative", "expected", "growth opportunity"];

const SCORE_LABELS: Record<keyof Omit<ReportAuditScores, "overall">, string> = {
  technicalSeo: "Technical SEO",
  onPageSeo: "On-Page SEO",
  content: "Content",
  uxConversion: "UX & Conversion",
  branding: "Branding",
  localSeo: "Local SEO",
  performance: "Performance",
};

export function buildPitchSlides(data: ReportData): PitchSlide[] {
  const slides: PitchSlide[] = [];

  slides.push({
    type: "title",
    businessName: data.business.businessName,
    customerName: data.business.customerName,
    companyName: data.consultant.companyName,
    generatedDate: data.generatedDate,
  });

  if (data.executiveSummary.currentSituation || data.executiveSummary.problems.length > 0) {
    slides.push({
      type: "situation",
      currentSituation: data.executiveSummary.currentSituation,
      // Keep the slide scannable — the PDF has the full list.
      problems: data.executiveSummary.problems.slice(0, 4),
    });
  }

  if (data.executiveSummary.biggestOpportunity) {
    const parsedDirection = parseLabeledSections(data.executiveSummary.recommendedDirection);
    slides.push({
      type: "opportunity",
      biggestOpportunity: data.executiveSummary.biggestOpportunity,
      recommendedDirection: data.executiveSummary.recommendedDirection,
      directionIntro: parsedDirection?.intro || null,
      directionSections: parsedDirection?.sections ?? null,
    });
  }

  // Only meaningful for has-website reports, and only if scores were
  // actually computed for this one (older/edited reports may lack them).
  if (data.auditScores) {
    const s = data.auditScores;
    slides.push({
      type: "auditScores",
      overall: s.overall,
      scores: (Object.keys(SCORE_LABELS) as Array<keyof typeof SCORE_LABELS>).map((key) => ({
        label: SCORE_LABELS[key],
        value: s[key],
      })),
    });
  }

  // Split into two focused slides — who the audience is, and where/how
  // they'll be reached — rather than cramming a (sometimes long) audience
  // description and the platform cards onto one slide. Each is independently
  // optional depending on what data the report actually has.
  if (data.audiencePlatform.targetAudience) {
    const parsedAudience = parseLabeledSections(data.audiencePlatform.targetAudience);
    slides.push({
      type: "audienceProfile",
      targetAudience: data.audiencePlatform.targetAudience,
      audienceIntro: parsedAudience?.intro || null,
      audienceSections: parsedAudience?.sections ?? null,
    });
  }

  if (data.audiencePlatform.platforms.length > 0) {
    slides.push({
      type: "platforms",
      // Cap so the grid stays readable on one slide — the PDF has the rest.
      platforms: data.audiencePlatform.platforms.slice(0, 6),
    });
  }

  const planItems = buildPlanItems(data);
  if (planItems.length > 0) {
    slides.push({ type: "plan", items: planItems });
  }

  // Concrete sample-ad previews make the deck feel tangible to a client
  // instead of all strategy talk — shown as mocked-up ad cards, one per
  // platform/variant that was actually generated, not a text dump of every
  // field each sample ad carries. Capped at 4 so the grid stays readable.
  const sampleAds = data.sampleAds.filter((ad) => ad.headline).slice(0, 4);
  if (sampleAds.length > 0) {
    slides.push({
      type: "sampleAds",
      ads: sampleAds.map((ad) => ({
        platform: ad.platform,
        format: ad.format,
        headline: ad.headline,
        benefit: ad.benefit,
        cta: ad.cta,
      })),
    });
  }

  if (data.scenarios.length > 0) {
    // Scenario cards always read Conservative -> Expected -> Growth
    // Opportunity left to right, regardless of the order scenarios came back
    // from the DB — same canonical tier order the PDF report and the
    // proposal page already use, so the chart/cards/detail table read the
    // same "conservative to growth" narrative everywhere the scenarios are
    // shown. A custom-named scenario without a recognized tier keeps its
    // relative position, sorted after the three standard tiers.
    const orderedScenarios = [...data.scenarios].sort((a, b) => {
      const ai = SCENARIO_TIER_ORDER.indexOf(a.label.toLowerCase());
      const bi = SCENARIO_TIER_ORDER.indexOf(b.label.toLowerCase());
      return (ai === -1 ? 99 : ai) - (bi === -1 ? 99 : bi);
    });
    slides.push({
      type: "forecast",
      currency: data.consultant.currency,
      // Cap at 3 scenarios so the chart/cards stay readable.
      scenarios: orderedScenarios.slice(0, 3).map((s) => ({
        label: s.label,
        budget: s.budget,
        revenue: s.revenue,
        leads: s.leads,
        customers: s.customers,
        roi: s.roi,
      })),
    });
  }

  const contacts: { label: string; value: string }[] = [];
  if (data.consultant.phone) contacts.push({ label: "Phone", value: data.consultant.phone });
  if (data.consultant.whatsapp && data.consultant.whatsapp !== data.consultant.phone)
    contacts.push({ label: "WhatsApp", value: data.consultant.whatsapp });
  if (data.consultant.email) contacts.push({ label: "Email", value: data.consultant.email });
  if (data.consultant.website) contacts.push({ label: "Website", value: data.consultant.website });

  slides.push({
    type: "cta",
    ctaText: data.consultant.ctaText,
    companyName: data.consultant.companyName,
    consultantName: data.consultant.consultantName,
    contacts,
  });

  return slides;
}

function buildPlanItems(data: ReportData): { title: string; detail: string[] }[] {
  // Prefer the actual phased Growth Plan when one was generated — it's the
  // most concrete, client-ready version of "here's what we'll do." Each
  // phase's real action items are kept as a list (not truncated to one
  // joined line) so the slide reads like an actual roadmap.
  if (data.growthPlan.length > 0) {
    return data.growthPlan.slice(0, 5).map((phase) => ({
      title: phase.phase,
      detail: phase.items.slice(0, 4),
    }));
  }
  // No-website reports won't have a Growth Plan in every case — fall back to
  // the strategic/website recommendations that ARE always present for a
  // no-website report, so the slide still has real, sourced content rather
  // than being skipped unnecessarily.
  if (data.websiteRecommendations.strategicRecommendations?.length) {
    return data.websiteRecommendations.strategicRecommendations.slice(0, 5).map((r) => ({ title: r, detail: [] }));
  }
  if (data.websiteRecommendations.recommendedImprovements?.length) {
    return data.websiteRecommendations.recommendedImprovements.slice(0, 5).map((r) => ({ title: r, detail: [] }));
  }
  return [];
}

// Some auto-generated report fields come back as one long paragraph that
// already embeds its own "Label: detail." sub-sections — e.g. a target
// audience description that reads "...Buyer type: X. Demographic: Y.
// Interests & online behaviour: Z..." or a recommended-direction paragraph
// that reads "Organic/SEO: ... Paid: ... Local presence: ...". Detecting
// that pattern and splitting it out turns a dense wall of text into a
// scannable list on the slide — using only text that was already there.
// Nothing is summarized, reworded, or invented; a label is only ever text
// the report itself already wrote right before its own colon. Text that
// doesn't follow this pattern (fewer than 2 matches) returns null, and the
// slide falls back to showing it as a plain paragraph.
function parseLabeledSections(text: string): { intro: string; sections: TextSection[] } | null {
  if (!text) return null;
  const labelPattern = /(?:^|\.\s+)([A-Z][A-Za-z0-9 /&()'-]{1,40}):\s+/g;
  const matches = [...text.matchAll(labelPattern)];
  if (matches.length < 2) return null;

  const firstIndex = matches[0].index ?? 0;
  const intro = text.slice(0, firstIndex).trim().replace(/\.$/, "");

  const sections: TextSection[] = matches.map((m, i) => {
    const start = (m.index ?? 0) + m[0].length;
    const end = i + 1 < matches.length ? (matches[i + 1].index ?? text.length) : text.length;
    return { label: m[1].trim(), text: text.slice(start, end).trim() };
  });

  return { intro, sections };
}

// Re-exported so the modal can format forecast numbers identically to the
// rest of the app without duplicating the currency/percent logic here.
export { formatCurrency, formatNumber, formatPercent };
