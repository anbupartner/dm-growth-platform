import type { PitchSlide } from "@/lib/pitch-slides";
import { formatCurrency, formatNumber, formatPercent } from "@/lib/pitch-slides";

// Exports the same curated slide deck shown in the in-app slideshow popup
// as a real, editable PowerPoint (.pptx) file — built client-side with
// pptxgenjs, so the consultant can open it in PowerPoint/Google
// Slides/Keynote, tweak it, and present without this app open at all.
// Every slide type here mirrors the on-screen version in
// ReportSlideshowModal.tsx as closely as PowerPoint's layout model allows;
// values come straight from the same PitchSlide objects, nothing is
// recomputed or re-derived here.

const INDIGO = "4F46E5";
const CYAN = "06B6D4";
const RED = "DC2626";
const SLATE_900 = "0F172A";
const SLATE_600 = "475569";
const SLATE_500 = "64748B";
const SLATE_400 = "94A3B8";
const WHITE = "FFFFFF";

// Slide is 13.33 x 7.5in (PowerPoint's standard 16:9 "widescreen" layout).
const W = 13.33;
const MARGIN = 0.7;

export async function buildPitchPptx(slides: PitchSlide[], fileName: string): Promise<void> {
  const { default: PptxGenJS } = await import("pptxgenjs");
  const pptx = new PptxGenJS();
  pptx.layout = "LAYOUT_WIDE"; // 13.33 x 7.5in, matches W above
  pptx.author = "Growth Platform";
  pptx.title = fileName.replace(/\.pptx$/i, "");

  for (const slide of slides) {
    const s = pptx.addSlide();
    s.background = { color: WHITE };
    switch (slide.type) {
      case "title":
        renderTitle(s, slide);
        break;
      case "situation":
        renderSituation(s, slide);
        break;
      case "opportunity":
        renderOpportunity(s, slide);
        break;
      case "auditScores":
        renderAuditScores(pptx, s, slide);
        break;
      case "audienceProfile":
        renderAudienceProfile(s, slide);
        break;
      case "platforms":
        renderPlatforms(s, slide);
        break;
      case "plan":
        renderPlan(s, slide);
        break;
      case "sampleAds":
        renderSampleAds(s, slide);
        break;
      case "forecast":
        renderForecast(pptx, s, slide);
        break;
      case "cta":
        renderCta(s, slide);
        break;
    }
  }

  await pptx.writeFile({ fileName });
}

function renderTitle(s: import("pptxgenjs").default.Slide, slide: Extract<PitchSlide, { type: "title" }>) {
  s.addText("DIGITAL GROWTH AUDIT & STRATEGY", {
    x: 0,
    y: 2.6,
    w: W,
    h: 0.4,
    align: "center",
    fontSize: 13,
    bold: true,
    color: INDIGO,
    charSpacing: 2,
  });
  s.addText(slide.businessName, {
    x: 0.5,
    y: 3.0,
    w: W - 1,
    h: 1.2,
    align: "center",
    fontSize: 40,
    bold: true,
    color: SLATE_900,
  });
  s.addText(`Prepared for ${slide.customerName} · ${slide.generatedDate}`, {
    x: 0,
    y: 4.25,
    w: W,
    h: 0.4,
    align: "center",
    fontSize: 13,
    color: SLATE_500,
  });
  if (slide.companyName) {
    s.addText(slide.companyName, { x: 0, y: 4.65, w: W, h: 0.35, align: "center", fontSize: 11, color: SLATE_400 });
  }
}

function heading(s: import("pptxgenjs").default.Slide, text: string) {
  s.addText(text, { x: MARGIN, y: 0.55, w: W - MARGIN * 2, h: 0.7, fontSize: 28, bold: true, color: SLATE_900 });
}

function renderSituation(s: import("pptxgenjs").default.Slide, slide: Extract<PitchSlide, { type: "situation" }>) {
  heading(s, "Where You Stand Today");
  s.addText("Issues already affecting your business — many go unnoticed until now", {
    x: MARGIN,
    y: 1.3,
    w: W - MARGIN * 2,
    h: 0.35,
    fontSize: 12,
    italic: true,
    color: RED,
  });
  let y = 1.8;
  if (slide.currentSituation) {
    s.addText(slide.currentSituation, {
      x: MARGIN,
      y,
      w: W - MARGIN * 2,
      h: 0.7,
      fontSize: 14,
      color: SLATE_600,
    });
    y += 0.9;
  }
  const colW = (W - MARGIN * 2 - 0.3) / 2;
  slide.problems.forEach((p, i) => {
    const col = i % 2;
    const row = Math.floor(i / 2);
    s.addShape("roundRect", {
      x: MARGIN + col * (colW + 0.3),
      y: y + row * 1.0,
      w: colW,
      h: 0.85,
      fill: { color: "FEF2F2" },
      line: { color: "FECACA", width: 0.75 },
      rectRadius: 0.06,
    });
    s.addText(
      [
        { text: `ISSUE ${i + 1}\n`, options: { fontSize: 9, bold: true, color: RED, charSpacing: 1 } },
        { text: p, options: { fontSize: 11, color: SLATE_600 } },
      ],
      { x: MARGIN + col * (colW + 0.3) + 0.15, y: y + row * 1.0 + 0.08, w: colW - 0.3, h: 0.7, valign: "top" }
    );
  });
}

// Mirrors headlineSize() in ReportSlideshowModal.tsx — the headline is
// normally a short one-liner that reads well large, but some reports write
// a fuller sentence there, so the font scales down with length instead of
// overflowing the slide.
function opportunityHeadlineSize(text: string): number {
  if (!text) return 26;
  if (text.length > 260) return 16;
  if (text.length > 140) return 20;
  return 26;
}

function renderOpportunity(s: import("pptxgenjs").default.Slide, slide: Extract<PitchSlide, { type: "opportunity" }>) {
  s.addText("THE BIG OPPORTUNITY", {
    x: MARGIN,
    y: 0.7,
    w: W - MARGIN * 2,
    h: 0.35,
    fontSize: 12,
    bold: true,
    color: INDIGO,
    charSpacing: 2,
  });
  s.addText(slide.biggestOpportunity, {
    x: MARGIN,
    y: 1.15,
    w: W - MARGIN * 2,
    h: 1.3,
    fontSize: opportunityHeadlineSize(slide.biggestOpportunity),
    bold: true,
    color: SLATE_900,
    valign: "top",
  });
  // When the recommended-direction text already reads as "Label: detail.
  // Label: detail...", show it as a clean labeled list (same data the
  // on-screen slide parses out via parseLabeledSections) instead of one
  // dense paragraph. Falls back to the plain text when it isn't structured
  // that way.
  if (slide.directionSections) {
    let y = 2.65;
    if (slide.directionIntro) {
      s.addText(slide.directionIntro, { x: MARGIN, y, w: W - MARGIN * 2, h: 0.5, fontSize: 13, color: SLATE_500, valign: "top" });
      y += 0.55;
    }
    const colW = (W - MARGIN * 2 - 0.3) / 2;
    slide.directionSections.forEach((sec, i) => {
      const col = i % 2;
      const row = Math.floor(i / 2);
      const x = MARGIN + col * (colW + 0.3);
      const yy = y + row * 1.1;
      s.addText(sec.label.toUpperCase(), { x, y: yy, w: colW, h: 0.3, fontSize: 10, bold: true, color: INDIGO, charSpacing: 1 });
      s.addText(sec.text, { x, y: yy + 0.28, w: colW, h: 0.75, fontSize: 11.5, color: SLATE_600, valign: "top" });
    });
  } else if (slide.recommendedDirection) {
    s.addText(slide.recommendedDirection, {
      x: MARGIN,
      y: 2.65,
      w: W - MARGIN * 2,
      h: 1.5,
      fontSize: 15,
      color: SLATE_500,
      valign: "top",
    });
  }
}

function renderAuditScores(
  pptx: import("pptxgenjs").default,
  s: import("pptxgenjs").default.Slide,
  slide: Extract<PitchSlide, { type: "auditScores" }>
) {
  heading(s, "Where Your Website Stands");
  s.addText(`${Math.round(slide.overall)}`, {
    x: MARGIN,
    y: 1.6,
    w: 2,
    h: 1.1,
    fontSize: 54,
    bold: true,
    color: slide.overall >= 70 ? "16A34A" : slide.overall >= 40 ? "D97706" : RED,
    align: "center",
  });
  s.addText("Overall Audit Score / 100", {
    x: MARGIN,
    y: 2.7,
    w: 2,
    h: 0.4,
    fontSize: 10,
    color: SLATE_500,
    align: "center",
  });
  s.addChart(
    pptx.ChartType.bar,
    [
      {
        name: "Score",
        labels: slide.scores.map((sc) => sc.label),
        values: slide.scores.map((sc) => sc.value),
      },
    ],
    {
      x: 2.9,
      y: 1.4,
      w: W - MARGIN - 2.9,
      h: 4.4,
      barDir: "bar",
      chartColors: [INDIGO],
      catAxisLabelFontSize: 10,
      valAxisMinVal: 0,
      valAxisMaxVal: 100,
      showValue: true,
      dataLabelFontSize: 9,
      showLegend: false,
    }
  );
}

// Split into two slides — who the audience is, and where/how they'll be
// reached — mirroring the on-screen audienceProfile/platforms split, so a
// long audience description no longer has to share a slide with the
// platform table.
function renderAudienceProfile(s: import("pptxgenjs").default.Slide, slide: Extract<PitchSlide, { type: "audienceProfile" }>) {
  heading(s, "Your Ideal Customer");
  s.addText("WHO WE'LL TARGET", {
    x: MARGIN,
    y: 0.55,
    w: W - MARGIN * 2,
    h: 0.3,
    fontSize: 10,
    bold: true,
    color: INDIGO,
    charSpacing: 1.5,
  });
  if (slide.audienceSections) {
    let y = 1.5;
    if (slide.audienceIntro) {
      s.addText(slide.audienceIntro, { x: MARGIN, y, w: W - MARGIN * 2, h: 0.5, fontSize: 13, color: SLATE_500, valign: "top" });
      y += 0.55;
    }
    const colW = (W - MARGIN * 2 - 0.3) / 2;
    slide.audienceSections.forEach((sec, i) => {
      const col = i % 2;
      const row = Math.floor(i / 2);
      const x = MARGIN + col * (colW + 0.3);
      const yy = y + row * 1.1;
      s.addText(sec.label.toUpperCase(), { x, y: yy, w: colW, h: 0.3, fontSize: 10, bold: true, color: INDIGO, charSpacing: 1 });
      s.addText(sec.text, { x, y: yy + 0.28, w: colW, h: 0.75, fontSize: 11.5, color: SLATE_600, valign: "top" });
    });
  } else if (slide.targetAudience) {
    s.addText(slide.targetAudience, { x: MARGIN, y: 1.5, w: W - MARGIN * 2, h: 2, fontSize: 14, color: SLATE_600, valign: "top" });
  }
}

function renderPlatforms(s: import("pptxgenjs").default.Slide, slide: Extract<PitchSlide, { type: "platforms" }>) {
  heading(s, "Where We'll Reach Them");
  const rows = [
    [
      { text: "Platform", options: { bold: true, color: WHITE, fill: { color: INDIGO } } },
      { text: "Ad Type", options: { bold: true, color: WHITE, fill: { color: INDIGO } } },
      { text: "Expected Result", options: { bold: true, color: WHITE, fill: { color: INDIGO } } },
      { text: "Budget", options: { bold: true, color: WHITE, fill: { color: INDIGO } } },
    ],
    ...slide.platforms.map((p) => [
      { text: p.platform },
      { text: p.adType },
      { text: p.expectedResult || "—" },
      { text: p.budgetAllocation || "—" },
    ]),
  ];
  s.addTable(rows as import("pptxgenjs").default.TableRow[], {
    x: MARGIN,
    y: 1.3,
    w: W - MARGIN * 2,
    fontSize: 11,
    color: SLATE_600,
    border: { type: "solid", color: "E2E8F0", pt: 0.5 },
    autoPage: false,
  });
}

function renderPlan(s: import("pptxgenjs").default.Slide, slide: Extract<PitchSlide, { type: "plan" }>) {
  heading(s, "Our Recommended Plan");
  const n = slide.items.length;
  const rowH = (7.5 - 1.5 - 0.3) / Math.max(n, 1);
  slide.items.forEach((item, i) => {
    const y = 1.5 + i * rowH;
    s.addShape("ellipse", {
      x: MARGIN,
      y: y + 0.05,
      w: 0.35,
      h: 0.35,
      fill: { color: INDIGO },
      line: { type: "none" },
    });
    s.addText(String(i + 1), { x: MARGIN, y: y + 0.05, w: 0.35, h: 0.35, align: "center", valign: "middle", fontSize: 12, bold: true, color: WHITE });
    const detail = item.detail.length > 0 ? item.detail.map((d) => `•  ${d}`).join("\n") : "";
    s.addText(
      [
        { text: item.title + "\n", options: { bold: true, fontSize: 13, color: SLATE_900 } },
        ...(detail ? [{ text: detail, options: { fontSize: 10.5, color: SLATE_500 } }] : []),
      ],
      { x: MARGIN + 0.55, y, w: W - MARGIN * 2 - 0.55, h: rowH - 0.1, valign: "top" }
    );
  });
}

function renderSampleAds(s: import("pptxgenjs").default.Slide, slide: Extract<PitchSlide, { type: "sampleAds" }>) {
  heading(s, "What Your Ads Could Look Like");
  const cols = 2;
  const cardW = (W - MARGIN * 2 - 0.4) / cols;
  const cardH = 2.35;
  slide.ads.forEach((ad, i) => {
    const col = i % cols;
    const row = Math.floor(i / cols);
    const x = MARGIN + col * (cardW + 0.4);
    const y = 1.4 + row * (cardH + 0.3);
    s.addShape("roundRect", { x, y, w: cardW, h: cardH, fill: { color: WHITE }, line: { color: "CBD5E1", width: 1 }, rectRadius: 0.08 });
    s.addText(`${ad.platform}${ad.format ? "  ·  " + ad.format : ""}`, {
      x: x + 0.2,
      y: y + 0.15,
      w: cardW - 0.4,
      h: 0.3,
      fontSize: 10,
      bold: true,
      color: SLATE_500,
    });
    s.addText(ad.headline, { x: x + 0.2, y: y + 0.55, w: cardW - 0.4, h: 0.7, fontSize: 15, bold: true, color: SLATE_900, valign: "top" });
    if (ad.benefit) {
      s.addText(ad.benefit, { x: x + 0.2, y: y + 1.25, w: cardW - 0.4, h: 0.5, fontSize: 10.5, color: SLATE_500, valign: "top" });
    }
    s.addShape("roundRect", { x: x + 0.2, y: y + cardH - 0.55, w: 1.6, h: 0.35, fill: { color: INDIGO }, line: { type: "none" }, rectRadius: 0.05 });
    s.addText(ad.cta, { x: x + 0.2, y: y + cardH - 0.55, w: 1.6, h: 0.35, align: "center", valign: "middle", fontSize: 10, bold: true, color: WHITE });
  });
}

function renderForecast(
  pptx: import("pptxgenjs").default,
  s: import("pptxgenjs").default.Slide,
  slide: Extract<PitchSlide, { type: "forecast" }>
) {
  heading(s, "Projected Results");
  s.addChart(
    pptx.ChartType.bar,
    [
      { name: "Budget", labels: slide.scenarios.map((sc) => sc.label), values: slide.scenarios.map((sc) => sc.budget) },
      { name: "Revenue", labels: slide.scenarios.map((sc) => sc.label), values: slide.scenarios.map((sc) => sc.revenue) },
    ],
    {
      x: MARGIN,
      y: 1.3,
      w: W - MARGIN * 2,
      h: 2.9,
      barDir: "col",
      chartColors: [CYAN, INDIGO],
      catAxisLabelFontSize: 10,
      showLegend: true,
      legendPos: "b",
      legendFontSize: 10,
    }
  );
  const rows = [
    [
      { text: "Scenario", options: { bold: true, color: WHITE, fill: { color: INDIGO } } },
      { text: "Revenue", options: { bold: true, color: WHITE, fill: { color: INDIGO } } },
      { text: "Leads → Customers", options: { bold: true, color: WHITE, fill: { color: INDIGO } } },
      { text: "ROI", options: { bold: true, color: WHITE, fill: { color: INDIGO } } },
    ],
    ...slide.scenarios.map((sc) => [
      { text: sc.label },
      { text: formatCurrency(sc.revenue, slide.currency) },
      { text: `${formatNumber(sc.leads)} → ${formatNumber(sc.customers)}` },
      { text: formatPercent(sc.roi) },
    ]),
  ];
  s.addTable(rows as import("pptxgenjs").default.TableRow[], {
    x: MARGIN,
    y: 4.4,
    w: W - MARGIN * 2,
    fontSize: 11,
    color: SLATE_600,
    border: { type: "solid", color: "E2E8F0", pt: 0.5 },
    autoPage: false,
  });
}

function renderCta(s: import("pptxgenjs").default.Slide, slide: Extract<PitchSlide, { type: "cta" }>) {
  s.addText("Let's Build This Together", {
    x: 0,
    y: 2.2,
    w: W,
    h: 0.8,
    align: "center",
    fontSize: 32,
    bold: true,
    color: SLATE_900,
  });
  if (slide.ctaText) {
    s.addText(slide.ctaText, { x: 1.5, y: 3.0, w: W - 3, h: 0.7, align: "center", fontSize: 15, color: SLATE_600 });
  }
  const contactLine = slide.contacts.map((c) => `${c.label}: ${c.value}`).join("      ");
  if (contactLine) {
    s.addText(contactLine, { x: 0, y: 3.9, w: W, h: 0.4, align: "center", fontSize: 12, color: SLATE_500 });
  }
  const footer = [slide.companyName, slide.consultantName].filter(Boolean).join("  ·  ");
  if (footer) {
    s.addText(footer, { x: 0, y: 4.5, w: W, h: 0.35, align: "center", fontSize: 10, color: SLATE_400 });
  }
}
