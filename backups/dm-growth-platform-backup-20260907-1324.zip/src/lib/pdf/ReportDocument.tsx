import { Document, Page, Text, View, StyleSheet, Image, Svg, Circle, G, Path, Polygon } from "@react-pdf/renderer";
import type { ReportData } from "./types";
import { auditStatusLabel } from "@/lib/constants";
import { formatCurrency, formatNumber } from "@/lib/calculations";

const COLORS = {
  ink: "#111827",
  sub: "#4b5563",
  faint: "#9ca3af",
  brand: "#4f46e5",
  brandSoft: "#eef2ff",
  line: "#e5e7eb",
  good: "#059669",
  goodSoft: "#ecfdf5",
  warn: "#d97706",
  warnSoft: "#fffbeb",
  bad: "#dc2626",
  badSoft: "#fef2f2",
  slate: "#64748b",
  slateSoft: "#f1f5f9",
};

const s = StyleSheet.create({
  page: { padding: 40, fontSize: 10, color: COLORS.ink, fontFamily: "Helvetica" },
  headerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 16 },
  brandTitle: { fontSize: 10, color: COLORS.brand, fontFamily: "Helvetica-Bold" },
  pageTitle: { fontSize: 18, fontFamily: "Helvetica-Bold", marginBottom: 4 },
  pageSubtitle: { fontSize: 10, color: COLORS.sub, marginBottom: 14 },
  sectionLabel: { fontSize: 11, fontFamily: "Helvetica-Bold", marginTop: 14, marginBottom: 6, color: COLORS.brand },
  bodyText: { fontSize: 10, color: COLORS.ink, lineHeight: 1.5 },
  subText: { fontSize: 9, color: COLORS.sub, lineHeight: 1.4 },
  bulletRow: { flexDirection: "row", marginBottom: 4 },
  bulletDot: { width: 10, fontSize: 10, color: COLORS.brand },
  bulletText: { flex: 1, fontSize: 10, lineHeight: 1.4 },
  card: { backgroundColor: COLORS.brandSoft, borderRadius: 6, padding: 10, marginBottom: 8 },
  divider: { borderBottomWidth: 1, borderBottomColor: COLORS.line, marginVertical: 10 },
  footer: { position: "absolute", bottom: 24, left: 40, right: 40, fontSize: 8, color: COLORS.faint, flexDirection: "row", justifyContent: "space-between" },
  table: { borderWidth: 1, borderColor: COLORS.line, borderRadius: 4 },
  tr: { flexDirection: "row", borderBottomWidth: 1, borderBottomColor: COLORS.line },
  trLast: { flexDirection: "row" },
  thCell: { flex: 1, padding: 6, fontFamily: "Helvetica-Bold", fontSize: 8, backgroundColor: "#f8fafc" },
  tdCell: { flex: 1, padding: 6, fontSize: 8 },
  scoreBarTrack: { height: 6, backgroundColor: COLORS.line, borderRadius: 3, marginTop: 3 },
  scoreBarFill: { height: 6, borderRadius: 3 },
  adCard: { width: "47%", borderWidth: 1, borderColor: COLORS.line, borderRadius: 6, padding: 10, marginBottom: 10 },
  chip: { fontSize: 7, color: "#fff", backgroundColor: COLORS.brand, borderRadius: 3, paddingVertical: 2, paddingHorizontal: 6, alignSelf: "flex-start", marginBottom: 6 },
  // --- visual/persuasion components added for the client-facing redesign ---
  heroRow: { flexDirection: "row", marginBottom: 14 },
  statTile: { flex: 1, borderWidth: 1, borderColor: COLORS.line, borderRadius: 8, padding: 10, marginRight: 8, justifyContent: "center" },
  statTileLast: { marginRight: 0 },
  statLabel: { fontSize: 7.5, color: COLORS.sub, marginBottom: 3 },
  statValue: { fontSize: 18, fontFamily: "Helvetica-Bold" },
  statSub: { fontSize: 6.5, color: COLORS.faint, marginTop: 2 },
  problemGrid: { flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between" },
  problemCard: { width: "48.5%", flexDirection: "row", alignItems: "flex-start", backgroundColor: COLORS.badSoft, borderRadius: 6, padding: 8, marginBottom: 8 },
  problemCardText: { flex: 1, fontSize: 8.5, lineHeight: 1.35, marginLeft: 7, color: COLORS.ink },
  calloutCard: { flexDirection: "row", alignItems: "flex-start", borderRadius: 6, padding: 10, marginBottom: 8 },
  calloutText: { flex: 1, fontSize: 9.5, lineHeight: 1.45, marginLeft: 9 },
  calloutLabel: { fontSize: 9, fontFamily: "Helvetica-Bold", marginBottom: 2 },
  stepRow: { flexDirection: "row", alignItems: "flex-start" },
  stepCard: { flex: 1, marginLeft: 10, borderRadius: 8, padding: 12, marginBottom: 0 },
  stepLabel: { fontSize: 12, fontFamily: "Helvetica-Bold", marginBottom: 4 },
  stepText: { fontSize: 9.5, lineHeight: 1.5, color: COLORS.ink },
  resultStatsRow: { flexDirection: "row", marginTop: 10 },
  resultStatTile: { flex: 1, backgroundColor: "#fff", borderRadius: 6, padding: 8, marginRight: 6, alignItems: "flex-start" },
  resultStatTileLast: { marginRight: 0 },
  resultStatLabel: { fontSize: 6.5, color: COLORS.sub, marginBottom: 2 },
  resultStatValue: { fontSize: 13, fontFamily: "Helvetica-Bold", color: COLORS.good },
  timelineRow: { flexDirection: "row" },
  timelineCol: { flex: 1, marginRight: 10 },
  timelineColLast: { marginRight: 0 },
  timelineHeadWrap: { alignItems: "center", marginBottom: 8 },
  timelineNumber: { width: 24, height: 24, borderRadius: 12, backgroundColor: COLORS.brand, alignItems: "center", justifyContent: "center", marginBottom: 4 },
  timelineNumberText: { fontSize: 11, fontFamily: "Helvetica-Bold", color: "#fff" },
  timelinePhase: { fontSize: 9, fontFamily: "Helvetica-Bold", textAlign: "center" },
  timelineCard: { backgroundColor: "#f8fafc", borderRadius: 6, padding: 8, borderTopWidth: 3, borderTopColor: COLORS.brand },
  timelineBulletRow: { flexDirection: "row", marginBottom: 4, alignItems: "flex-start" },
  timelineBulletText: { flex: 1, fontSize: 7.8, lineHeight: 1.35 },
  scenarioCardsRow: { flexDirection: "row", marginBottom: 14 },
  scenarioCard: { flex: 1, borderWidth: 1, borderColor: COLORS.line, borderRadius: 8, marginRight: 8, overflow: "hidden" },
  scenarioCardLast: { marginRight: 0 },
  scenarioCardHead: { padding: 8, borderTopWidth: 4 },
  scenarioCardLabel: { fontSize: 9.5, fontFamily: "Helvetica-Bold", color: "#fff" },
  scenarioCardBody: { padding: 10 },
  scenarioBigLabel: { fontSize: 7, color: COLORS.sub, marginBottom: 2 },
  scenarioBigValue: { fontSize: 16, fontFamily: "Helvetica-Bold", marginBottom: 8 },
  scenarioSubGrid: { flexDirection: "row", flexWrap: "wrap" },
  scenarioSubItem: { width: "50%", marginBottom: 6 },
  scenarioSubLabel: { fontSize: 6.5, color: COLORS.sub },
  scenarioSubValue: { fontSize: 9.5, fontFamily: "Helvetica-Bold" },
});

function Header({ consultant }: { consultant: ReportData["consultant"] }) {
  return (
    <View style={s.headerRow} fixed>
      <View style={{ flexDirection: "row", alignItems: "center" }}>
        {consultant.logoUrl && (
          // eslint-disable-next-line jsx-a11y/alt-text -- this is @react-pdf/renderer's Image, not an HTML <img>
          <Image src={consultant.logoUrl} style={{ width: 20, height: 20, marginRight: 6, objectFit: "contain" }} />
        )}
        <Text style={s.brandTitle}>{consultant.companyName}</Text>
      </View>
      <Text style={{ fontSize: 8, color: COLORS.faint }}>{consultant.consultantName}</Text>
    </View>
  );
}

function Footer({ page, total, consultant }: { page: number; total: number; consultant: ReportData["consultant"] }) {
  return (
    <View style={s.footer} fixed>
      <Text>
        {consultant.companyName} · {consultant.website || consultant.email || ""}
      </Text>
      <Text>Page {page} of {total}</Text>
    </View>
  );
}

function scoreColor(score: number) {
  if (score < 40) return COLORS.bad;
  if (score < 65) return COLORS.warn;
  return COLORS.good;
}

// A ring/donut score gauge drawn with react-pdf's SVG primitives — vector
// shapes, not font glyphs, so (unlike text icons) there's no WinAnsi/CP1252
// encoding risk (see the ₹/≈/→ bugs fixed earlier in this app's history).
function ScoreGauge({ score, size = 72, sublabel }: { score: number; size?: number; sublabel?: string }) {
  const strokeWidth = 8;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const pct = Math.max(0, Math.min(100, score)) / 100;
  const dash = circumference * pct;
  const color = scoreColor(score);
  const center = size / 2;
  return (
    <View style={{ width: size, height: size, position: "relative", alignItems: "center", justifyContent: "center" }}>
      <Svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <Circle cx={center} cy={center} r={radius} stroke={COLORS.line} strokeWidth={strokeWidth} fill="none" />
        {dash > 0 && (
          // A zero-length dash array (score === 0 — e.g. a "no website"
          // lead, which has no audit checks to score at all and defaults to
          // 0 in build-report-data.ts) makes react-pdf's SVG renderer throw
          // ("dash([0, circumference]) invalid, lengths must be numeric and
          // greater than zero") and fails the whole PDF generation request.
          // At score 0 there's nothing to show anyway — an empty progress
          // ring is the correct rendering, not a missing one — so the
          // progress arc is simply skipped rather than drawn with a 0 dash.
          <G transform={`rotate(-90 ${center} ${center})`}>
            <Circle
              cx={center}
              cy={center}
              r={radius}
              stroke={color}
              strokeWidth={strokeWidth}
              fill="none"
              strokeDasharray={`${dash} ${circumference}`}
              strokeLinecap="round"
            />
          </G>
        )}
      </Svg>
      <View style={{ position: "absolute", alignItems: "center" }}>
        <Text style={{ fontSize: size * 0.24, fontFamily: "Helvetica-Bold", color: COLORS.ink }}>{Math.round(score)}</Text>
        {sublabel ? <Text style={{ fontSize: 6, color: COLORS.sub }}>{sublabel}</Text> : null}
      </View>
    </View>
  );
}

// Small vector icon badges (warning / check / trending-up / flag), drawn as
// SVG paths inside a colored circle — same non-fabrication-of-glyphs reason
// as ScoreGauge above: these render identically everywhere, unlike a ✓ or ⚠
// text character which react-pdf's built-in Helvetica font can't display.
function IconBadge({ icon, color, size = 22 }: { icon: "warn" | "check" | "up" | "flag"; color: string; size?: number }) {
  const iconSize = size * 0.58;
  const offset = (size - iconSize) / 2;
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: color, alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
      <Svg width={iconSize} height={iconSize} viewBox="0 0 24 24" style={{ position: "absolute", left: offset, top: offset }}>
        {icon === "check" && (
          <Path d="M4 12 L10 18 L20 6" stroke="#fff" strokeWidth={3} fill="none" strokeLinecap="round" strokeLinejoin="round" />
        )}
        {icon === "warn" && (
          <>
            <Circle cx={12} cy={17.5} r={1.6} fill="#fff" />
            <Path d="M12 6 L12 13.5" stroke="#fff" strokeWidth={2.4} strokeLinecap="round" />
          </>
        )}
        {icon === "up" && (
          <Path
            d="M3 16 L10 9 L14 13 L21 5 M15 5 H21 V11"
            stroke="#fff"
            strokeWidth={2.4}
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        )}
        {icon === "flag" && (
          <Path d="M6 3 L6 21 M6 4 L18 4 L15 8 L18 12 L6 12" stroke="#fff" strokeWidth={2} fill="none" strokeLinejoin="round" strokeLinecap="round" />
        )}
      </Svg>
    </View>
  );
}

// Connects the Problem -> Solution -> Result steps with a short vertical
// line and a downward triangle drawn via <Polygon> — this replaces a text
// "↓" arrow character that (like ₹/≈/→ elsewhere in this app) sits outside
// react-pdf's built-in Helvetica/WinAnsi font and rendered as a garbled
// glyph. A vector shape has no encoding to get wrong.
function StepConnector() {
  return (
    <View style={{ alignItems: "center", marginVertical: 3, marginLeft: 15 }}>
      <View style={{ width: 2, height: 12, backgroundColor: COLORS.brand }} />
      <Svg width={11} height={7} viewBox="0 0 11 7">
        <Polygon points="0,0 11,0 5.5,7" fill={COLORS.brand} />
      </Svg>
    </View>
  );
}

function StatTile({ label, value, sub, color, last }: { label: string; value: string; sub?: string; color?: string; last?: boolean }) {
  return (
    <View style={[s.statTile, last ? s.statTileLast : undefined]}>
      <Text style={s.statLabel}>{label}</Text>
      <Text style={[s.statValue, { color: color ?? COLORS.ink }]}>{value}</Text>
      {sub ? <Text style={s.statSub}>{sub}</Text> : null}
    </View>
  );
}

export function ReportDocument({ data }: { data: ReportData }) {
  const { consultant, business, executiveSummary, websiteRecommendations, auditScores, competitorInsights, competitorSites, audiencePlatform, sampleAds, scenarios, growthPlan, problemSolutionStory } = data;
  const competitorRows = competitorSites ? [...(competitorSites.client ? [competitorSites.client] : []), ...competitorSites.competitors] : [];
  const hasAdCopyPage = sampleAds.some((ad) => ad.searchAd || ad.displayAd || ad.socialAd || ad.videoAd);
  const totalPages = hasAdCopyPage ? 10 : 9;
  const pAdCopy = 7;
  const pBudget = hasAdCopyPage ? 8 : 7;
  const pGrowthPlan = hasAdCopyPage ? 9 : 8;
  const pClosing = hasAdCopyPage ? 10 : 9;

  // The "Expected" scenario is what the hero stats and the Problem/Solution/
  // Result page's result numbers are drawn from — found by label rather than
  // array position since the scenarios array's stored order isn't guaranteed.
  const expectedScenario = scenarios.find((sc) => sc.label.toLowerCase().includes("expected")) ?? scenarios[0] ?? null;

  // Scenario cards always read Conservative -> Expected -> Growth Opportunity
  // left to right, regardless of the order scenarios came back from the DB —
  // the detailed table further down keeps the original order untouched.
  const tierOrder = ["conservative", "expected", "growth opportunity"];
  const orderedScenarios = [...scenarios].sort((a, b) => {
    const ai = tierOrder.indexOf(a.label.toLowerCase());
    const bi = tierOrder.indexOf(b.label.toLowerCase());
    return (ai === -1 ? 99 : ai) - (bi === -1 ? 99 : bi);
  });
  const maxRevenue = Math.max(1, ...scenarios.map((sc) => sc.revenue));
  const scenarioTierColor = (label: string) => {
    const l = label.toLowerCase();
    if (l.includes("growth")) return COLORS.good;
    if (l.includes("expected")) return COLORS.brand;
    return COLORS.slate;
  };

  return (
    <Document title={`${business.businessName} — Digital Growth Report`} author={consultant.companyName}>
      {/* PAGE 1 — EXECUTIVE SUMMARY / COVER */}
      <Page size="A4" style={s.page}>
        <Header consultant={consultant} />
        <Text style={s.pageTitle}>Digital Growth &amp; Lead Conversion Report</Text>
        <Text style={s.pageSubtitle}>
          Prepared for {business.customerName} · {business.businessName} · {data.generatedDate}
        </Text>

        <View style={s.heroRow}>
          {auditScores ? (
            <View style={[s.statTile, { flexDirection: "row", alignItems: "center" }]}>
              <ScoreGauge score={auditScores.overall} size={54} />
              <View style={{ marginLeft: 8, flex: 1 }}>
                <Text style={s.statLabel}>Website Score</Text>
                <Text style={{ fontSize: 8, color: COLORS.sub, lineHeight: 1.3 }}>out of 100</Text>
              </View>
            </View>
          ) : (
            <StatTile label="Website Score" value="N/A" sub="No live audit for this lead" />
          )}
          {expectedScenario ? (
            <>
              <StatTile
                label="Projected Monthly Customers"
                value={formatNumber(Math.round(expectedScenario.customers))}
                sub={`at ${formatCurrency(expectedScenario.budget, consultant.currency)}/mo · Expected case`}
                color={COLORS.brand}
              />
              <StatTile
                label="Projected ROI"
                value={`${Math.round(expectedScenario.roi)}%`}
                sub="Expected case, this budget"
                color={COLORS.good}
                last
              />
            </>
          ) : (
            <StatTile label="Projected Results" value="Set a budget" sub="to see customer &amp; ROI projections" last />
          )}
        </View>

        <View style={[s.calloutCard, { backgroundColor: COLORS.brandSoft, flexDirection: "column", alignItems: "stretch" }]}>
          <Text style={{ fontSize: 9, fontFamily: "Helvetica-Bold", marginBottom: 4 }}>Current Situation</Text>
          <Text style={s.bodyText}>{executiveSummary.currentSituation}</Text>
        </View>

        <Text style={s.sectionLabel}>Key Problems Affecting Growth</Text>
        <View style={s.problemGrid}>
          {executiveSummary.problems.slice(0, 6).map((p, i) => (
            <View style={s.problemCard} key={i}>
              <IconBadge icon="warn" color={COLORS.bad} size={18} />
              <Text style={s.problemCardText}>{p}</Text>
            </View>
          ))}
        </View>

        <View style={[s.calloutCard, { backgroundColor: COLORS.goodSoft, marginTop: 6 }]}>
          <IconBadge icon="flag" color={COLORS.good} size={20} />
          <View style={{ flex: 1, marginLeft: 9 }}>
            <Text style={[s.calloutLabel, { color: COLORS.good }]}>Biggest Growth Opportunity</Text>
            <Text style={s.bodyText}>{executiveSummary.biggestOpportunity}</Text>
          </View>
        </View>

        <View style={[s.calloutCard, { backgroundColor: COLORS.brandSoft }]}>
          <IconBadge icon="up" color={COLORS.brand} size={20} />
          <View style={{ flex: 1, marginLeft: 9 }}>
            <Text style={[s.calloutLabel, { color: COLORS.brand }]}>Recommended Direction</Text>
            <Text style={s.bodyText}>{executiveSummary.recommendedDirection}</Text>
          </View>
        </View>

        <Footer page={1} total={totalPages} consultant={consultant} />
      </Page>

      {/* PAGE 2 — PROBLEM -> SOLUTION -> RESULT (the persuasive narrative arc) */}
      <Page size="A4" style={s.page}>
        <Header consultant={consultant} />
        <Text style={s.pageTitle}>Problem -&gt; Solution -&gt; Result</Text>
        <Text style={s.pageSubtitle}>The story in three steps — why {business.businessName} is losing growth today, what changes, and what that&apos;s worth.</Text>

        <View style={s.stepRow}>
          <IconBadge icon="warn" color={COLORS.bad} size={26} />
          <View style={[s.stepCard, { backgroundColor: COLORS.badSoft }]}>
            <Text style={[s.stepLabel, { color: COLORS.bad }]}>1 · The Problem</Text>
            <Text style={s.stepText}>{problemSolutionStory.problem}</Text>
          </View>
        </View>
        <StepConnector />
        <View style={s.stepRow}>
          <IconBadge icon="check" color={COLORS.warn} size={26} />
          <View style={[s.stepCard, { backgroundColor: COLORS.warnSoft }]}>
            <Text style={[s.stepLabel, { color: COLORS.warn }]}>2 · The Solution</Text>
            <Text style={s.stepText}>{problemSolutionStory.solution}</Text>
          </View>
        </View>
        <StepConnector />
        <View style={s.stepRow}>
          <IconBadge icon="up" color={COLORS.good} size={26} />
          <View style={[s.stepCard, { backgroundColor: COLORS.goodSoft }]}>
            <Text style={[s.stepLabel, { color: COLORS.good }]}>3 · The Result</Text>
            <Text style={s.stepText}>{problemSolutionStory.expectedResult}</Text>

            {expectedScenario ? (
              <View style={s.resultStatsRow}>
                <View style={s.resultStatTile}>
                  <Text style={s.resultStatLabel}>Expected Customers/mo</Text>
                  <Text style={s.resultStatValue}>{formatNumber(Math.round(expectedScenario.customers))}</Text>
                </View>
                <View style={s.resultStatTile}>
                  <Text style={s.resultStatLabel}>Expected Revenue/mo</Text>
                  <Text style={s.resultStatValue}>{formatCurrency(Math.round(expectedScenario.revenue), consultant.currency)}</Text>
                </View>
                <View style={[s.resultStatTile, s.resultStatTileLast]}>
                  <Text style={s.resultStatLabel}>Expected ROI</Text>
                  <Text style={s.resultStatValue}>{Math.round(expectedScenario.roi)}%</Text>
                </View>
              </View>
            ) : null}
          </View>
        </View>

        <Text style={{ fontSize: 8, color: COLORS.faint, marginTop: 14 }}>
          Result figures are scenario-based estimates from the budget and benchmarks on the Budget &amp; Scenario Projections page — see page {pBudget} for the full breakdown, including Conservative and Growth Opportunity cases.
        </Text>

        <Footer page={2} total={totalPages} consultant={consultant} />
      </Page>

      {/* PAGE 3 — WEBSITE RECOMMENDATIONS */}
      <Page size="A4" style={s.page}>
        <Header consultant={consultant} />
        <Text style={s.pageTitle}>Website Recommendations</Text>
        {websiteRecommendations.hasWebsite ? (
          <>
            <Text style={s.sectionLabel}>Top Website Problems</Text>
            {websiteRecommendations.topProblems.map((p, i) => (
              <View style={s.bulletRow} key={i}>
                <Text style={s.bulletDot}>•</Text>
                <Text style={s.bulletText}>{p}</Text>
              </View>
            ))}
            {websiteRecommendations.growthRecommendations ? (
              (
                [
                  ["Increase Traffic", websiteRecommendations.growthRecommendations.traffic],
                  ["Strengthen Branding", websiteRecommendations.growthRecommendations.branding],
                  ["Extend Reach", websiteRecommendations.growthRecommendations.reach],
                ] as [string, string[]][]
              ).map(([label, items]) =>
                items.length === 0 ? null : (
                  <View key={label} style={{ marginBottom: 8 }}>
                    <Text style={s.sectionLabel}>{label}</Text>
                    {items.map((p, i) => (
                      <View style={s.bulletRow} key={i}>
                        <Text style={s.bulletDot}>•</Text>
                        <Text style={s.bulletText}>{p}</Text>
                      </View>
                    ))}
                  </View>
                )
              )
            ) : (
              <>
                <Text style={s.sectionLabel}>Recommended Improvements</Text>
                {websiteRecommendations.recommendedImprovements.map((p, i) => (
                  <View style={s.bulletRow} key={i}>
                    <Text style={s.bulletDot}>•</Text>
                    <Text style={s.bulletText}>{p}</Text>
                  </View>
                ))}
              </>
            )}

            {websiteRecommendations.offPageMetrics ? (
              <View style={s.card}>
                <Text style={{ fontSize: 9, fontFamily: "Helvetica-Bold", marginBottom: 4 }}>Off-Page &amp; Traffic Snapshot</Text>
                <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
                  {(
                    [
                      ["Domain Authority / Rating", websiteRecommendations.offPageMetrics.domainAuthority],
                      ["Total Backlinks", websiteRecommendations.offPageMetrics.totalBacklinks],
                      ["Referring Domains", websiteRecommendations.offPageMetrics.referringDomains],
                      ["Est. Monthly Organic Traffic", websiteRecommendations.offPageMetrics.estimatedOrganicTraffic],
                    ] as [string, string | undefined][]
                  )
                    .filter(([, v]) => v)
                    .map(([label, value]) => (
                      <View key={label} style={{ width: "50%", marginBottom: 4 }}>
                        <Text style={{ fontSize: 8, color: COLORS.sub }}>{label}</Text>
                        <Text style={{ fontSize: 10, fontFamily: "Helvetica-Bold" }}>{value}</Text>
                      </View>
                    ))}
                </View>
                {websiteRecommendations.offPageMetrics.source ? (
                  <Text style={{ fontSize: 7, color: COLORS.faint, marginTop: 2 }}>Source: {websiteRecommendations.offPageMetrics.source}</Text>
                ) : null}
              </View>
            ) : null}

            {websiteRecommendations.strategicRecommendations && websiteRecommendations.strategicRecommendations.length > 0 && (
              <>
                <Text style={s.sectionLabel}>Strategic Next Steps — Off-Page, Link Building &amp; Content</Text>
                {websiteRecommendations.strategicRecommendations.map((p, i) => (
                  <View style={s.bulletRow} key={i}>
                    <Text style={s.bulletDot}>•</Text>
                    <Text style={s.bulletText}>{p}</Text>
                  </View>
                ))}
              </>
            )}
          </>
        ) : (
          <>
            <Text style={s.sectionLabel}>Recommended Website Type</Text>
            <Text style={s.bodyText}>{websiteRecommendations.recommendedWebsiteType ?? "Lead-generation website"}</Text>
            {websiteRecommendations.recommendedWebsiteTypeDescription ? (
              <Text style={[s.subText, { marginTop: 2, marginBottom: 6 }]}>{websiteRecommendations.recommendedWebsiteTypeDescription}</Text>
            ) : null}
            <Text style={s.sectionLabel}>Recommended Pages</Text>
            {(websiteRecommendations.recommendedPages ?? []).map((p, i) => (
              <View style={s.bulletRow} key={i}>
                <Text style={s.bulletDot}>•</Text>
                <Text style={s.bulletText}>{p}</Text>
              </View>
            ))}
            {websiteRecommendations.onlinePresenceChannels && websiteRecommendations.onlinePresenceChannels.length > 0 && (
              <View style={{ marginTop: 8 }}>
                <Text style={s.sectionLabel}>
                  Online Presence While the Website Is Being Built
                  {websiteRecommendations.businessType ? ` (${websiteRecommendations.businessType})` : ""}
                </Text>
                {websiteRecommendations.onlinePresenceChannels.map((c, i) => (
                  <View style={s.bulletRow} key={i}>
                    <Text style={s.bulletDot}>•</Text>
                    <Text style={s.bulletText}>{c}</Text>
                  </View>
                ))}
              </View>
            )}
          </>
        )}

        {websiteRecommendations.localPresence ? (
          <View style={s.card}>
            <Text style={{ fontSize: 9, fontFamily: "Helvetica-Bold", marginBottom: 4 }}>
              Local Presence — {websiteRecommendations.localPresence.storeLocations.length} Location
              {websiteRecommendations.localPresence.storeLocations.length === 1 ? "" : "s"}
            </Text>
            {websiteRecommendations.localPresence.storeLocations.map((url, i) => (
              <Text key={url + i} style={{ fontSize: 8, color: COLORS.sub, marginBottom: 2 }}>
                {i === 0 ? "Main store: " : `Location ${i + 1}: `}
                {url}
              </Text>
            ))}
            {websiteRecommendations.localPresence.notes ? (
              <Text style={{ fontSize: 8, marginTop: 4, lineHeight: 1.4 }}>{websiteRecommendations.localPresence.notes}</Text>
            ) : null}
            {websiteRecommendations.localPresence.recommendations && websiteRecommendations.localPresence.recommendations.length > 0 ? (
              <>
                <Text style={{ fontSize: 8, fontFamily: "Helvetica-Bold", marginTop: 6, marginBottom: 3 }}>
                  Recommended Local Branding Improvements (Google Business Profile)
                </Text>
                {websiteRecommendations.localPresence.recommendations.map((r, i) => (
                  <View style={s.bulletRow} key={i}>
                    <Text style={s.bulletDot}>•</Text>
                    <Text style={s.bulletText}>{r}</Text>
                  </View>
                ))}
              </>
            ) : null}
          </View>
        ) : null}

        {websiteRecommendations.socialPresence ? (
          <View style={s.card}>
            <Text style={{ fontSize: 9, fontFamily: "Helvetica-Bold", marginBottom: 4 }}>Social Media Presence</Text>
            {(
              [
                ["Facebook", websiteRecommendations.socialPresence.facebook, websiteRecommendations.socialPresence.metrics?.facebook],
                ["Instagram", websiteRecommendations.socialPresence.instagram, websiteRecommendations.socialPresence.metrics?.instagram],
                ["LinkedIn", websiteRecommendations.socialPresence.linkedin, websiteRecommendations.socialPresence.metrics?.linkedin],
                ["YouTube", websiteRecommendations.socialPresence.youtube, websiteRecommendations.socialPresence.metrics?.youtube],
              ] as [string, string | undefined, string | undefined][]
            )
              .filter(([, url]) => url)
              .map(([label, url, metrics]) => (
                <View key={label} style={{ marginBottom: 4 }}>
                  <Text style={{ fontSize: 8, color: COLORS.sub }}>
                    {label}: {url}
                  </Text>
                  {metrics ? <Text style={{ fontSize: 7.5, color: COLORS.faint, marginTop: 1 }}>{metrics}</Text> : null}
                </View>
              ))}
          </View>
        ) : null}

        <Footer page={3} total={totalPages} consultant={consultant} />
      </Page>

      {/* PAGE 4 — WEBSITE AUDIT SCORING */}
      <Page size="A4" style={s.page}>
        <Header consultant={consultant} />
        <Text style={s.pageTitle}>Website Audit Scorecard</Text>
        {auditScores ? (
          <View style={{ marginTop: 4 }}>
            <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 16 }}>
              <ScoreGauge score={auditScores.overall} size={64} sublabel="/ 100" />
              <View style={{ marginLeft: 12 }}>
                <Text style={{ fontSize: 13, fontFamily: "Helvetica-Bold" }}>Overall Website Score</Text>
                <Text style={{ fontSize: 9, color: COLORS.sub, marginTop: 2 }}>{auditStatusLabel(auditScores.overall)} — based on 7 weighted categories below.</Text>
              </View>
            </View>
            {(
              [
                ["Technical SEO", auditScores.technicalSeo],
                ["On-Page SEO", auditScores.onPageSeo],
                ["Content", auditScores.content],
                ["UX & Conversion", auditScores.uxConversion],
                ["Branding", auditScores.branding],
                ["Local SEO", auditScores.localSeo],
                ["Performance", auditScores.performance],
              ] as [string, number][]
            ).map(([label, score]) => (
              <View key={label} style={{ marginBottom: 10 }}>
                <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                  <Text style={{ fontSize: 9, fontFamily: "Helvetica-Bold" }}>{label}</Text>
                  <Text style={{ fontSize: 9 }}>
                    {score}/100 — {auditStatusLabel(score)}
                  </Text>
                </View>
                <View style={s.scoreBarTrack}>
                  <View style={[s.scoreBarFill, { width: `${score}%`, backgroundColor: scoreColor(score) }]} />
                </View>
              </View>
            ))}
          </View>
        ) : (
          <Text style={s.subText}>Data unavailable – requires external tool/account access.</Text>
        )}
        <Footer page={4} total={totalPages} consultant={consultant} />
      </Page>

      {/* PAGE 5 — COMPETITOR INSIGHTS */}
      <Page size="A4" style={s.page}>
        <Header consultant={consultant} />
        <Text style={s.pageTitle}>Competitor Insights</Text>
        <Text style={s.pageSubtitle}>Live research on each competitor&apos;s own site — no estimated or sample data.</Text>

        {competitorRows.length > 0 ? (
          <View style={[s.table, { marginBottom: 12 }]}>
            <View style={s.tr}>
              <Text style={s.thCell}>Site</Text>
              <Text style={s.thCell}>Words</Text>
              <Text style={s.thCell}>Blog</Text>
              <Text style={s.thCell}>Schema</Text>
              <Text style={s.thCell}>Mobile</Text>
              <Text style={s.thCell}>HTTPS</Text>
              <Text style={s.thCell}>Platform</Text>
            </View>
            {competitorRows.map((c, idx) => (
              <View style={idx === competitorRows.length - 1 ? s.trLast : s.tr} key={c.hostname + idx}>
                <Text style={s.tdCell}>{idx === 0 && competitorSites?.client ? "Your client" : c.hostname}</Text>
                {c.fetchedOk ? (
                  <>
                    <Text style={s.tdCell}>{c.wordCount}</Text>
                    <Text style={s.tdCell}>{c.hasBlog ? "Yes" : "No"}</Text>
                    <Text style={s.tdCell}>{c.hasSchema ? "Yes" : "No"}</Text>
                    <Text style={s.tdCell}>{c.hasViewport ? "Yes" : "No"}</Text>
                    <Text style={s.tdCell}>{c.https ? "Yes" : "No"}</Text>
                    <Text style={s.tdCell}>{c.techPlatform}</Text>
                  </>
                ) : (
                  <Text style={[s.tdCell, { flex: 5 }]}>Not reachable</Text>
                )}
              </View>
            ))}
          </View>
        ) : null}

        <Text style={s.sectionLabel}>Insights &amp; Recommendations</Text>
        {competitorInsights.length > 0 ? (
          competitorInsights.map((c, i) => (
            <View style={s.bulletRow} key={i}>
              <Text style={s.bulletDot}>•</Text>
              <Text style={s.bulletText}>{c}</Text>
            </View>
          ))
        ) : (
          <Text style={s.subText}>Competitor data unavailable — no competitor URLs were analyzed.</Text>
        )}
        <Footer page={5} total={totalPages} consultant={consultant} />
      </Page>

      {/* PAGE 6 — TARGET AUDIENCE, PLATFORMS & VISUAL SAMPLE ADVERTISEMENTS */}
      <Page size="A4" style={s.page}>
        <Header consultant={consultant} />
        <Text style={s.pageTitle}>Target Audience, Platforms &amp; Sample Ads</Text>

        <Text style={s.sectionLabel}>Target Audience</Text>
        <Text style={s.bodyText}>{audiencePlatform.targetAudience}</Text>

        {audiencePlatform.platforms.length > 0 && (
          <>
            <Text style={s.sectionLabel}>Recommended Platforms &amp; Ad Types</Text>
            {audiencePlatform.platforms.map((p, i) => (
              <View key={i} style={{ marginBottom: 6 }}>
                <Text style={{ fontSize: 9, fontFamily: "Helvetica-Bold" }}>{p.platform}{p.adType ? ` — ${p.adType}` : ""}</Text>
                {p.expectedResult ? <Text style={s.subText}>Expected result: {p.expectedResult}</Text> : null}
              </View>
            ))}
          </>
        )}

        {audiencePlatform.platforms.some((p) => p.budgetAllocation || p.estimatedResult) && (
          <>
            <Text style={s.sectionLabel}>Suggested Campaign Budget Allocation</Text>
            {audiencePlatform.platforms.map((p, i) => (
              <View key={i} style={{ marginBottom: 6 }}>
                <Text style={{ fontSize: 9, fontFamily: "Helvetica-Bold" }}>{p.platform}</Text>
                {p.budgetAllocation ? <Text style={s.subText}>Suggested budget: {p.budgetAllocation}</Text> : null}
                {p.estimatedResult ? <Text style={s.subText}>At this spend: {p.estimatedResult}</Text> : null}
              </View>
            ))}
          </>
        )}

        <Text style={[s.pageSubtitle, { marginTop: 10 }]}>Sample ad concepts based on {business.businessName}&apos;s actual products/services.</Text>
        <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between" }}>
          {sampleAds.map((ad, i) => (
            <View key={i} style={s.adCard}>
              <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 3 }}>
                <Text style={[s.chip, { marginBottom: 0, marginRight: 4 }]}>{ad.platform}</Text>
                {ad.format ? <Text style={{ fontSize: 7, color: COLORS.sub }}>{ad.format}</Text> : null}
              </View>
              {ad.adType ? <Text style={{ fontSize: 7, color: COLORS.faint, marginBottom: 3 }}>{ad.adType}</Text> : null}
              {ad.imageDataUrl ? (
                // eslint-disable-next-line jsx-a11y/alt-text -- this is @react-pdf/renderer's Image, not an HTML <img>
                <Image src={ad.imageDataUrl} style={{ width: "100%", borderRadius: 4, marginBottom: 5 }} />
              ) : ad.referenceImageUrl ? (
                <View style={{ marginBottom: 5 }}>
                  {/* eslint-disable-next-line jsx-a11y/alt-text -- this is @react-pdf/renderer's Image, not an HTML <img> */}
                  <Image src={ad.referenceImageUrl} style={{ width: "100%", borderRadius: 4 }} />
                  <Text style={{ fontSize: 6, color: COLORS.faint, marginTop: 2 }}>Reference photo from {ad.referenceImageSource} — for visual inspiration only.</Text>
                </View>
              ) : null}
              <Text style={{ fontSize: 11, fontFamily: "Helvetica-Bold", marginBottom: 4 }}>{ad.headline}</Text>
              {ad.benefit ? <Text style={{ fontSize: 8, color: COLORS.sub, marginBottom: 6 }}>{ad.benefit}</Text> : null}
              {ad.videoScript ? (
                <View style={{ marginBottom: 6 }}>
                  <Text style={{ fontSize: 7, color: COLORS.sub, marginBottom: 2 }}>
                    <Text style={{ fontFamily: "Helvetica-Bold" }}>Hook: </Text>
                    {ad.videoScript.hook}
                  </Text>
                  <Text style={{ fontSize: 7, color: COLORS.sub, marginBottom: 2 }}>
                    <Text style={{ fontFamily: "Helvetica-Bold" }}>Story: </Text>
                    {ad.videoScript.story}
                  </Text>
                  <Text style={{ fontSize: 7, color: COLORS.sub }}>
                    <Text style={{ fontFamily: "Helvetica-Bold" }}>Closing: </Text>
                    {ad.videoScript.cta}
                  </Text>
                </View>
              ) : null}
              {/* "->" not "→" — see the WinAnsi/CP1252 note on StepConnector above; a
                  literal → arrow here previously rendered as a garbled stray mark. */}
              <Text style={{ fontSize: 8, color: COLORS.brand, fontFamily: "Helvetica-Bold" }}>{ad.cta} -&gt;</Text>
            </View>
          ))}
        </View>
        <Footer page={6} total={totalPages} consultant={consultant} />
      </Page>

      {/* PAGE 7 — AD COPY & EXTENSIONS (full platform-specific ad fields) */}
      {hasAdCopyPage && (
        <Page size="A4" style={s.page}>
          <Header consultant={consultant} />
          <Text style={s.pageTitle}>Ad Copy &amp; Extensions</Text>
          <Text style={s.pageSubtitle}>Full field-level ad copy, matching each platform&apos;s actual ad structure — ready to paste into Ads Manager / Google Ads.</Text>

          {sampleAds.map((ad, i) => {
            if (!ad.searchAd && !ad.displayAd && !ad.socialAd && !ad.videoAd) return null;
            return (
              <View key={i} style={{ marginBottom: 12, borderWidth: 1, borderColor: COLORS.line, borderRadius: 4, padding: 8 }} wrap={false}>
                <Text style={{ fontSize: 10, fontFamily: "Helvetica-Bold", color: COLORS.brand, marginBottom: 4 }}>
                  {ad.platform} — {ad.format}
                </Text>

                {ad.searchAd && (
                  <View>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Headlines: </Text>{ad.searchAd.headlines.filter(Boolean).join(" | ")}</Text>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Descriptions: </Text>{ad.searchAd.descriptions.filter(Boolean).join(" | ")}</Text>
                    {ad.searchAd.displayPath.filter(Boolean).length > 0 && (
                      <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Display Path: </Text>/{ad.searchAd.displayPath.filter(Boolean).join("/")}</Text>
                    )}
                    {ad.searchAd.sitelinks.filter((sl) => sl.text).length > 0 && (
                      <Text style={s.subText}>
                        <Text style={{ fontFamily: "Helvetica-Bold" }}>Sitelinks: </Text>
                        {ad.searchAd.sitelinks.filter((sl) => sl.text).map((sl) => `${sl.text} (${sl.description})`).join("  •  ")}
                      </Text>
                    )}
                    {ad.searchAd.callouts.filter(Boolean).length > 0 && (
                      <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Callouts: </Text>{ad.searchAd.callouts.filter(Boolean).join(" | ")}</Text>
                    )}
                    {ad.searchAd.structuredSnippetValues.filter(Boolean).length > 0 && (
                      <Text style={s.subText}>
                        <Text style={{ fontFamily: "Helvetica-Bold" }}>{ad.searchAd.structuredSnippetHeader}: </Text>
                        {ad.searchAd.structuredSnippetValues.filter(Boolean).join(", ")}
                      </Text>
                    )}
                  </View>
                )}

                {ad.displayAd && (
                  <View>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Short Headlines: </Text>{ad.displayAd.headlines.filter(Boolean).join(" | ")}</Text>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Long Headline: </Text>{ad.displayAd.longHeadline}</Text>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Descriptions: </Text>{ad.displayAd.descriptions.filter(Boolean).join(" | ")}</Text>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Business Name: </Text>{ad.displayAd.businessName}</Text>
                  </View>
                )}

                {ad.socialAd && (
                  <View>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Primary Text: </Text>{ad.socialAd.primaryText}</Text>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Headline: </Text>{ad.socialAd.headline}</Text>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Description: </Text>{ad.socialAd.description}</Text>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>CTA Button: </Text>{ad.socialAd.ctaButton}</Text>
                  </View>
                )}

                {ad.videoAd && (
                  <View>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Companion Banner Headline: </Text>{ad.videoAd.companionHeadline}</Text>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Companion Banner Description: </Text>{ad.videoAd.companionDescription}</Text>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>CTA Button: </Text>{ad.videoAd.ctaButton}</Text>
                  </View>
                )}
              </View>
            );
          })}
          <Footer page={pAdCopy} total={totalPages} consultant={consultant} />
        </Page>
      )}

      {/* PAGE 8 — BUDGET & SCENARIO PROJECTIONS */}
      <Page size="A4" style={s.page}>
        <Header consultant={consultant} />
        <Text style={s.pageTitle}>Budget &amp; Scenario Projections</Text>
        <Text style={s.pageSubtitle}>Three ways this could play out on the same monthly budget.</Text>

        <View style={s.scenarioCardsRow}>
          {orderedScenarios.map((sc, i) => {
            const color = scenarioTierColor(sc.label);
            const barPct = Math.max(4, Math.round((sc.revenue / maxRevenue) * 100));
            return (
              <View key={sc.label} style={[s.scenarioCard, i === orderedScenarios.length - 1 ? s.scenarioCardLast : undefined]}>
                <View style={[s.scenarioCardHead, { borderTopColor: color, backgroundColor: color }]}>
                  <Text style={s.scenarioCardLabel}>{sc.label}</Text>
                </View>
                <View style={s.scenarioCardBody}>
                  <Text style={s.scenarioBigLabel}>Monthly Revenue</Text>
                  <Text style={[s.scenarioBigValue, { color }]}>{formatCurrency(Math.round(sc.revenue), consultant.currency)}</Text>
                  <View style={s.scoreBarTrack}>
                    <View style={[s.scoreBarFill, { width: `${barPct}%`, backgroundColor: color }]} />
                  </View>
                  <View style={[s.scenarioSubGrid, { marginTop: 10 }]}>
                    <View style={s.scenarioSubItem}>
                      <Text style={s.scenarioSubLabel}>Customers/mo</Text>
                      <Text style={s.scenarioSubValue}>{formatNumber(Math.round(sc.customers))}</Text>
                    </View>
                    <View style={s.scenarioSubItem}>
                      <Text style={s.scenarioSubLabel}>ROAS</Text>
                      <Text style={s.scenarioSubValue}>{sc.roas.toFixed(2)}X</Text>
                    </View>
                    <View style={s.scenarioSubItem}>
                      <Text style={s.scenarioSubLabel}>ROI</Text>
                      <Text style={s.scenarioSubValue}>{sc.roi.toFixed(0)}%</Text>
                    </View>
                    <View style={s.scenarioSubItem}>
                      <Text style={s.scenarioSubLabel}>Cost/Customer</Text>
                      <Text style={s.scenarioSubValue}>{formatCurrency(sc.cac, consultant.currency)}</Text>
                    </View>
                  </View>
                </View>
              </View>
            );
          })}
        </View>

        <Text style={s.sectionLabel}>Full Metric Breakdown</Text>
        <View style={s.table}>
          <View style={s.tr}>
            <Text style={s.thCell}>Metric</Text>
            {scenarios.map((sc) => (
              <Text style={s.thCell} key={sc.label}>
                {sc.label}
              </Text>
            ))}
          </View>
          {(
            [
              ["Budget", (sc: (typeof scenarios)[number]) => formatCurrency(sc.budget, consultant.currency)],
              ["Traffic/Clicks", (sc: (typeof scenarios)[number]) => Math.round(sc.traffic).toLocaleString()],
              ["Leads", (sc: (typeof scenarios)[number]) => Math.round(sc.leads).toLocaleString()],
              ["Qualified Leads", (sc: (typeof scenarios)[number]) => Math.round(sc.qualifiedLeads).toLocaleString()],
              ["Customers", (sc: (typeof scenarios)[number]) => Math.round(sc.customers).toLocaleString()],
              ["Revenue", (sc: (typeof scenarios)[number]) => formatCurrency(Math.round(sc.revenue), consultant.currency)],
              ["CPL", (sc: (typeof scenarios)[number]) => formatCurrency(sc.cpl, consultant.currency)],
              ["CAC", (sc: (typeof scenarios)[number]) => formatCurrency(sc.cac, consultant.currency)],
              ["ROAS", (sc: (typeof scenarios)[number]) => `${sc.roas.toFixed(2)}X`],
              ["ROI", (sc: (typeof scenarios)[number]) => `${sc.roi.toFixed(0)}%`],
            ] as [string, (sc: (typeof scenarios)[number]) => string][]
          ).map(([label, fmt], idx, arr) => (
            <View style={idx === arr.length - 1 ? s.trLast : s.tr} key={label}>
              <Text style={s.tdCell}>{label}</Text>
              {scenarios.map((sc) => (
                <Text style={s.tdCell} key={sc.label + label}>
                  {fmt(sc)}
                </Text>
              ))}
            </View>
          ))}
        </View>
        <Text style={{ fontSize: 8, color: COLORS.sub, marginTop: 10 }}>
          These are scenario-based estimates. Actual results may vary.
        </Text>
        <Text style={{ fontSize: 7, color: COLORS.faint, marginTop: 4 }}>{data.benchmarkDisclaimer}</Text>
        <Footer page={pBudget} total={totalPages} consultant={consultant} />
      </Page>

      {/* PAGE 9 — 30/60/90 GROWTH PLAN */}
      <Page size="A4" style={s.page}>
        <Header consultant={consultant} />
        <Text style={s.pageTitle}>30 / 60 / 90-Day Growth Plan</Text>
        <Text style={s.pageSubtitle}>{problemSolutionStory.execution}</Text>

        <View style={s.timelineRow}>
          {growthPlan.map((phase, i) => (
            <View key={phase.phase} style={[s.timelineCol, i === growthPlan.length - 1 ? s.timelineColLast : undefined]}>
              <View style={s.timelineHeadWrap}>
                <View style={s.timelineNumber}>
                  <Text style={s.timelineNumberText}>{i + 1}</Text>
                </View>
                <Text style={s.timelinePhase}>{phase.phase}</Text>
              </View>
              <View style={s.timelineCard}>
                {phase.items.map((item, j) => (
                  <View style={s.timelineBulletRow} key={j}>
                    <IconBadge icon="check" color={COLORS.brand} size={11} />
                    <Text style={[s.timelineBulletText, { marginLeft: 5 }]}>{item}</Text>
                  </View>
                ))}
              </View>
            </View>
          ))}
        </View>

        <Footer page={pGrowthPlan} total={totalPages} consultant={consultant} />
      </Page>

      {/* PAGE 10 — CLOSING / CALL TO ACTION */}
      <Page size="A4" style={s.page}>
        <Header consultant={consultant} />
        <Text style={s.pageTitle}>Ready to Grow, {business.businessName}?</Text>

        <View style={[s.calloutCard, { backgroundColor: COLORS.brandSoft }]}>
          <IconBadge icon="flag" color={COLORS.brand} size={20} />
          <View style={{ flex: 1, marginLeft: 9 }}>
            <Text style={[s.calloutLabel, { color: COLORS.brand }]}>Our Approach</Text>
            <Text style={s.bodyText}>{problemSolutionStory.strategy}</Text>
          </View>
        </View>

        {expectedScenario ? (
          <View style={s.resultStatsRow}>
            <View style={[s.resultStatTile, { backgroundColor: COLORS.slateSoft }]}>
              <Text style={s.resultStatLabel}>Expected Customers/mo</Text>
              <Text style={[s.resultStatValue, { color: COLORS.ink }]}>{formatNumber(Math.round(expectedScenario.customers))}</Text>
            </View>
            <View style={[s.resultStatTile, { backgroundColor: COLORS.slateSoft }]}>
              <Text style={s.resultStatLabel}>Expected Revenue/mo</Text>
              <Text style={[s.resultStatValue, { color: COLORS.ink }]}>{formatCurrency(Math.round(expectedScenario.revenue), consultant.currency)}</Text>
            </View>
            <View style={[s.resultStatTile, s.resultStatTileLast, { backgroundColor: COLORS.slateSoft }]}>
              <Text style={s.resultStatLabel}>Expected ROI</Text>
              <Text style={[s.resultStatValue, { color: COLORS.ink }]}>{Math.round(expectedScenario.roi)}%</Text>
            </View>
          </View>
        ) : null}

        <View style={s.divider} />
        <Text style={{ fontSize: 16, fontFamily: "Helvetica-Bold", textAlign: "center", marginVertical: 12 }}>
          {consultant.ctaText}
        </Text>
        <View style={{ alignItems: "center", marginTop: 6 }}>
          <Text style={{ fontSize: 10, fontFamily: "Helvetica-Bold" }}>{consultant.consultantName}</Text>
          <Text style={{ fontSize: 9, color: COLORS.sub }}>{consultant.companyName}</Text>
          {consultant.phone ? <Text style={{ fontSize: 9, color: COLORS.sub }}>{consultant.phone}</Text> : null}
          {consultant.whatsapp ? <Text style={{ fontSize: 9, color: COLORS.sub }}>WhatsApp: {consultant.whatsapp}</Text> : null}
          {consultant.email ? <Text style={{ fontSize: 9, color: COLORS.sub }}>{consultant.email}</Text> : null}
          {consultant.website ? <Text style={{ fontSize: 9, color: COLORS.sub }}>{consultant.website}</Text> : null}
          {consultant.linkedin ? <Text style={{ fontSize: 9, color: COLORS.sub }}>{consultant.linkedin}</Text> : null}
        </View>
        <Footer page={pClosing} total={totalPages} consultant={consultant} />
      </Page>
    </Document>
  );
}
