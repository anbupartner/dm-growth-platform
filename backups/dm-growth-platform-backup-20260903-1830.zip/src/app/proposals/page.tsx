"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { api } from "@/lib/api-client";
import { PageHeading, Card, Badge, Spinner, EmptyState, Input } from "@/components/ui";
import { LEAD_STATUS_LABELS, LEAD_STATUS_COLORS, type LeadStatus } from "@/lib/constants";
import { formatCurrency } from "@/lib/calculations";

interface Lead {
  id: string;
  customerId: string;
  businessName: string;
  customerName: string;
  status: string;
  quoteValue?: number | null;
}

const PROPOSAL_STATUSES = ["PROPOSAL_SENT", "NEGOTIATION", "WON", "LOST"];

export default function ProposalsPage() {
  const [leads, setLeads] = useState<Lead[] | null>(null);

  const load = useCallback(async () => {
    const all = await Promise.all(PROPOSAL_STATUSES.map((s) => api.get<Lead[]>(`/api/leads?status=${s}`)));
    setLeads(all.flat());
  }, []);

  useEffect(() => {
    Promise.all(PROPOSAL_STATUSES.map((s) => api.get<Lead[]>(`/api/leads?status=${s}`))).then((all) => setLeads(all.flat()));
  }, []);

  async function updateQuote(id: string, value: string) {
    await api.patch(`/api/leads/${id}`, { quoteValue: value ? Number(value) : null });
    await load();
  }

  if (!leads) return <div className="flex justify-center py-20"><Spinner /></div>;

  const totalPipeline = leads.filter((l) => l.status !== "WON" && l.status !== "LOST").reduce((s, l) => s + (l.quoteValue ?? 0), 0);
  const totalWon = leads.filter((l) => l.status === "WON").reduce((s, l) => s + (l.quoteValue ?? 0), 0);

  return (
    <div>
      <PageHeading title="Proposals" subtitle="Track proposals, quotes and negotiation status." />

      <div className="grid grid-cols-2 gap-4 mb-6 max-w-md">
        <Card className="p-4">
          <p className="text-xs text-slate-400">Open Proposal Value</p>
          <p className="text-xl font-semibold mt-1">{formatCurrency(totalPipeline)}</p>
        </Card>
        <Card className="p-4">
          <p className="text-xs text-slate-400">Won Value</p>
          <p className="text-xl font-semibold mt-1 text-emerald-600">{formatCurrency(totalWon)}</p>
        </Card>
      </div>

      {leads.length === 0 ? (
        <EmptyState title="No proposals yet" subtitle="Leads move here once their status becomes Proposal Sent or later." />
      ) : (
        <Card className="overflow-hidden">
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {leads.map((lead) => (
              <div key={lead.id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-3">
                <Link href={`/leads/${lead.id}`} className="min-w-0">
                  <p className="text-sm font-medium text-slate-900 dark:text-white truncate">{lead.businessName}</p>
                  <p className="text-xs text-slate-400 truncate">{lead.customerId} · {lead.customerName}</p>
                </Link>
                <div className="flex items-center gap-3">
                  <Badge className={LEAD_STATUS_COLORS[lead.status as LeadStatus]}>{LEAD_STATUS_LABELS[lead.status as LeadStatus]}</Badge>
                  <Input
                    type="number"
                    defaultValue={lead.quoteValue ?? ""}
                    onBlur={(e) => updateQuote(lead.id, e.target.value)}
                    placeholder="Quote value"
                    className="w-32"
                  />
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
