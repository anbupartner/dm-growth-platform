"use client";

import { useEffect, useRef, useState } from "react";
import { api } from "@/lib/api-client";
import { PageHeading, Card, Field, Input, Textarea, Button, Spinner, Select } from "@/components/ui";
import { CURRENCIES } from "@/lib/constants";
import { Trash2 } from "lucide-react";

interface Settings {
  consultantName: string;
  companyName: string;
  phone: string;
  whatsapp: string;
  email: string;
  website: string;
  linkedin: string;
  address: string;
  reportFooter: string;
  ctaText: string;
  currency: string;
  defaultQualificationRate: number;
  aiImageApiKey: string | null;
  logoUrl: string | null;
}

// PNG/JPEG only — @react-pdf/renderer's <Image> (used to show this logo on
// every generated PDF's header) renders raster formats, not SVG. Kept small
// since the logo is stored inline as a data: URI on the consultant_settings
// row (same "no separate file-serving route needed" tradeoff as every other
// small embedded asset in this app, e.g. generated ad images).
const MAX_LOGO_BYTES = 2 * 1024 * 1024; // 2MB

export default function SettingsPage() {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [logoBusy, setLogoBusy] = useState(false);
  const [logoError, setLogoError] = useState<string | null>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    api.get<Settings>("/api/settings").then(setSettings);
  }, []);

  function set<K extends keyof Settings>(key: K, value: Settings[K]) {
    setSettings((s) => (s ? { ...s, [key]: value } : s));
    setSaved(false);
  }

  async function save() {
    if (!settings) return;
    setSaving(true);
    await api.patch("/api/settings", settings);
    setSaving(false);
    setSaved(true);
  }

  // Upload/Change save immediately on selection (rather than waiting for the
  // main "Save Settings" button) — a logo picker with a pending, easy-to-
  // forget save step is a common source of "I uploaded it but it didn't
  // stick" confusion. Delete works the same way for consistency.
  function handleLogoFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = ""; // allow re-selecting the same file later
    if (!file) return;
    setLogoError(null);
    if (!["image/png", "image/jpeg"].includes(file.type)) {
      setLogoError("Please choose a PNG or JPEG image.");
      return;
    }
    if (file.size > MAX_LOGO_BYTES) {
      setLogoError("That image is too large — please choose one under 2MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = reader.result as string;
      setLogoBusy(true);
      try {
        await api.patch("/api/settings", { logoUrl: dataUrl });
        setSettings((s) => (s ? { ...s, logoUrl: dataUrl } : s));
      } catch (err) {
        setLogoError((err as Error).message);
      } finally {
        setLogoBusy(false);
      }
    };
    reader.onerror = () => setLogoError("Couldn't read that file — please try again.");
    reader.readAsDataURL(file);
  }

  async function deleteLogo() {
    setLogoBusy(true);
    setLogoError(null);
    try {
      await api.patch("/api/settings", { logoUrl: null });
      setSettings((s) => (s ? { ...s, logoUrl: null } : s));
    } catch (err) {
      setLogoError((err as Error).message);
    } finally {
      setLogoBusy(false);
    }
  }

  if (!settings) return <div className="flex justify-center py-20"><Spinner /></div>;

  return (
    <div className="max-w-2xl">
      <PageHeading title="Consultant Settings" subtitle="These details are automatically used on every generated PDF report." />
      <Card className="p-5 space-y-4">
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Consultant Name"><Input value={settings.consultantName} onChange={(e) => set("consultantName", e.target.value)} /></Field>
          <Field label="Company / Brand"><Input value={settings.companyName} onChange={(e) => set("companyName", e.target.value)} /></Field>
          <Field label="Phone"><Input value={settings.phone ?? ""} onChange={(e) => set("phone", e.target.value)} /></Field>
          <Field label="WhatsApp"><Input value={settings.whatsapp ?? ""} onChange={(e) => set("whatsapp", e.target.value)} /></Field>
          <Field label="Email"><Input type="email" value={settings.email ?? ""} onChange={(e) => set("email", e.target.value)} /></Field>
          <Field label="Website"><Input value={settings.website ?? ""} onChange={(e) => set("website", e.target.value)} /></Field>
          <Field label="LinkedIn"><Input value={settings.linkedin ?? ""} onChange={(e) => set("linkedin", e.target.value)} /></Field>
          <Field label="Currency">
            <Select value={settings.currency} onChange={(e) => set("currency", e.target.value)}>
              {CURRENCIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </Select>
          </Field>
          <Field label="Default Qualification Rate %">
            <Input type="number" value={settings.defaultQualificationRate} onChange={(e) => set("defaultQualificationRate", Number(e.target.value))} />
          </Field>
        </div>
        <Field label="Address"><Textarea value={settings.address ?? ""} onChange={(e) => set("address", e.target.value)} /></Field>
        <Field label="Report Footer"><Input value={settings.reportFooter ?? ""} onChange={(e) => set("reportFooter", e.target.value)} /></Field>
        <Field label="PDF Call-to-Action"><Textarea value={settings.ctaText} onChange={(e) => set("ctaText", e.target.value)} /></Field>
        <div className="flex items-center gap-3 pt-2">
          <Button onClick={save} disabled={saving}>{saving ? "Saving…" : "Save Settings"}</Button>
          {saved && <span className="text-sm text-emerald-600">Saved.</span>}
        </div>
      </Card>

      <Card className="p-5 space-y-3 mt-6">
        <div>
          <p className="text-sm font-semibold text-slate-900 dark:text-white">Brand Logo (optional)</p>
          <p className="text-xs text-slate-400 mt-1">
            Shown next to your Company / Brand name in the header of every generated PDF report and proposal. PNG or JPEG, up to 2MB.
          </p>
        </div>
        <div className="flex items-center gap-4">
          {settings.logoUrl ? (
            <img
              src={settings.logoUrl}
              alt="Brand logo"
              className="h-16 w-16 object-contain rounded-lg border border-slate-200 bg-white p-1 dark:border-slate-700"
            />
          ) : (
            <div className="h-16 w-16 rounded-lg border border-dashed border-slate-300 dark:border-slate-700 flex items-center justify-center text-[10px] text-slate-400 text-center px-1">
              No logo
            </div>
          )}
          <div className="flex flex-col gap-2">
            <div className="flex gap-2">
              <Button type="button" variant="secondary" size="sm" onClick={() => logoInputRef.current?.click()} disabled={logoBusy}>
                {logoBusy ? "Uploading…" : settings.logoUrl ? "Change" : "Upload Logo"}
              </Button>
              {settings.logoUrl && (
                <Button type="button" variant="ghost" size="sm" onClick={deleteLogo} disabled={logoBusy} title="Remove logo">
                  <Trash2 size={13} className="text-red-500" /> Delete
                </Button>
              )}
            </div>
            {logoError && <p className="text-xs text-red-600">{logoError}</p>}
          </div>
          <input ref={logoInputRef} type="file" accept="image/png,image/jpeg" className="hidden" onChange={handleLogoFile} />
        </div>
      </Card>

      <Card className="p-5 space-y-3 mt-6">
        <div>
          <p className="text-sm font-semibold text-slate-900 dark:text-white">AI Image Generation (optional)</p>
          <p className="text-xs text-slate-400 mt-1">
            Powers real, generated Image Ad concepts in the Sample Ads step of the assessment wizard (using OpenAI&apos;s DALL·E 3).
            Left blank, image generation is simply unavailable there — nothing is faked in its place. Each image you
            generate is billed by OpenAI to this key; images are only generated when you click &quot;Generate Image&quot; on a
            specific ad concept, never automatically.
          </p>
        </div>
        <Field label="OpenAI API Key" hint="Starts with sk-… Get one at platform.openai.com/api-keys.">
          <Input
            type="password"
            value={settings.aiImageApiKey ?? ""}
            onChange={(e) => set("aiImageApiKey", e.target.value)}
            placeholder="sk-…"
            className="max-w-md"
            autoComplete="off"
          />
        </Field>
        <div className="flex items-center gap-3 pt-1">
          <Button onClick={save} disabled={saving}>{saving ? "Saving…" : "Save Settings"}</Button>
          {saved && <span className="text-sm text-emerald-600">Saved.</span>}
        </div>
      </Card>
    </div>
  );
}
