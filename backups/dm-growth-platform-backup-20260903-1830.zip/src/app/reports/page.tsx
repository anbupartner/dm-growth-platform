"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { api } from "@/lib/api-client";
import { PageHeading, Card, Spinner, EmptyState, LinkButton, Button } from "@/components/ui";
import { Download } from "lucide-react";

interface ReportRow {
  id: string;
  leadId: string;
  pdfFileName?: string | null;
  createdAt: string;
  businessName?: string;
  customerId?: string;
  customerName?: string;
}

export default function ReportsPage() {
  const [rows, setRows] = useState<ReportRow[] | null>(null);

  useEffect(() => {
    api.get<ReportRow[]>("/api/reports").then(setRows);
  }, []);

  if (!rows) return <div className="flex justify-center py-20"><Spinner /></div>;

  return (
    <div>
      <PageHeading title="Reports" subtitle="View and download generated client reports." />
      {rows.length === 0 ? (
        <EmptyState title="No reports generated yet" subtitle="Run a New Assessment to generate your first client PDF." action={<LinkButton href="/assessment/new">Run New Assessment</LinkButton>} />
      ) : (
        <Card className="overflow-hidden">
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {rows.map((r) => (
              <div key={r.id} className="flex items-center justify-between gap-3 px-5 py-3">
                <Link href={`/leads/${r.leadId}`} className="min-w-0">
                  <p className="text-sm font-medium text-slate-900 dark:text-white truncate">{r.businessName ?? "Unknown business"}</p>
                  <p className="text-xs text-slate-400 truncate">
                    {r.customerId} · {new Date(r.createdAt).toLocaleDateString()} · {r.pdfFileName}
                  </p>
                </Link>
                <a href={`/api/reports/${r.id}/pdf`}>
                  <Button size="sm" variant="secondary"><Download size={13} /> Download</Button>
                </a>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
