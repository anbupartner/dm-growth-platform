"use client";

import { useEffect, useMemo, useState } from "react";
import { useParams } from "next/navigation";
import { api } from "@/lib/api-client";
import { PageHeading, Card, CardHeader, Field, Input, Textarea, Select, Button, LinkButton, Spinner, Badge } from "@/components/ui";
import type { ReportData } from "@/lib/pdf/types";
import type { ProposalPackage } from "@/lib/pdf/proposal-types";
import { formatCurrency } from "@/lib/calculations";
import { Download, Star } from "lucide-react";

interface ReportRow {
  id: string;
  version: number;
  createdAt: string;
  hasReportData: boolean;
}

interface LeadDetail {
  lead: { id: string; businessName: string; customerName: string; quoteValue?: number | null };
  reports: ReportRow[];
}

const TIER_ORDER = ["conservative", "expected", "growth opportunity"];

function defaultTermsText() {
  return [
    "Validity: this proposal is valid for 30 days from the date above.",
    "Payment terms: 50% advance to begin work, balance due monthly in advance for the selected plan.",
    "What's included: campaign setup, ongoing management and optimization, and a monthly performance report.",
    "Ad spend is billed separately, directly to the ad platform (Google/Meta/etc.) at cost — not included in the management fee above.",
    "Either party may cancel with 30 days' written notice.",
  ].join("\n");
}

export default function NewProposalPage() {
  const params = useParams();
  const leadId = params.id as string;

  const [leadDetail, setLeadDetail] = useState<LeadDetail | null>(null);
  const [selectedReportId, setSelectedReportId] = useState<string>("");
  const [reportData, setReportData] = useState<ReportData | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [packages, setPackages] = useState<ProposalPackage[]>([]);
  const [termsText, setTermsText] = useState(defaultTermsText());
  const [validUntil, setValidUntil] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 30);
    return d.toISOString().slice(0, 10);
  });

  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const [pdfFilename, setPdfFilename] = useState("");
  const [savedVersion, setSavedVersion] = useState<number | null>(null);

  const editableReports = useMemo(
    () => (leadDetail?.reports ?? []).filter((r) => r.hasReportData).sort((a, b) => b.version - a.version),
    [leadDetail]
  );

  useEffect(() => {
    api
      .get<LeadDetail>(`/api/leads/${leadId}`)
      .then((d) => {
        setLeadDetail(d);
        const editable = (d.reports ?? []).filter((r) => r.hasReportData).sort((a, b) => b.version - a.version);
        if (editable.length > 0) setSelectedReportId(editable[0].id);
      })
      .catch((e) => setLoadError((e as Error).message));
  }, [leadId]);

  useEffect(() => {
    if (!selectedReportId) return;
    setReportData(null);
    api
      .get<{ reportData: string | null }>(`/api/reports/${selectedReportId}`)
      .then((row) => {
        if (!row.reportData) return;
        const parsed = JSON.parse(row.reportData) as ReportData;
        setReportData(parsed);
        const ordered = [...parsed.scenarios].sort((a, b) => {
          const ai = TIER_ORDER.indexOf(a.label.toLowerCase());
          const bi = TIER_ORDER.indexOf(b.label.toLowerCase());
          return (ai === -1 ? 99 : ai) - (bi === -1 ? 99 : bi);
        });
        setPackages(
          ordered.map((sc) => ({
            key: sc.label.toLowerCase().replace(/\s+/g, "-"),
            label: sc.label,
            description: "",
            price: 0,
            currency: parsed.consultant.currency,
            scenarioLabel: sc.label,
            customers: sc.customers,
            revenue: sc.revenue,
            roi: sc.roi,
            recommended: sc.label.toLowerCase().includes("expected"),
          }))
        );
      })
      .catch((e) => setLoadError((e as Error).message));
  }, [selectedReportId]);

  useEffect(() => {
    return () => {
      if (pdfUrl) URL.revokeObjectURL(pdfUrl);
    };
  }, [pdfUrl]);

  function updatePackage(i: number, patch: Partial<ProposalPackage>) {
    setPackages((prev) => prev.map((p, j) => (j === i ? { ...p, ...patch } : p)));
  }

  function markRecommended(i: number) {
    setPackages((prev) => prev.map((p, j) => ({ ...p, recommended: j === i })));
  }

  function downloadPdf() {
    if (!pdfUrl) return;
    const a = document.createElement("a");
    a.href = pdfUrl;
    a.download = pdfFilename || "proposal.pdf";
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  async function generate() {
    if (!reportData || !selectedReportId) return;
    setSaving(true);
    setSaveError(null);
    try {
      const res = await fetch("/api/proposals", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          leadId,
          reportSnapshotId: selectedReportId,
          packages,
          termsText,
          validUntil: validUntil || null,
        }),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => null);
        throw new Error(body?.error || "Generation failed.");
      }
      const version = res.headers.get("X-Proposal-Version");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      setPdfUrl(url);
      setPdfFilename(`${reportData.business.businessName || "proposal"}-proposal-v${version ?? ""}.pdf`);
      setSavedVersion(version ? Number(version) : null);
    } catch (e) {
      setSaveError((e as Error).message);
    } finally {
      setSaving(false);
    }
  }

  if (loadError && !leadDetail) {
    return (
      <div>
        <PageHeading title="Generate Proposal" />
        <Card className="p-5">
          <p className="text-sm text-red-600">{loadError}</p>
        </Card>
      </div>
    );
  }

  if (!leadDetail) {
    return (
      <div className="flex justify-center py-20">
        <Spinner />
      </div>
    );
  }

  if (editableReports.length === 0) {
    return (
      <div>
        <PageHeading title="Generate Proposal" subtitle={leadDetail.lead.businessName} />
        <Card className="p-5">
          <p className="text-sm text-amber-600">
            No editable report versions found for this lead yet. Generate a report first (Run Assessment → Save & Generate), then come back here to
            turn it into a priced proposal.
          </p>
          <LinkButton href={`/leads/${leadId}`} variant="secondary" className="mt-4">
            ← Back to Lead
          </LinkButton>
        </Card>
      </div>
    );
  }

  return (
    <div>
      <PageHeading
        title="Generate Proposal"
        subtitle={`${leadDetail.lead.businessName} · ${leadDetail.lead.customerName} · priced packages sent to the client for sign-off`}
        action={
          <LinkButton href={`/leads/${leadId}`} variant="secondary" size="sm">
            ← Back to Lead
          </LinkButton>
        }
      />

      {savedVersion ? (
        <Card className="p-4 mb-4 border-emerald-300 dark:border-emerald-700">
          <p className="text-sm text-emerald-600 font-medium mb-3">
            Proposal v{savedVersion} generated — ready to download and send to the client.
          </p>
          <div className="flex flex-wrap gap-2">
            <Button onClick={downloadPdf}>
              <Download size={16} /> Download Proposal v{savedVersion}
            </Button>
            <LinkButton href={`/leads/${leadId}`} variant="secondary">
              Go to Lead
            </LinkButton>
          </div>
        </Card>
      ) : null}

      <Card className="p-5 mb-4">
        <Field label="Based on report version" hint="Packages below are seeded from this version's scenarios — pick a different version to reseed them.">
          <Select value={selectedReportId} onChange={(e) => setSelectedReportId(e.target.value)} className="max-w-xs">
            {editableReports.map((r) => (
              <option key={r.id} value={r.id}>
                v{r.version} — {new Date(r.createdAt).toLocaleDateString()}
              </option>
            ))}
          </Select>
        </Field>
      </Card>

      {!reportData ? (
        <div className="flex justify-center py-10">
          <Spinner />
        </div>
      ) : (
        <>
          <div className="grid md:grid-cols-3 gap-4 mb-4">
            {packages.map((pkg, i) => (
              <Card key={pkg.key} className={pkg.recommended ? "p-4 border-indigo-400 border-2" : "p-4"}>
                <div className="flex items-center justify-between mb-3">
                  {pkg.recommended ? (
                    <Badge className="bg-indigo-600 text-white">Recommended</Badge>
                  ) : (
                    <button
                      type="button"
                      onClick={() => markRecommended(i)}
                      className="text-xs text-slate-400 hover:text-indigo-600 flex items-center gap-1"
                    >
                      <Star size={12} /> Mark recommended
                    </button>
                  )}
                </div>
                <Field label="Package name">
                  <Input value={pkg.label} onChange={(e) => updatePackage(i, { label: e.target.value })} />
                </Field>
                <div className="mt-3">
                  <Field label={`Monthly price (${pkg.currency})`}>
                    <Input
                      type="number"
                      min={0}
                      value={pkg.price || ""}
                      onChange={(e) => updatePackage(i, { price: Number(e.target.value) || 0 })}
                    />
                  </Field>
                </div>
                <div className="mt-3">
                  <Field label="Description" hint="What's included at this tier.">
                    <Textarea rows={3} value={pkg.description ?? ""} onChange={(e) => updatePackage(i, { description: e.target.value })} />
                  </Field>
                </div>
                {(pkg.customers != null || pkg.revenue != null || pkg.roi != null) && (
                  <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 grid grid-cols-3 gap-2 text-xs">
                    {pkg.customers != null && (
                      <div>
                        <div className="text-slate-400">Customers/mo</div>
                        <div className="font-semibold text-slate-700 dark:text-slate-200">{Math.round(pkg.customers)}</div>
                      </div>
                    )}
                    {pkg.revenue != null && (
                      <div>
                        <div className="text-slate-400">Revenue/mo</div>
                        <div className="font-semibold text-slate-700 dark:text-slate-200">{formatCurrency(Math.round(pkg.revenue), pkg.currency)}</div>
                      </div>
                    )}
                    {pkg.roi != null && (
                      <div>
                        <div className="text-slate-400">ROI</div>
                        <div className="font-semibold text-slate-700 dark:text-slate-200">{Math.round(pkg.roi)}%</div>
                      </div>
                    )}
                  </div>
                )}
              </Card>
            ))}
          </div>

          <Card className="p-5 mb-4">
            <CardHeader title="Terms & Validity" />
            <div className="pt-4 space-y-4">
              <Field label="Valid until" hint="Leave blank for no expiry.">
                <Input type="date" value={validUntil} onChange={(e) => setValidUntil(e.target.value)} className="max-w-xs" />
              </Field>
              <Field label="Terms shown on the proposal">
                <Textarea rows={6} value={termsText} onChange={(e) => setTermsText(e.target.value)} />
              </Field>
            </div>
          </Card>

          {saveError && <p className="text-sm text-red-600 mb-3">{saveError}</p>}
          <div className="flex justify-end">
            <Button onClick={generate} disabled={saving || packages.every((p) => !p.price)}>
              {saving ? "Generating…" : "Generate Proposal PDF"}
            </Button>
          </div>
          {packages.every((p) => !p.price) && (
            <p className="text-xs text-amber-600 text-right mt-2">Set a price on at least one package to generate the proposal.</p>
          )}
        </>
      )}
    </div>
  );
}
