"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api-client";
import { PageHeading, Card, Field, Input, Select, Textarea, Button } from "@/components/ui";
import { LEAD_SOURCES, LEAD_SOURCE_LABELS, BUSINESS_GOALS, INDUSTRIES } from "@/lib/constants";

export default function NewLeadPage() {
  const router = useRouter();
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({
    customerName: "",
    businessName: "",
    email: "",
    phone: "",
    whatsapp: "",
    city: "",
    state: "",
    country: "",
    businessVertical: "",
    websiteUrl: "",
    monthlyBudget: "",
    businessGoal: "",
    leadSource: "OTHER",
    notes: "",
  });

  function set<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.customerName || !form.businessName) {
      setError("Customer name and business name are required.");
      return;
    }
    setSaving(true);
    setError(null);
    try {
      const lead = await api.post<{ id: string }>("/api/leads", {
        ...form,
        monthlyBudget: form.monthlyBudget ? Number(form.monthlyBudget) : undefined,
      });
      router.push(`/leads/${lead.id}`);
    } catch (e) {
      setError((e as Error).message);
      setSaving(false);
    }
  }

  return (
    <div className="max-w-2xl">
      <PageHeading title="Add Lead" subtitle="Capture a new prospect. You can run a full assessment afterwards." />
      <Card className="p-5">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Customer Name *">
              <Input value={form.customerName} onChange={(e) => set("customerName", e.target.value)} required />
            </Field>
            <Field label="Business Name *">
              <Input value={form.businessName} onChange={(e) => set("businessName", e.target.value)} required />
            </Field>
            <Field label="Email">
              <Input type="email" value={form.email} onChange={(e) => set("email", e.target.value)} />
            </Field>
            <Field label="Phone">
              <Input value={form.phone} onChange={(e) => set("phone", e.target.value)} />
            </Field>
            <Field label="WhatsApp">
              <Input value={form.whatsapp} onChange={(e) => set("whatsapp", e.target.value)} />
            </Field>
            <Field label="Website URL">
              <Input value={form.websiteUrl} onChange={(e) => set("websiteUrl", e.target.value)} placeholder="https://" />
            </Field>
            <Field label="City">
              <Input value={form.city} onChange={(e) => set("city", e.target.value)} />
            </Field>
            <Field label="State">
              <Input value={form.state} onChange={(e) => set("state", e.target.value)} />
            </Field>
            <Field label="Country">
              <Input value={form.country} onChange={(e) => set("country", e.target.value)} />
            </Field>
            <Field label="Business Vertical / Industry">
              <Select value={form.businessVertical} onChange={(e) => set("businessVertical", e.target.value)}>
                <option value="">Select…</option>
                {INDUSTRIES.map((i) => (
                  <option key={i} value={i}>{i}</option>
                ))}
              </Select>
            </Field>
            <Field label="Monthly Marketing Budget">
              <Input type="number" value={form.monthlyBudget} onChange={(e) => set("monthlyBudget", e.target.value)} />
            </Field>
            <Field label="Business Goal">
              <Select value={form.businessGoal} onChange={(e) => set("businessGoal", e.target.value)}>
                <option value="">Select…</option>
                {BUSINESS_GOALS.map((g) => (
                  <option key={g} value={g}>{g}</option>
                ))}
              </Select>
            </Field>
            <Field label="Lead Source">
              <Select value={form.leadSource} onChange={(e) => set("leadSource", e.target.value)}>
                {LEAD_SOURCES.map((s) => (
                  <option key={s} value={s}>{LEAD_SOURCE_LABELS[s]}</option>
                ))}
              </Select>
            </Field>
          </div>
          <Field label="Notes">
            <Textarea value={form.notes} onChange={(e) => set("notes", e.target.value)} />
          </Field>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <div className="flex gap-3 pt-2">
            <Button type="submit" disabled={saving}>{saving ? "Saving…" : "Save Lead"}</Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
