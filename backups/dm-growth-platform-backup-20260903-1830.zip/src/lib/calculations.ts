// Centralized marketing forecast calculation engine.
// Every formula here mirrors the spec (sections 12–17) exactly. Nothing in
// the UI should compute these numbers itself — always call through here so
// the math stays in one place and benchmark changes never require touching
// the frontend.

export interface ForecastInputs {
  adBudget: number;
  cpc: number;
  leadConversionRate: number; // % — traffic -> leads
  qualificationRate: number; // % — default 85
  salesConversionRate: number; // % — qualified leads -> customers
  avgSellingPrice: number;
  profitMarginPct: number; // %
  additionalMarketingCost: number;
  // Organic (kept separate from paid per spec section 13)
  currentOrganicTraffic?: number;
  organicTrafficGrowth?: number; // % growth applied to currentOrganicTraffic
  organicLeadConversionRate?: number; // % — organic traffic -> organic leads
}

export interface PaidForecastResults {
  clicks: number; // = traffic
  traffic: number;
  leads: number;
  qualifiedLeads: number;
  customers: number;
  revenue: number;
  cpl: number;
  cac: number;
  roas: number; // multiplier, e.g. 2.92 -> display "2.92X"
  grossProfit: number;
  totalMarketingCost: number;
  netMarketingProfit: number;
  roi: number; // percentage
}

export interface OrganicForecastResults {
  organicTraffic: number;
  organicLeads: number;
}

export interface ForecastResults {
  paid: PaidForecastResults;
  organic: OrganicForecastResults;
  totalEstimatedTraffic: number; // paid.traffic + organic.organicTraffic, clearly labeled combined metric
  totalEstimatedLeads: number; // paid.leads + organic.organicLeads
}

function safeDiv(numerator: number, denominator: number): number {
  if (!denominator || Number.isNaN(denominator)) return 0;
  return numerator / denominator;
}

/** 12.1–12.12 — paid forecast */
export function calculatePaidForecast(inputs: ForecastInputs): PaidForecastResults {
  const traffic = safeDiv(inputs.adBudget, inputs.cpc); // 12.1 Traffic = Ad Spend / Avg CPC
  const leads = traffic * (inputs.leadConversionRate / 100); // 12.2 Leads = Traffic x Lead Conversion Rate
  const qualifiedLeads = leads * (inputs.qualificationRate / 100); // 12.3 Qualified Leads = Total Leads x Qualification Rate
  const customers = qualifiedLeads * (inputs.salesConversionRate / 100); // 12.4 Customers = Qualified Leads x Sales Conversion Rate
  const revenue = customers * inputs.avgSellingPrice; // 12.5 Revenue = Customers x Avg Selling Price
  const cpl = safeDiv(inputs.adBudget, leads); // 12.6 CPL = Ad Spend / Leads
  const cac = safeDiv(inputs.adBudget, customers); // 12.7 CAC = Ad Spend / Customers
  const roas = safeDiv(revenue, inputs.adBudget); // 12.8 ROAS = Revenue / Ad Spend (never %)
  const grossProfit = revenue * (inputs.profitMarginPct / 100); // 12.9 Gross Profit = Revenue x Profit Margin
  const totalMarketingCost = inputs.adBudget + inputs.additionalMarketingCost; // 12.10
  const netMarketingProfit = grossProfit - totalMarketingCost; // 12.11
  const roi = safeDiv(netMarketingProfit, totalMarketingCost) * 100; // 12.12 ROI = (GP - TMC) / TMC x 100

  return {
    clicks: traffic,
    traffic,
    leads,
    qualifiedLeads,
    customers,
    revenue,
    cpl,
    cac,
    roas,
    grossProfit,
    totalMarketingCost,
    netMarketingProfit,
    roi,
  };
}

/** Organic forecast, kept separate from paid (spec section 13) */
export function calculateOrganicForecast(inputs: ForecastInputs): OrganicForecastResults {
  const base = inputs.currentOrganicTraffic ?? 0;
  const growth = inputs.organicTrafficGrowth ?? 0;
  const organicTraffic = base * (1 + growth / 100);
  const organicLeads = organicTraffic * ((inputs.organicLeadConversionRate ?? 0) / 100);
  return { organicTraffic, organicLeads };
}

export function calculateForecast(inputs: ForecastInputs): ForecastResults {
  const paid = calculatePaidForecast(inputs);
  const organic = calculateOrganicForecast(inputs);
  return {
    paid,
    organic,
    totalEstimatedTraffic: paid.traffic + organic.organicTraffic,
    totalEstimatedLeads: paid.leads + organic.organicLeads,
  };
}

// --- Scenario tiers (section 14) -------------------------------------------
// Conservative / Expected / Growth Opportunity — defensible, clearly labeled
// deltas on the *Expected* (as-entered) assumptions. Never inflates blindly;
// each tier's assumption changes are returned alongside the results so the
// UI/PDF can show exactly what changed and why.
//
// Every tier also nudges Avg. CPC (paid traffic efficiency), not just the
// downstream conversion rates. Traffic = Ad Spend / CPC (12.1), so leaving
// CPC identical across all three tiers made "Traffic / Clicks" render as the
// exact same number in Conservative/Expected/Growth Opportunity, which read
// as a bug even though the funnel below it correctly diverged — and it
// undersold the Growth Opportunity case, since the same "improved targeting,
// landing pages, creative, offer and campaign optimisation" that justifies a
// higher conversion rate also typically buys cheaper, more relevant clicks
// (a better Quality/Relevance Score), not just a better close rate. A ±10%
// CPC swing is used — smaller than the ±15-20% swing on conversion rates,
// since CPC is a paid-media market price the consultant has less unilateral
// control over than their own funnel.
const CPC_CONSERVATIVE_MULTIPLIER = 1.1; // pay more per click -> less traffic for the same budget
const CPC_GROWTH_MULTIPLIER = 0.9; // cheaper clicks from optimisation -> more traffic for the same budget

export interface ScenarioTierDefinition {
  tier: "CONSERVATIVE" | "EXPECTED" | "GROWTH_OPPORTUNITY";
  label: string;
  assumptionNote: string;
  inputs: ForecastInputs;
  results: ForecastResults;
}

export function buildScenarioTiers(expected: ForecastInputs): ScenarioTierDefinition[] {
  const conservativeInputs: ForecastInputs = {
    ...expected,
    cpc: expected.cpc * CPC_CONSERVATIVE_MULTIPLIER,
    leadConversionRate: expected.leadConversionRate * 0.8,
    salesConversionRate: expected.salesConversionRate * 0.85,
    organicTrafficGrowth: (expected.organicTrafficGrowth ?? 0) * 0.5,
  };

  const growthInputs: ForecastInputs = {
    ...expected,
    cpc: expected.cpc * CPC_GROWTH_MULTIPLIER,
    leadConversionRate: expected.leadConversionRate * 1.2,
    salesConversionRate: expected.salesConversionRate * 1.15,
    organicTrafficGrowth: (expected.organicTrafficGrowth ?? 0) * 1.5,
  };

  return [
    {
      tier: "CONSERVATIVE",
      label: "Conservative",
      assumptionNote:
        "Cautious assumptions: avg. CPC +10% (paying more per click, so less traffic for the same budget), lead conversion −20%, sales conversion −15%, organic growth halved vs. Expected.",
      inputs: conservativeInputs,
      results: calculateForecast(conservativeInputs),
    },
    {
      tier: "EXPECTED",
      label: "Expected",
      assumptionNote: "Most realistic assumptions, as entered.",
      inputs: expected,
      results: calculateForecast(expected),
    },
    {
      tier: "GROWTH_OPPORTUNITY",
      label: "Growth Opportunity",
      assumptionNote:
        "Optimistic but defensible: avg. CPC −10% (cheaper, more relevant clicks from better targeting), lead conversion +20%, sales conversion +15%, organic growth x1.5 — reflecting improved targeting, landing pages, creative, offer and campaign optimisation.",
      inputs: growthInputs,
      results: calculateForecast(growthInputs),
    },
  ];
}

// --- Benchmark priority resolution (section 42) -----------------------------
// 1. Client Historical Data  2. Consultant Custom Assumption
// 3. Current Industry Benchmark  4. Generic Fallback Benchmark

export interface BenchmarkRow {
  platform: string;
  industry: string;
  metric: string;
  campaignType?: string | null;
  value: number;
  unit: string;
  currency: string;
  region: string;
  source?: string | null;
}

export interface ResolvedMetric {
  value: number | null;
  source: string;
  priorityLevel: 1 | 2 | 3 | 4;
}

export function resolveBenchmarkMetric(params: {
  clientHistoricalValue?: number | null;
  consultantAssumption?: number | null;
  industryBenchmarks: BenchmarkRow[]; // pre-filtered to platform+industry+metric(+campaignType)
  genericFallback?: number | null;
  genericFallbackLabel?: string;
}): ResolvedMetric {
  const { clientHistoricalValue, consultantAssumption, industryBenchmarks, genericFallback, genericFallbackLabel } =
    params;

  if (clientHistoricalValue != null && !Number.isNaN(clientHistoricalValue)) {
    return { value: clientHistoricalValue, source: "Client Historical Data", priorityLevel: 1 };
  }
  if (consultantAssumption != null && !Number.isNaN(consultantAssumption)) {
    return { value: consultantAssumption, source: "Consultant Custom Assumption", priorityLevel: 2 };
  }
  if (industryBenchmarks.length > 0) {
    const match = industryBenchmarks[0];
    return {
      value: match.value,
      source: `Industry Benchmark — ${match.platform} ${match.industry}${match.campaignType ? " " + match.campaignType : ""}`,
      priorityLevel: 3,
    };
  }
  if (genericFallback != null) {
    return { value: genericFallback, source: genericFallbackLabel ?? "Generic Fallback Benchmark", priorityLevel: 4 };
  }
  return { value: null, source: "Data unavailable – requires external tool/account access.", priorityLevel: 4 };
}

// --- Formatting helpers ------------------------------------------------------

// Only currencies whose real symbol is safely renderable in the PDF's
// built-in Helvetica font (WinAnsi encoding — effectively just $ £ ¥ € and
// plain Latin letters) get a bare symbol here. Everything else — including
// INR, since ₹ (U+20B9) is outside WinAnsi and would not render correctly in
// the generated PDF — falls back to the ISO code prefix below (e.g.
// "INR 50,000"), which is always correct and unambiguous.
export function formatCurrency(value: number, currency = "USD"): string {
  const symbols: Record<string, string> = {
    USD: "$",
    GBP: "£",
    EUR: "€",
    JPY: "¥",
    CNY: "CN¥",
    CAD: "C$",
    AUD: "A$",
    NZD: "NZ$",
    SGD: "S$",
    HKD: "HK$",
    MXN: "MX$",
    BRL: "R$",
    ZAR: "R ",
    AED: "AED ",
    SAR: "SAR ",
    QAR: "QAR ",
    KWD: "KWD ",
    BHD: "BHD ",
    OMR: "OMR ",
  };
  const symbol = symbols[currency] ?? currency + " ";
  return `${symbol}${value.toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
}

export function formatRoas(value: number): string {
  return `${value.toFixed(2)}X`;
}

export function formatPercent(value: number): string {
  return `${value.toFixed(1)}%`;
}

export function formatNumber(value: number): string {
  return value.toLocaleString(undefined, { maximumFractionDigits: 0 });
}
