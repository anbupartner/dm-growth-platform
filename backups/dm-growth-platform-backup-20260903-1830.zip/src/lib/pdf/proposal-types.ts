import type { ReportConsultant } from "./types";

// One priced package on the Proposal PDF — normally seeded 1:1 from a report
// version's Conservative/Expected/Growth Opportunity scenarios (so the price
// sits next to the same projected customers/revenue/ROI the client already
// saw in the full report), but label/description/price are all
// consultant-editable before sending, and a package doesn't strictly need a
// backing scenario (a flat custom package is fine too).
export interface ProposalPackage {
  key: string;
  label: string;
  description?: string;
  price: number;
  currency: string;
  scenarioLabel?: string; // which report scenario this was seeded from, if any
  customers?: number | null;
  revenue?: number | null;
  roi?: number | null;
  recommended?: boolean;
}

export interface ProposalData {
  consultant: ReportConsultant;
  business: {
    businessName: string;
    customerName: string;
  };
  summary: {
    opportunity: string;
    approach: string;
  };
  packages: ProposalPackage[];
  termsText: string;
  validUntil?: string | null;
  generatedDate: string;
  version: number;
}
