import type { ReportData } from "./types";
import type { ProposalData, ProposalPackage } from "./proposal-types";

export interface BuildProposalDataArgs {
  reportData: ReportData; // the report version this proposal is quoting off of
  packages: ProposalPackage[];
  termsText: string;
  validUntil?: string | null; // already-formatted date string, or null/omitted for no expiry
  version: number;
}

// Builds the flat ProposalData contract ProposalDocument consumes. Kept as a
// small pure function (same reasoning as build-report-data.ts) — the API
// route and any future "preview before sending" UI can share this exact
// logic instead of duplicating it.
export function buildProposalData(args: BuildProposalDataArgs): ProposalData {
  const { reportData, packages, termsText, validUntil, version } = args;
  return {
    consultant: reportData.consultant,
    business: {
      businessName: reportData.business.businessName,
      customerName: reportData.business.customerName,
    },
    summary: {
      opportunity: reportData.executiveSummary.biggestOpportunity,
      approach: reportData.problemSolutionStory.strategy,
    },
    packages,
    termsText,
    validUntil: validUntil ?? null,
    generatedDate: new Date().toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" }),
    version,
  };
}
