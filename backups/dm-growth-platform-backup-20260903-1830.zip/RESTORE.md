# Restore point — dm-growth-platform-backup-20260903-1830.zip

Taken: 2026-09-03 ~18:30 UTC (Asia/Calcutta ~00:00, 2026-09-04)
Source: E:\My Project\Dm Project\dm-growth-platform (live machine, via Claude's device bridge — not a shell snapshot)

## What this snapshot captures

Full application state as of this moment, including:

- **Source code**: `src/` (all routes, components, lib — including the app/api/billing and app/leads/[id]/billing routes from the most recent lead-billing feature, plus every fix logged in the project's build-summary doc through the 2026-09-03 scenario-tier CPC fix), `public/`, `scripts/seed.ts`.
- **Root config**: `.env`, `.env.example`, `.gitignore`, `AGENTS.md`, `CLAUDE.md`, `drizzle.config.ts`, `eslint.config.mjs`, `HOW_TO_APPLY.md`, `next-env.d.ts`, `next.config.ts`, `package.json`, `package-lock.json`, `postcss.config.mjs`, `README.md`, `tsconfig.json`.
- **Live database**: `data/app.db` + its `-wal`/`-shm` files (SQLite, includes any pending WAL-only writes at snapshot time).
- **Benchmark seed data**: all 8 `data/benchmarks/*.json` files (Google, Meta, LinkedIn, YouTube, Instagram, Microsoft Ads, WhatsApp, Industry Benchmarks — 34 industries).
- **Generated PDFs on disk**: 4 report PDFs (`data/reports/*.pdf`) and 2 proposal PDFs (`data/proposals/*.pdf`).

**Not included** (deliberately, matching every prior backup in this project): `node_modules/` and `.next/` (regenerate with `npm install` and `npm run dev`/`npm run build`), the `backups/` folder itself (avoids nesting old zips inside new ones), and the `Claude outputs/` folder (delivery-only working files from a prior session, not live app state — its content already exists inside `src/`).

## How to restore

### Full restore (replace everything)
1. Stop the dev server if it's running.
2. Unzip this archive somewhere temporary.
3. Copy every extracted file/folder over the corresponding path in your project root (`E:\My Project\Dm Project\dm-growth-platform`), overwriting what's there. This restores source, config, the database, benchmark data and generated PDFs to exactly this snapshot.
4. Run `npm install` (in case dependencies changed since this snapshot) and `npm run dev` (or `-- -p <port>` if you use a specific port).
5. On first request, the app's self-heal (`src/lib/db/index.ts`) will re-check schema/columns/tables/benchmark rows against the restored `app.db` — this is safe and a no-op if nothing's missing.

### Database-only restore (keep current code, roll back data)
1. Stop the dev server.
2. Replace `data/app.db`, `data/app.db-wal` and `data/app.db-shm` with the three files from this archive's `data/` folder.
3. Restart the dev server.

### Single-file restore
Extract just the one file you need from the archive (it mirrors the project's folder structure exactly — e.g. `src/lib/calculations.ts`) and copy it over the live file at the same relative path.

## Known state at this snapshot

- Scenario tiers vary both CPC (±10%) and conversion rates across Conservative/Expected/Growth Opportunity (2026-09-03 fix).
- Self-heal is throttle-based (5s, request-triggered) — picks up code, schema, *and* pure-data-file changes automatically, no restart needed (2026-09-03 fix).
- 34 business verticals, full 8-channel benchmark coverage, suggested-minimum-budget hints (with vertical-fallback for the 5 verticals whose usual channels lack lead-based benchmarks).
- Report/Proposal versioning, delete-with-confirmation for reports/proposals/leads, brand logo on PDFs, and the lead-billing feature (payments API + UI) are all present in this snapshot's `src/`.
