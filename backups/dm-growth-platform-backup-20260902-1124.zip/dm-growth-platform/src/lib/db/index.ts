// Database client.
//
// Local dev / single machine: Node's built-in `node:sqlite` (stable as of
// Node 22.5+, no native compilation and no external package required —
// this deliberately avoids better-sqlite3, whose native build can fail on
// machines without build tools or with restricted network access to
// download prebuilt binaries).
//
// Production / cross-device sync: swap this for a hosted Postgres driver so
// every device talking to the same deployed app shares the same data. Steps:
//   1. npm install drizzle-orm pg (or @neondatabase/serverless for Neon)
//   2. Replace the block below with:
//        import { drizzle } from "drizzle-orm/node-postgres";
//        import { Pool } from "pg";
//        const pool = new Pool({ connectionString: process.env.DATABASE_URL });
//        export const db = drizzle(pool, { schema });
//   3. Run `npx drizzle-kit push` against the Postgres DATABASE_URL.
// See README.md → "Going to production: cross-device sync" for the full walkthrough.

import { DatabaseSync, type StatementSync } from "node:sqlite";
import { drizzle } from "drizzle-orm/sqlite-proxy";
import { getTableColumns, getTableName } from "drizzle-orm";
import { randomUUID } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import * as schema from "./schema";

const dbPath = process.env.DATABASE_URL ?? "./data/app.db";
const resolved = path.isAbsolute(dbPath)
  ? dbPath
  : path.join(process.cwd(), /* turbopackIgnore: true */ dbPath);
fs.mkdirSync(path.dirname(resolved), { recursive: true });

const globalForDb = globalThis as unknown as { __sqlite?: DatabaseSync };
const sqlite = globalForDb.__sqlite ?? new DatabaseSync(resolved);
sqlite.exec("PRAGMA journal_mode = WAL");
sqlite.exec("PRAGMA foreign_keys = ON");
if (process.env.NODE_ENV !== "production") globalForDb.__sqlite = sqlite;

// --- Lightweight auto-migration ---------------------------------------------
// This project syncs schema.ts to the SQLite file with `drizzle-kit push`
// (no migration files) — see package.json's `db:push`. That's a command the
// consultant has to remember to re-run by hand after every schema change,
// but the app itself is updated by copying source files over, not by running
// commands. If a shipped change adds a column (e.g. `target_country`) before
// `db:push` is re-run, every insert/update touching that column then fails
// with a raw "no such column" error — which surfaces to the consultant as an
// unexplained "Internal Server Error" on Save & Generate.
//
// To make that whole class of failure impossible, every time this module
// loads it reconciles each table in schema.ts against the actual columns in
// the SQLite file and ALTER TABLE ADD COLUMN's anything missing. This only
// ever adds columns to tables that already exist — it never creates tables
// (initial setup is still `npm run setup` / db:push) and never drops,
// renames, or changes an existing column — so it's safe to run
// unconditionally, as often as this module re-evaluates.
//
// Deliberately NOT gated behind a "have I already run this process?" latch:
// a long-running `next dev` server keeps the same Node process (and the same
// globalThis) across every file update the consultant receives, so a
// once-per-process guard would only ever catch the very first schema change
// after a cold start — any later shipped column addition would silently
// need a full server restart to pick up, reintroducing the exact "Internal
// Server Error" this was built to prevent. Turbopack re-evaluates this
// module on the next request whenever schema.ts (a direct import) changes,
// which is exactly when the check needs to re-run — so letting it run every
// time is what makes updates self-heal without a restart. The check itself
// is a handful of synchronous, in-process PRAGMA/ALTER statements per table,
// so re-running it costs virtually nothing when there's nothing to do.
function quoteIdent(name: string): string {
  return `"${name.replace(/"/g, '""')}"`;
}

function formatSqlLiteral(value: unknown, sqlType: string): string {
  if (value === null) return "NULL";
  if (typeof value === "boolean") return value ? "1" : "0"; // sqlite has no bool type; drizzle stores as 0/1
  if (typeof value === "number") return String(value);
  if (sqlType === "integer" && value instanceof Date) return String(value.getTime());
  return `'${String(value).replace(/'/g, "''")}'`;
}

function ensureSchemaColumns(db: DatabaseSync) {
  for (const value of Object.values(schema)) {
    let tableName: string;
    let columns: Record<string, ReturnType<typeof getTableColumns>[string]>;
    try {
      tableName = getTableName(value as Parameters<typeof getTableName>[0]);
      columns = getTableColumns(value as Parameters<typeof getTableColumns>[0]);
    } catch {
      continue; // not a Drizzle table export (e.g. a type or helper)
    }

    const tableExists = db
      .prepare("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?")
      .get(tableName);
    if (!tableExists) continue; // brand-new install — `npm run setup` creates it

    const existingCols = new Set(
      (db.prepare(`PRAGMA table_info(${quoteIdent(tableName)})`).all() as Array<{ name: string }>).map(
        (r) => r.name
      )
    );

    for (const col of Object.values(columns)) {
      if (existingCols.has(col.name)) continue;
      const sqlType = col.getSQLType();
      let ddl = `ALTER TABLE ${quoteIdent(tableName)} ADD COLUMN ${quoteIdent(col.name)} ${sqlType}`;
      // Only literal defaults can be used in an ALTER ... ADD COLUMN; $defaultFn
      // callbacks (e.g. randomUUID/new Date for id/timestamps) can't be — those
      // columns are always present on table creation already, so this only
      // matters for the rare notNull column with a literal default.
      if (typeof col.default !== "function" && col.default !== undefined) {
        ddl += ` DEFAULT ${formatSqlLiteral(col.default, sqlType)}`;
        if (col.notNull) ddl += " NOT NULL";
      }
      try {
        db.exec(ddl);
        console.log(`[db] auto-migrated: added column "${tableName}"."${col.name}"`);
      } catch (err) {
        console.error(`[db] auto-migration failed for "${tableName}"."${col.name}":`, err);
      }
    }
  }
}

ensureSchemaColumns(sqlite);

// --- Lightweight auto-seed: per-industry Profit Margin benchmarks ----------
// The Benchmarks page needs a starting "Profit Margin %" per business
// vertical, same as the CPC/CTR benchmarks already seeded per
// platform+industry (see calculations.ts's resolveBenchmarkMetric and the
// Forecast step's "Profit Margin %" field). This consultant's installation
// was already seeded before this metric existed, and — same reasoning as
// ensureSchemaColumns above — updates ship as source-file diffs rather than
// by re-running `npm run db:seed`, so a one-time seed script would never
// reach an already-running install. This reconciles the `benchmarks` table
// against the list below on every boot and inserts only whichever
// industry's row is missing — it never touches a row that already exists,
// so editing a value later from the Benchmarks page (or disabling it) is
// never overwritten by a later update. A brand-new install seeds the same
// rows the normal way too, via scripts/seed.ts + data/benchmarks/industry_benchmarks.json.
//
// These are general industry starting points (see data/benchmarks/industry_benchmarks.json's
// "notes" field per row for caveats), not a claim about any specific client's
// actual margin — the consultant enters the client's real Profit Margin %
// on the Business Details step, or edits the benchmark value itself here.
const INDUSTRY_PROFIT_MARGIN_BENCHMARKS: Array<{ industry: string; value: number; notes: string }> = [
  { industry: "Advocacy", value: 30, notes: "Non-profit/advocacy orgs don't have a standard commercial profit margin — this represents a typical lean operating-surplus margin. Treat as illustrative only and override freely." },
  { industry: "Apparel", value: 45, notes: "General starting point — override with the client's actual margin whenever known." },
  { industry: "Auto", value: 15, notes: "Blended figure across vehicle sales (thin) and service/parts (higher-margin) — adjust for the client's actual mix." },
  { industry: "B2B", value: 35, notes: "General starting point — override with the client's actual margin whenever known." },
  { industry: "Beauty", value: 40, notes: "General starting point — override with the client's actual margin whenever known." },
  { industry: "Consumer Services", value: 40, notes: "Typical of local trade/home-service businesses (plumbing, cleaning, repair) — adjust for the client's actual overhead." },
  { industry: "Dating & Personals", value: 65, notes: "Digital subscription/app businesses typically carry very low direct delivery cost — high margin before customer-acquisition spend." },
  { industry: "E-Commerce", value: 35, notes: "General starting point — varies significantly by product category and shipping/fulfillment cost." },
  { industry: "Education", value: 45, notes: "General starting point — override with the client's actual margin whenever known." },
  { industry: "Employment & Job Training", value: 45, notes: "General starting point — override with the client's actual margin whenever known." },
  { industry: "Employment Services", value: 25, notes: "Staffing/placement businesses vary widely — pass-through staffing runs thinner, retained-search/placement fees run higher." },
  { industry: "Finance & Insurance", value: 50, notes: "Reflects an advisory/agency business (broker, agent, advisor), not a full underwriting carrier." },
  { industry: "Fitness", value: 40, notes: "General starting point — override with the client's actual margin whenever known." },
  { industry: "Health & Medical", value: 45, notes: "Reflects an individual practice (clinic, dentist, specialist) — compliance/insurance mix changes this significantly." },
  { industry: "Healthcare", value: 30, notes: "Reflects a larger facility/network (multi-provider, hospital-adjacent) — typically thinner than a single practice." },
  { industry: "Home Goods", value: 30, notes: "General starting point — custom/made-to-order businesses often run meaningfully higher; use the client's actual figure when known." },
  { industry: "Home Improvement", value: 25, notes: "Residential remodeling/contracting — commercial construction typically runs thinner." },
  { industry: "Industrial Services", value: 20, notes: "General starting point — override with the client's actual margin whenever known." },
  { industry: "Legal", value: 60, notes: "Professional services with low direct delivery cost — typically among the highest-margin categories here." },
  { industry: "Real Estate", value: 45, notes: "Reflects a commission-based agency/brokerage, not a property developer or REIT." },
  { industry: "Retail", value: 30, notes: "General starting point — varies significantly by product category." },
  { industry: "Technology", value: 45, notes: "Blended across software/SaaS (higher) and IT services/hardware (lower) — narrow to the client's actual model." },
  { industry: "Travel & Hospitality", value: 30, notes: "General starting point — hotels, tour operators and travel agencies vary widely." },
];

function ensureIndustryProfitMarginBenchmarks(db: DatabaseSync) {
  const tableExists = db
    .prepare("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'benchmarks'")
    .get();
  if (!tableExists) return; // brand-new install — scripts/seed.ts seeds this table on first run

  const existsStmt = db.prepare(
    "SELECT 1 FROM benchmarks WHERE platform = ? AND industry = ? AND metric = 'Profit Margin'"
  );
  const insertStmt = db.prepare(
    `INSERT INTO benchmarks (id, platform, industry, metric, value, unit, currency, region, source, benchmark_year, status, notes, created_at, updated_at)
     VALUES (?, 'Industry Benchmark', ?, 'Profit Margin', ?, '%', 'USD', 'Global', 'Industry Benchmark', '2026', 'active', ?, ?, ?)`
  );

  let added = 0;
  for (const row of INDUSTRY_PROFIT_MARGIN_BENCHMARKS) {
    try {
      if (existsStmt.get("Industry Benchmark", row.industry)) continue;
      // schema.ts declares created_at/updated_at as integer mode "timestamp"
      // (Drizzle stores/reads these as Unix *seconds*, not milliseconds —
      // unlike mode "timestamp_ms" used nowhere in this schema).
      const now = Math.floor(Date.now() / 1000);
      insertStmt.run(randomUUID(), row.industry, row.value, row.notes, now, now);
      added++;
    } catch (err) {
      console.error(`[db] profit-margin benchmark seed failed for "${row.industry}":`, err);
    }
  }
  if (added > 0) console.log(`[db] auto-seeded ${added} industry Profit Margin benchmark row(s)`);
}

ensureIndustryProfitMarginBenchmarks(sqlite);

const statementCache = new Map<string, StatementSync>();
function prepare(sql: string): StatementSync {
  let stmt = statementCache.get(sql);
  if (!stmt) {
    stmt = sqlite.prepare(sql);
    statementCache.set(sql, stmt);
  }
  return stmt;
}

// Bridges Drizzle's async sqlite-proxy contract onto node:sqlite's
// synchronous API. "all"/"get"/"values" all return rows as plain arrays
// (setReturnArrays) since that's what Drizzle's row mapper expects; "run" is
// used for statements where the caller doesn't need rows back.
export const db = drizzle(
  async (sqlText, params, method) => {
    const stmt = prepare(sqlText);
    if (method === "run") {
      stmt.run(...params);
      return { rows: [] };
    }
    stmt.setReturnArrays(true);
    if (method === "get") {
      const row = stmt.get(...params) as unknown as unknown[] | undefined;
      return { rows: (row ?? undefined) as unknown as unknown[] };
    }
    const rows = stmt.all(...params) as unknown as unknown[][];
    return { rows };
  },
  { schema }
);

export { sqlite };
