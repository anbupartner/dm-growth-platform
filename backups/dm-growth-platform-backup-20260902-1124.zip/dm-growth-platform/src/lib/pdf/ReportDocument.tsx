import { Document, Page, Text, View, StyleSheet, Image } from "@react-pdf/renderer";
import type { ReportData } from "./types";
import { auditStatusLabel } from "@/lib/constants";
import { formatCurrency } from "@/lib/calculations";

const COLORS = {
  ink: "#111827",
  sub: "#4b5563",
  faint: "#9ca3af",
  brand: "#4f46e5",
  brandSoft: "#eef2ff",
  line: "#e5e7eb",
  good: "#059669",
  warn: "#d97706",
  bad: "#dc2626",
};

const s = StyleSheet.create({
  page: { padding: 40, fontSize: 10, color: COLORS.ink, fontFamily: "Helvetica" },
  headerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 16 },
  brandTitle: { fontSize: 10, color: COLORS.brand, fontFamily: "Helvetica-Bold" },
  pageTitle: { fontSize: 18, fontFamily: "Helvetica-Bold", marginBottom: 4 },
  pageSubtitle: { fontSize: 10, color: COLORS.sub, marginBottom: 14 },
  sectionLabel: { fontSize: 11, fontFamily: "Helvetica-Bold", marginTop: 14, marginBottom: 6, color: COLORS.brand },
  bodyText: { fontSize: 10, color: COLORS.ink, lineHeight: 1.5 },
  subText: { fontSize: 9, color: COLORS.sub, lineHeight: 1.4 },
  bulletRow: { flexDirection: "row", marginBottom: 4 },
  bulletDot: { width: 10, fontSize: 10, color: COLORS.brand },
  bulletText: { flex: 1, fontSize: 10, lineHeight: 1.4 },
  card: { backgroundColor: COLORS.brandSoft, borderRadius: 6, padding: 10, marginBottom: 8 },
  divider: { borderBottomWidth: 1, borderBottomColor: COLORS.line, marginVertical: 10 },
  footer: { position: "absolute", bottom: 24, left: 40, right: 40, fontSize: 8, color: COLORS.faint, flexDirection: "row", justifyContent: "space-between" },
  table: { borderWidth: 1, borderColor: COLORS.line, borderRadius: 4 },
  tr: { flexDirection: "row", borderBottomWidth: 1, borderBottomColor: COLORS.line },
  trLast: { flexDirection: "row" },
  thCell: { flex: 1, padding: 6, fontFamily: "Helvetica-Bold", fontSize: 8, backgroundColor: "#f8fafc" },
  tdCell: { flex: 1, padding: 6, fontSize: 8 },
  scoreBarTrack: { height: 6, backgroundColor: COLORS.line, borderRadius: 3, marginTop: 3 },
  scoreBarFill: { height: 6, borderRadius: 3 },
  adCard: { width: "47%", borderWidth: 1, borderColor: COLORS.line, borderRadius: 6, padding: 10, marginBottom: 10 },
  chip: { fontSize: 7, color: "#fff", backgroundColor: COLORS.brand, borderRadius: 3, paddingVertical: 2, paddingHorizontal: 6, alignSelf: "flex-start", marginBottom: 6 },
});

function Header({ consultant }: { consultant: ReportData["consultant"] }) {
  return (
    <View style={s.headerRow} fixed>
      <Text style={s.brandTitle}>{consultant.companyName}</Text>
      <Text style={{ fontSize: 8, color: COLORS.faint }}>{consultant.consultantName}</Text>
    </View>
  );
}

function Footer({ page, total, consultant }: { page: number; total: number; consultant: ReportData["consultant"] }) {
  return (
    <View style={s.footer} fixed>
      <Text>
        {consultant.companyName} · {consultant.website ?? consultant.email ?? ""}
      </Text>
      <Text>Page {page} of {total}</Text>
    </View>
  );
}

function scoreColor(score: number) {
  if (score < 40) return COLORS.bad;
  if (score < 65) return COLORS.warn;
  return COLORS.good;
}

export function ReportDocument({ data }: { data: ReportData }) {
  const { consultant, business, executiveSummary, websiteRecommendations, auditScores, competitorInsights, competitorSites, audiencePlatform, sampleAds, scenarios, growthPlan, problemSolutionStory } = data;
  const competitorRows = competitorSites ? [...(competitorSites.client ? [competitorSites.client] : []), ...competitorSites.competitors] : [];
  const hasAdCopyPage = sampleAds.some((ad) => ad.searchAd || ad.displayAd || ad.socialAd || ad.videoAd);
  const totalPages = hasAdCopyPage ? 9 : 8;
  const pAdCopy = 6;
  const pBudget = hasAdCopyPage ? 7 : 6;
  const pGrowthPlan = hasAdCopyPage ? 8 : 7;
  const pStory = hasAdCopyPage ? 9 : 8;

  return (
    <Document title={`${business.businessName} — Digital Growth Report`} author={consultant.companyName}>
      {/* PAGE 1 — EXECUTIVE SUMMARY */}
      <Page size="A4" style={s.page}>
        <Header consultant={consultant} />
        <Text style={s.pageTitle}>Digital Growth &amp; Lead Conversion Report</Text>
        <Text style={s.pageSubtitle}>
          Prepared for {business.customerName} · {business.businessName} · {data.generatedDate}
        </Text>

        <View style={s.card}>
          <Text style={{ fontSize: 9, fontFamily: "Helvetica-Bold", marginBottom: 4 }}>Current Situation</Text>
          <Text style={s.bodyText}>{executiveSummary.currentSituation}</Text>
        </View>

        <Text style={s.sectionLabel}>Key Problems Affecting Growth</Text>
        {executiveSummary.problems.slice(0, 5).map((p, i) => (
          <View style={s.bulletRow} key={i}>
            <Text style={s.bulletDot}>•</Text>
            <Text style={s.bulletText}>{p}</Text>
          </View>
        ))}

        <Text style={s.sectionLabel}>Biggest Growth Opportunity</Text>
        <Text style={s.bodyText}>{executiveSummary.biggestOpportunity}</Text>

        <Text style={s.sectionLabel}>Recommended Direction</Text>
        <Text style={s.bodyText}>{executiveSummary.recommendedDirection}</Text>

        <Footer page={1} total={totalPages} consultant={consultant} />
      </Page>

      {/* PAGE 2 — WEBSITE RECOMMENDATIONS */}
      <Page size="A4" style={s.page}>
        <Header consultant={consultant} />
        <Text style={s.pageTitle}>Website Recommendations</Text>
        {websiteRecommendations.hasWebsite ? (
          <>
            <Text style={s.sectionLabel}>Top Website Problems</Text>
            {websiteRecommendations.topProblems.map((p, i) => (
              <View style={s.bulletRow} key={i}>
                <Text style={s.bulletDot}>•</Text>
                <Text style={s.bulletText}>{p}</Text>
              </View>
            ))}
            {websiteRecommendations.growthRecommendations ? (
              (
                [
                  ["Increase Traffic", websiteRecommendations.growthRecommendations.traffic],
                  ["Strengthen Branding", websiteRecommendations.growthRecommendations.branding],
                  ["Extend Reach", websiteRecommendations.growthRecommendations.reach],
                ] as [string, string[]][]
              ).map(([label, items]) =>
                items.length === 0 ? null : (
                  <View key={label} style={{ marginBottom: 8 }}>
                    <Text style={s.sectionLabel}>{label}</Text>
                    {items.map((p, i) => (
                      <View style={s.bulletRow} key={i}>
                        <Text style={s.bulletDot}>•</Text>
                        <Text style={s.bulletText}>{p}</Text>
                      </View>
                    ))}
                  </View>
                )
              )
            ) : (
              <>
                <Text style={s.sectionLabel}>Recommended Improvements</Text>
                {websiteRecommendations.recommendedImprovements.map((p, i) => (
                  <View style={s.bulletRow} key={i}>
                    <Text style={s.bulletDot}>•</Text>
                    <Text style={s.bulletText}>{p}</Text>
                  </View>
                ))}
              </>
            )}

            {websiteRecommendations.offPageMetrics ? (
              <View style={s.card}>
                <Text style={{ fontSize: 9, fontFamily: "Helvetica-Bold", marginBottom: 4 }}>Off-Page &amp; Traffic Snapshot</Text>
                <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
                  {(
                    [
                      ["Domain Authority / Rating", websiteRecommendations.offPageMetrics.domainAuthority],
                      ["Total Backlinks", websiteRecommendations.offPageMetrics.totalBacklinks],
                      ["Referring Domains", websiteRecommendations.offPageMetrics.referringDomains],
                      ["Est. Monthly Organic Traffic", websiteRecommendations.offPageMetrics.estimatedOrganicTraffic],
                    ] as [string, string | undefined][]
                  )
                    .filter(([, v]) => v)
                    .map(([label, value]) => (
                      <View key={label} style={{ width: "50%", marginBottom: 4 }}>
                        <Text style={{ fontSize: 8, color: COLORS.sub }}>{label}</Text>
                        <Text style={{ fontSize: 10, fontFamily: "Helvetica-Bold" }}>{value}</Text>
                      </View>
                    ))}
                </View>
                {websiteRecommendations.offPageMetrics.source ? (
                  <Text style={{ fontSize: 7, color: COLORS.faint, marginTop: 2 }}>Source: {websiteRecommendations.offPageMetrics.source}</Text>
                ) : null}
              </View>
            ) : null}

            {websiteRecommendations.strategicRecommendations && websiteRecommendations.strategicRecommendations.length > 0 && (
              <>
                <Text style={s.sectionLabel}>Strategic Next Steps — Off-Page, Link Building &amp; Content</Text>
                {websiteRecommendations.strategicRecommendations.map((p, i) => (
                  <View style={s.bulletRow} key={i}>
                    <Text style={s.bulletDot}>•</Text>
                    <Text style={s.bulletText}>{p}</Text>
                  </View>
                ))}
              </>
            )}
          </>
        ) : (
          <>
            <Text style={s.sectionLabel}>Recommended Website Type</Text>
            <Text style={s.bodyText}>{websiteRecommendations.recommendedWebsiteType ?? "Lead-generation website"}</Text>
            {websiteRecommendations.recommendedWebsiteTypeDescription ? (
              <Text style={[s.subText, { marginTop: 2, marginBottom: 6 }]}>{websiteRecommendations.recommendedWebsiteTypeDescription}</Text>
            ) : null}
            <Text style={s.sectionLabel}>Recommended Pages</Text>
            {(websiteRecommendations.recommendedPages ?? []).map((p, i) => (
              <View style={s.bulletRow} key={i}>
                <Text style={s.bulletDot}>•</Text>
                <Text style={s.bulletText}>{p}</Text>
              </View>
            ))}
          </>
        )}

        {websiteRecommendations.localPresence ? (
          <View style={s.card}>
            <Text style={{ fontSize: 9, fontFamily: "Helvetica-Bold", marginBottom: 4 }}>
              Local Presence — {websiteRecommendations.localPresence.storeLocations.length} Location
              {websiteRecommendations.localPresence.storeLocations.length === 1 ? "" : "s"}
            </Text>
            {websiteRecommendations.localPresence.storeLocations.map((url, i) => (
              <Text key={url + i} style={{ fontSize: 8, color: COLORS.sub, marginBottom: 2 }}>
                {i === 0 ? "Main store: " : `Location ${i + 1}: `}
                {url}
              </Text>
            ))}
            {websiteRecommendations.localPresence.notes ? (
              <Text style={{ fontSize: 8, marginTop: 4, lineHeight: 1.4 }}>{websiteRecommendations.localPresence.notes}</Text>
            ) : null}
            {websiteRecommendations.localPresence.recommendations && websiteRecommendations.localPresence.recommendations.length > 0 ? (
              <>
                <Text style={{ fontSize: 8, fontFamily: "Helvetica-Bold", marginTop: 6, marginBottom: 3 }}>
                  Recommended Local Branding Improvements (Google Business Profile)
                </Text>
                {websiteRecommendations.localPresence.recommendations.map((r, i) => (
                  <View style={s.bulletRow} key={i}>
                    <Text style={s.bulletDot}>•</Text>
                    <Text style={s.bulletText}>{r}</Text>
                  </View>
                ))}
              </>
            ) : null}
          </View>
        ) : null}

        <Footer page={2} total={totalPages} consultant={consultant} />
      </Page>

      {/* PAGE 3 — WEBSITE AUDIT SCORING */}
      <Page size="A4" style={s.page}>
        <Header consultant={consultant} />
        <Text style={s.pageTitle}>Website Audit Scorecard</Text>
        {auditScores ? (
          <View style={{ marginTop: 8 }}>
            {(
              [
                ["Technical SEO", auditScores.technicalSeo],
                ["On-Page SEO", auditScores.onPageSeo],
                ["Content", auditScores.content],
                ["UX & Conversion", auditScores.uxConversion],
                ["Branding", auditScores.branding],
                ["Local SEO", auditScores.localSeo],
                ["Performance", auditScores.performance],
              ] as [string, number][]
            ).map(([label, score]) => (
              <View key={label} style={{ marginBottom: 10 }}>
                <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                  <Text style={{ fontSize: 9, fontFamily: "Helvetica-Bold" }}>{label}</Text>
                  <Text style={{ fontSize: 9 }}>
                    {score}/100 — {auditStatusLabel(score)}
                  </Text>
                </View>
                <View style={s.scoreBarTrack}>
                  <View style={[s.scoreBarFill, { width: `${score}%`, backgroundColor: scoreColor(score) }]} />
                </View>
              </View>
            ))}
            <View style={[s.divider]} />
            <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
              <Text style={{ fontSize: 11, fontFamily: "Helvetica-Bold" }}>Overall Website Score</Text>
              <Text style={{ fontSize: 11, fontFamily: "Helvetica-Bold" }}>{auditScores.overall}/100</Text>
            </View>
          </View>
        ) : (
          <Text style={s.subText}>Data unavailable – requires external tool/account access.</Text>
        )}
        <Footer page={3} total={totalPages} consultant={consultant} />
      </Page>

      {/* PAGE 4 — COMPETITOR INSIGHTS */}
      <Page size="A4" style={s.page}>
        <Header consultant={consultant} />
        <Text style={s.pageTitle}>Competitor Insights</Text>
        <Text style={s.pageSubtitle}>Live research on each competitor&apos;s own site — no estimated or sample data.</Text>

        {competitorRows.length > 0 ? (
          <View style={[s.table, { marginBottom: 12 }]}>
            <View style={s.tr}>
              <Text style={s.thCell}>Site</Text>
              <Text style={s.thCell}>Words</Text>
              <Text style={s.thCell}>Blog</Text>
              <Text style={s.thCell}>Schema</Text>
              <Text style={s.thCell}>Mobile</Text>
              <Text style={s.thCell}>HTTPS</Text>
              <Text style={s.thCell}>Platform</Text>
            </View>
            {competitorRows.map((c, idx) => (
              <View style={idx === competitorRows.length - 1 ? s.trLast : s.tr} key={c.hostname + idx}>
                <Text style={s.tdCell}>{idx === 0 && competitorSites?.client ? "Your client" : c.hostname}</Text>
                {c.fetchedOk ? (
                  <>
                    <Text style={s.tdCell}>{c.wordCount}</Text>
                    <Text style={s.tdCell}>{c.hasBlog ? "Yes" : "No"}</Text>
                    <Text style={s.tdCell}>{c.hasSchema ? "Yes" : "No"}</Text>
                    <Text style={s.tdCell}>{c.hasViewport ? "Yes" : "No"}</Text>
                    <Text style={s.tdCell}>{c.https ? "Yes" : "No"}</Text>
                    <Text style={s.tdCell}>{c.techPlatform}</Text>
                  </>
                ) : (
                  <Text style={[s.tdCell, { flex: 5 }]}>Not reachable</Text>
                )}
              </View>
            ))}
          </View>
        ) : null}

        <Text style={s.sectionLabel}>Insights &amp; Recommendations</Text>
        {competitorInsights.length > 0 ? (
          competitorInsights.map((c, i) => (
            <View style={s.bulletRow} key={i}>
              <Text style={s.bulletDot}>•</Text>
              <Text style={s.bulletText}>{c}</Text>
            </View>
          ))
        ) : (
          <Text style={s.subText}>Competitor data unavailable — no competitor URLs were analyzed.</Text>
        )}
        <Footer page={4} total={totalPages} consultant={consultant} />
      </Page>

      {/* PAGE 5 — TARGET AUDIENCE, PLATFORMS & VISUAL SAMPLE ADVERTISEMENTS */}
      <Page size="A4" style={s.page}>
        <Header consultant={consultant} />
        <Text style={s.pageTitle}>Target Audience, Platforms &amp; Sample Ads</Text>

        <Text style={s.sectionLabel}>Target Audience</Text>
        <Text style={s.bodyText}>{audiencePlatform.targetAudience}</Text>

        {audiencePlatform.platforms.length > 0 && (
          <>
            <Text style={s.sectionLabel}>Recommended Platforms &amp; Ad Types</Text>
            {audiencePlatform.platforms.map((p, i) => (
              <View key={i} style={{ marginBottom: 6 }}>
                <Text style={{ fontSize: 9, fontFamily: "Helvetica-Bold" }}>{p.platform}{p.adType ? ` — ${p.adType}` : ""}</Text>
                {p.expectedResult ? <Text style={s.subText}>Expected result: {p.expectedResult}</Text> : null}
              </View>
            ))}
          </>
        )}

        <Text style={[s.pageSubtitle, { marginTop: 10 }]}>Sample ad concepts based on {business.businessName}&apos;s actual products/services.</Text>
        <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between" }}>
          {sampleAds.map((ad, i) => (
            <View key={i} style={s.adCard}>
              <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 3 }}>
                <Text style={[s.chip, { marginBottom: 0, marginRight: 4 }]}>{ad.platform}</Text>
                {ad.format ? <Text style={{ fontSize: 7, color: COLORS.sub }}>{ad.format}</Text> : null}
              </View>
              {ad.adType ? <Text style={{ fontSize: 7, color: COLORS.faint, marginBottom: 3 }}>{ad.adType}</Text> : null}
              {ad.imageDataUrl ? (
                // eslint-disable-next-line jsx-a11y/alt-text -- this is @react-pdf/renderer's Image, not an HTML <img>
                <Image src={ad.imageDataUrl} style={{ width: "100%", borderRadius: 4, marginBottom: 5 }} />
              ) : ad.referenceImageUrl ? (
                <View style={{ marginBottom: 5 }}>
                  {/* eslint-disable-next-line jsx-a11y/alt-text -- this is @react-pdf/renderer's Image, not an HTML <img> */}
                  <Image src={ad.referenceImageUrl} style={{ width: "100%", borderRadius: 4 }} />
                  <Text style={{ fontSize: 6, color: COLORS.faint, marginTop: 2 }}>Reference photo from {ad.referenceImageSource} — for visual inspiration only.</Text>
                </View>
              ) : null}
              <Text style={{ fontSize: 11, fontFamily: "Helvetica-Bold", marginBottom: 4 }}>{ad.headline}</Text>
              {ad.benefit ? <Text style={{ fontSize: 8, color: COLORS.sub, marginBottom: 6 }}>{ad.benefit}</Text> : null}
              {ad.videoScript ? (
                <View style={{ marginBottom: 6 }}>
                  <Text style={{ fontSize: 7, color: COLORS.sub, marginBottom: 2 }}>
                    <Text style={{ fontFamily: "Helvetica-Bold" }}>Hook: </Text>
                    {ad.videoScript.hook}
                  </Text>
                  <Text style={{ fontSize: 7, color: COLORS.sub, marginBottom: 2 }}>
                    <Text style={{ fontFamily: "Helvetica-Bold" }}>Story: </Text>
                    {ad.videoScript.story}
                  </Text>
                  <Text style={{ fontSize: 7, color: COLORS.sub }}>
                    <Text style={{ fontFamily: "Helvetica-Bold" }}>Closing: </Text>
                    {ad.videoScript.cta}
                  </Text>
                </View>
              ) : null}
              <Text style={{ fontSize: 8, color: COLORS.brand, fontFamily: "Helvetica-Bold" }}>{ad.cta} →</Text>
            </View>
          ))}
        </View>
        <Footer page={5} total={totalPages} consultant={consultant} />
      </Page>

      {/* PAGE 6 — AD COPY & EXTENSIONS (full platform-specific ad fields) */}
      {sampleAds.some((ad) => ad.searchAd || ad.displayAd || ad.socialAd || ad.videoAd) && (
        <Page size="A4" style={s.page}>
          <Header consultant={consultant} />
          <Text style={s.pageTitle}>Ad Copy &amp; Extensions</Text>
          <Text style={s.pageSubtitle}>Full field-level ad copy, matching each platform&apos;s actual ad structure — ready to paste into Ads Manager / Google Ads.</Text>

          {sampleAds.map((ad, i) => {
            if (!ad.searchAd && !ad.displayAd && !ad.socialAd && !ad.videoAd) return null;
            return (
              <View key={i} style={{ marginBottom: 12, borderWidth: 1, borderColor: COLORS.line, borderRadius: 4, padding: 8 }} wrap={false}>
                <Text style={{ fontSize: 10, fontFamily: "Helvetica-Bold", color: COLORS.brand, marginBottom: 4 }}>
                  {ad.platform} — {ad.format}
                </Text>

                {ad.searchAd && (
                  <View>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Headlines: </Text>{ad.searchAd.headlines.filter(Boolean).join(" | ")}</Text>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Descriptions: </Text>{ad.searchAd.descriptions.filter(Boolean).join(" | ")}</Text>
                    {ad.searchAd.displayPath.filter(Boolean).length > 0 && (
                      <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Display Path: </Text>/{ad.searchAd.displayPath.filter(Boolean).join("/")}</Text>
                    )}
                    {ad.searchAd.sitelinks.filter((sl) => sl.text).length > 0 && (
                      <Text style={s.subText}>
                        <Text style={{ fontFamily: "Helvetica-Bold" }}>Sitelinks: </Text>
                        {ad.searchAd.sitelinks.filter((sl) => sl.text).map((sl) => `${sl.text} (${sl.description})`).join("  •  ")}
                      </Text>
                    )}
                    {ad.searchAd.callouts.filter(Boolean).length > 0 && (
                      <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Callouts: </Text>{ad.searchAd.callouts.filter(Boolean).join(" | ")}</Text>
                    )}
                    {ad.searchAd.structuredSnippetValues.filter(Boolean).length > 0 && (
                      <Text style={s.subText}>
                        <Text style={{ fontFamily: "Helvetica-Bold" }}>{ad.searchAd.structuredSnippetHeader}: </Text>
                        {ad.searchAd.structuredSnippetValues.filter(Boolean).join(", ")}
                      </Text>
                    )}
                  </View>
                )}

                {ad.displayAd && (
                  <View>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Short Headlines: </Text>{ad.displayAd.headlines.filter(Boolean).join(" | ")}</Text>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Long Headline: </Text>{ad.displayAd.longHeadline}</Text>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Descriptions: </Text>{ad.displayAd.descriptions.filter(Boolean).join(" | ")}</Text>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Business Name: </Text>{ad.displayAd.businessName}</Text>
                  </View>
                )}

                {ad.socialAd && (
                  <View>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Primary Text: </Text>{ad.socialAd.primaryText}</Text>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Headline: </Text>{ad.socialAd.headline}</Text>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Description: </Text>{ad.socialAd.description}</Text>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>CTA Button: </Text>{ad.socialAd.ctaButton}</Text>
                  </View>
                )}

                {ad.videoAd && (
                  <View>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Companion Banner Headline: </Text>{ad.videoAd.companionHeadline}</Text>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>Companion Banner Description: </Text>{ad.videoAd.companionDescription}</Text>
                    <Text style={s.subText}><Text style={{ fontFamily: "Helvetica-Bold" }}>CTA Button: </Text>{ad.videoAd.ctaButton}</Text>
                  </View>
                )}
              </View>
            );
          })}
          <Footer page={pAdCopy} total={totalPages} consultant={consultant} />
        </Page>
      )}

      {/* PAGE 7 — BUDGET & SCENARIO PROJECTIONS */}
      <Page size="A4" style={s.page}>
        <Header consultant={consultant} />
        <Text style={s.pageTitle}>Budget &amp; Scenario Projections</Text>
        <View style={s.table}>
          <View style={s.tr}>
            <Text style={s.thCell}>Metric</Text>
            {scenarios.map((sc) => (
              <Text style={s.thCell} key={sc.label}>
                {sc.label}
              </Text>
            ))}
          </View>
          {(
            [
              ["Budget", (sc: (typeof scenarios)[number]) => formatCurrency(sc.budget, consultant.currency)],
              ["Traffic/Clicks", (sc: (typeof scenarios)[number]) => Math.round(sc.traffic).toLocaleString()],
              ["Leads", (sc: (typeof scenarios)[number]) => Math.round(sc.leads).toLocaleString()],
              ["Qualified Leads", (sc: (typeof scenarios)[number]) => Math.round(sc.qualifiedLeads).toLocaleString()],
              ["Customers", (sc: (typeof scenarios)[number]) => Math.round(sc.customers).toLocaleString()],
              ["Revenue", (sc: (typeof scenarios)[number]) => formatCurrency(Math.round(sc.revenue), consultant.currency)],
              ["CPL", (sc: (typeof scenarios)[number]) => formatCurrency(sc.cpl, consultant.currency)],
              ["CAC", (sc: (typeof scenarios)[number]) => formatCurrency(sc.cac, consultant.currency)],
              ["ROAS", (sc: (typeof scenarios)[number]) => `${sc.roas.toFixed(2)}X`],
              ["ROI", (sc: (typeof scenarios)[number]) => `${sc.roi.toFixed(0)}%`],
            ] as [string, (sc: (typeof scenarios)[number]) => string][]
          ).map(([label, fmt], idx, arr) => (
            <View style={idx === arr.length - 1 ? s.trLast : s.tr} key={label}>
              <Text style={s.tdCell}>{label}</Text>
              {scenarios.map((sc) => (
                <Text style={s.tdCell} key={sc.label + label}>
                  {fmt(sc)}
                </Text>
              ))}
            </View>
          ))}
        </View>
        <Text style={{ fontSize: 8, color: COLORS.sub, marginTop: 10 }}>
          These are scenario-based estimates. Actual results may vary.
        </Text>
        <Text style={{ fontSize: 7, color: COLORS.faint, marginTop: 4 }}>{data.benchmarkDisclaimer}</Text>
        <Footer page={pBudget} total={totalPages} consultant={consultant} />
      </Page>

      {/* PAGE 8 — 30/60/90 GROWTH PLAN */}
      <Page size="A4" style={s.page}>
        <Header consultant={consultant} />
        <Text style={s.pageTitle}>30 / 60 / 90-Day Growth Plan</Text>
        {growthPlan.map((phase) => (
          <View key={phase.phase} style={{ marginBottom: 12 }}>
            <Text style={s.sectionLabel}>{phase.phase}</Text>
            {phase.items.map((item, i) => (
              <View style={s.bulletRow} key={i}>
                <Text style={s.bulletDot}>•</Text>
                <Text style={s.bulletText}>{item}</Text>
              </View>
            ))}
          </View>
        ))}
        <Footer page={pGrowthPlan} total={totalPages} consultant={consultant} />
      </Page>

      {/* PAGE 9 — FINAL BUSINESS GROWTH STORY */}
      <Page size="A4" style={s.page}>
        <Header consultant={consultant} />
        <Text style={s.pageTitle}>Your Business Growth Story</Text>
        {(
          [
            ["Client Problem", problemSolutionStory.problem],
            ["Solution", problemSolutionStory.solution],
            ["Strategy", problemSolutionStory.strategy],
            ["Execution", problemSolutionStory.execution],
            ["Expected Result", problemSolutionStory.expectedResult],
          ] as [string, string][]
        ).map(([label, text], i, arr) => (
          <View key={label}>
            <View style={s.card}>
              <Text style={{ fontSize: 9, fontFamily: "Helvetica-Bold", marginBottom: 3, color: COLORS.brand }}>{label}</Text>
              <Text style={s.bodyText}>{text}</Text>
            </View>
            {i < arr.length - 1 && <Text style={{ textAlign: "center", color: COLORS.brand, marginBottom: 4 }}>↓</Text>}
          </View>
        ))}

        <View style={s.divider} />
        <Text style={{ fontSize: 14, fontFamily: "Helvetica-Bold", textAlign: "center", marginVertical: 10 }}>
          {consultant.ctaText}
        </Text>
        <View style={{ alignItems: "center", marginTop: 6 }}>
          <Text style={{ fontSize: 10, fontFamily: "Helvetica-Bold" }}>{consultant.consultantName}</Text>
          <Text style={{ fontSize: 9, color: COLORS.sub }}>{consultant.companyName}</Text>
          {consultant.phone ? <Text style={{ fontSize: 9, color: COLORS.sub }}>{consultant.phone}</Text> : null}
          {consultant.whatsapp ? <Text style={{ fontSize: 9, color: COLORS.sub }}>WhatsApp: {consultant.whatsapp}</Text> : null}
          {consultant.email ? <Text style={{ fontSize: 9, color: COLORS.sub }}>{consultant.email}</Text> : null}
          {consultant.website ? <Text style={{ fontSize: 9, color: COLORS.sub }}>{consultant.website}</Text> : null}
          {consultant.linkedin ? <Text style={{ fontSize: 9, color: COLORS.sub }}>{consultant.linkedin}</Text> : null}
        </View>
        <Footer page={pStory} total={totalPages} consultant={consultant} />
      </Page>
    </Document>
  );
}
