export const LEAD_STATUSES = [
  "NEW_LEAD",
  "CONTACTED",
  "INTERESTED",
  "AUDIT_SENT",
  "MEETING_SCHEDULED",
  "PROPOSAL_SENT",
  "NEGOTIATION",
  "WON",
  "LOST",
  "FOLLOW_UP",
  "NOT_INTERESTED",
  "ON_HOLD",
] as const;
export type LeadStatus = (typeof LEAD_STATUSES)[number];

export const LEAD_STATUS_LABELS: Record<LeadStatus, string> = {
  NEW_LEAD: "New Lead",
  CONTACTED: "Contacted",
  INTERESTED: "Interested",
  AUDIT_SENT: "Audit Sent",
  MEETING_SCHEDULED: "Meeting Scheduled",
  PROPOSAL_SENT: "Proposal Sent",
  NEGOTIATION: "Negotiation",
  WON: "Won",
  LOST: "Lost",
  FOLLOW_UP: "Follow-up",
  NOT_INTERESTED: "Not Interested",
  ON_HOLD: "On Hold",
};

export const LEAD_STATUS_COLORS: Record<LeadStatus, string> = {
  NEW_LEAD: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200",
  CONTACTED: "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300",
  INTERESTED: "bg-cyan-100 text-cyan-700 dark:bg-cyan-900/40 dark:text-cyan-300",
  AUDIT_SENT: "bg-indigo-100 text-indigo-700 dark:bg-indigo-900/40 dark:text-indigo-300",
  MEETING_SCHEDULED: "bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300",
  PROPOSAL_SENT: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
  NEGOTIATION: "bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300",
  WON: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300",
  LOST: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300",
  FOLLOW_UP: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/40 dark:text-yellow-300",
  NOT_INTERESTED: "bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400",
  ON_HOLD: "bg-stone-100 text-stone-600 dark:bg-stone-800 dark:text-stone-300",
};

export const LEAD_SOURCES = [
  "LINKEDIN",
  "FACEBOOK",
  "INSTAGRAM",
  "WEBSITE",
  "REFERRAL",
  "GOOGLE_MAPS",
  "WHATSAPP",
  "OTHER",
] as const;
export type LeadSource = (typeof LEAD_SOURCES)[number];

export const LEAD_SOURCE_LABELS: Record<LeadSource, string> = {
  LINKEDIN: "LinkedIn",
  FACEBOOK: "Facebook",
  INSTAGRAM: "Instagram",
  WEBSITE: "Website",
  REFERRAL: "Referral",
  GOOGLE_MAPS: "Google Maps",
  WHATSAPP: "WhatsApp",
  OTHER: "Other",
};

export const BUSINESS_GOALS = [
  "Increase website traffic",
  "Increase organic traffic",
  "Improve keyword rankings",
  "Increase leads",
  "Increase qualified leads",
  "Increase sales",
  "Increase revenue",
  "Improve brand awareness",
  "Improve online visibility",
  "Enter new markets",
  "Generate B2B enquiries",
  "Reduce CAC",
  "Improve ROAS",
  "Improve conversion rate",
];

export const ORGANIC_GOALS = [
  "Increase organic traffic",
  "Improve search rankings",
  "Increase search visibility",
  "Increase non-branded traffic",
  "Increase qualified organic leads",
  "Improve local SEO",
  "Build topical authority",
  "Increase organic enquiries",
  "Increase organic conversions",
];

export const PPC_OBJECTIVES = [
  "Website traffic",
  "Lead generation",
  "Sales",
  "Product enquiries",
  "Brand awareness",
  "Remarketing",
  "B2B lead generation",
  "Appointment generation",
  "Store visits where applicable",
];

// Shown only when the consultant flags this business as also having a
// physical/local store to promote (Business Details step) — additional goal
// options layered onto the standard Organic/PPC goals above, reflecting the
// local-search funnel: Google Business Profile -> Search/Maps -> Reviews ->
// Website/Call/WhatsApp -> Qualified Enquiry -> Sales Follow-up -> Purchase
// -> Review + Referral.
export const LOCAL_ORGANIC_GOALS = [
  "Improve Google Business Profile ranking",
  "Increase visibility in the Local (Maps) Pack",
  "Increase Google Business Profile views",
  "Grow review count & rating",
];

export const LOCAL_PPC_OBJECTIVES = [
  "Increase calls from Search/Maps",
  "Increase direction requests",
  "Increase store visits",
  "Increase WhatsApp enquiries from local search",
];

// WhatsApp Marketing — its own campaign channel alongside Organic/PPC
// (Organic & PPC step), since it's a distinct, plannable channel in its own
// right, not just an outcome of the other two.
export const WHATSAPP_MARKETING_GOALS = [
  "Click-to-WhatsApp ads for lead generation",
  "Broadcast offers & promotions to opted-in customers",
  "Automated quick replies / FAQ catalogue",
  "Product catalogue sharing",
  "Abandoned cart / enquiry follow-up",
  "Post-purchase order updates & shipping notifications",
  "Review & referral requests after purchase",
  "Appointment / booking reminders",
];

// Standard local-SEO / Google Business Profile best practices — general
// industry practice, never claims specific to this business's actual
// listing (that would need a paid Places API, which isn't configured; see
// the Local Presence Notes field for the consultant's own manual read of
// each listing). Same non-fabrication approach as STRATEGIC_RECOMMENDATIONS
// in recommendations.ts.
export const LOCAL_BRANDING_RECOMMENDATIONS = [
  "Claim and fully verify the Google Business Profile for every location.",
  "Keep NAP (Name, Address, Phone) 100% consistent across the website, GBP and all directories.",
  "Complete every GBP field — categories, service areas, attributes, products/services, business description.",
  "Add fresh, high-quality photos and videos regularly (exterior, interior, team, products/services).",
  "Post weekly updates and offers via Google Posts to stay active in local search.",
  "Respond to every review — positive and negative — within 24-48 hours.",
  "Build a steady flow of new reviews with a simple ask (in-store signage, WhatsApp/SMS after purchase, receipt QR code).",
  "Enable messaging / click-to-WhatsApp on the profile so 'near me' searchers can reach out instantly.",
  "Add a booking/appointment link if the business takes bookings.",
  "Use local keywords naturally in the business description and Google Posts.",
  "Link the website to the GBP listing and embed a Google Map on the Contact page.",
  "Build local citations on major and industry-specific directories with identical NAP.",
];

export const AD_PLATFORMS = [
  "Google Search",
  "Google Display",
  "YouTube",
  "Facebook",
  "Instagram",
  "WhatsApp",
  "LinkedIn",
  "Microsoft Ads",
];

// Fallback Ad type / Expected result shown on the Audience step's
// "Platform-Wise Ad Type & Expected Result" card for WhatsApp, since it isn't
// one of the per-business-vertical platform suggestions in recommendations.ts
// (those cover the paid search/social networks). Click-to-WhatsApp ads run
// through Meta Ads Manager, so this is a real, defensible ad type — not a
// guess about this specific business's results.
export const WHATSAPP_PLATFORM_DETAIL = {
  adType: "Click-to-WhatsApp ads (via Meta Ads Manager)",
  expectedResult:
    "Opens a direct 1:1 WhatsApp chat with an interested prospect — typically faster replies and higher engagement than a contact form, feeding straight into the WhatsApp Marketing follow-up flow.",
};

export const WEBSITE_TYPES = [
  "Corporate website",
  "Business website",
  "Lead-generation website",
  "E-commerce website",
  "Product catalogue",
  "Service website",
  "Landing page",
];

// Crisp, catchy detail for each website type, shown on the Audit/Info step
// when there's no existing website to recommend the right foundation instead
// of a bare dropdown. Same non-fabrication rule as everywhere else — these
// describe the website TYPE in general (a real, well-known category), never
// a claim about how this specific business's site will perform.
export const WEBSITE_TYPE_DETAILS: Record<
  string,
  { description: string; idealFor: string; suggestedPages: string[] }
> = {
  "Corporate website": {
    description:
      "The brand's digital HQ — polished and credible, built to reassure rather than hard-sell. First stop for partners and press as much as customers.",
    idealFor: "Established or multi-location businesses that need brand presence and trust more than an immediate lead form.",
    suggestedPages: ["Home", "About Us", "Our Story", "Leadership", "Careers", "Contact"],
  },
  "Business website": {
    description:
      "The reliable all-rounder — explains who you are, what you offer and why to trust you, all in one clean, professional home base.",
    idealFor: "Most small and mid-size businesses that want one credible site covering services, team and contact.",
    suggestedPages: ["Home", "About", "Services", "Testimonials", "FAQ", "Contact"],
  },
  "Lead-generation website": {
    description:
      "Built around one job: turning visitors into enquiries. Clear value proposition, trust signals, and a quote/contact form on every page.",
    idealFor: "Service businesses running paid or organic campaigns, aiming for calls, form fills or quote requests.",
    suggestedPages: ["Home", "Services", "Why Choose Us", "Testimonials", "Get a Quote"],
  },
  "E-commerce website": {
    description: "A full online store — browse, add to cart, checkout and pay. Product pages do the selling, around the clock.",
    idealFor: "Businesses selling products directly online, with delivery or shipping already sorted out.",
    suggestedPages: ["Home", "Shop", "Product Detail", "Cart", "Checkout", "About", "Contact"],
  },
  "Product catalogue": {
    description:
      "Shows off the full range with rich detail and photography — no online checkout. Every enquiry closes with a real conversation, not a cart.",
    idealFor: "High-value, custom or bespoke products better sold over a call, WhatsApp or in-store visit.",
    suggestedPages: ["Home", "Catalogue", "Product Detail", "About", "Enquire"],
  },
  "Service website": {
    description:
      "Speaks to one core service (or a tight set of them) — the problem it solves, how it works, and how to book it. Focused beats broad.",
    idealFor: "Single-service or niche providers who want a sharp pitch instead of a scattered multi-service site.",
    suggestedPages: ["Home", "The Service", "How It Works", "Pricing", "Testimonials", "Book Now"],
  },
  "Landing page": {
    description: "One page, one offer, one action — every distraction stripped away so the visitor does exactly one thing.",
    idealFor: "A single campaign, launch or promotion where every visitor should take the same next step.",
    suggestedPages: ["Home"],
  },
};

export const CURRENCIES = ["USD", "INR", "AED", "SAR", "GBP", "EUR"] as const;

export const REGIONS = ["Global", "India", "UAE", "Saudi Arabia", "USA", "UK", "Other"];

// Countries for the "Target Country" selector in the assessment wizard — used
// to steer the auto-suggested target audience toward real, widely-known
// digital-behavior patterns for that market (see COUNTRY_AUDIENCE_NOTES in
// recommendations.ts). Not every micro-territory is listed — this covers
// recognised sovereign states plus a handful of major distinct markets
// (Hong Kong, Puerto Rico, etc.). "India" is the default selection.
export const COUNTRIES = [
  "Afghanistan","Albania","Algeria","American Samoa","Andorra","Angola","Anguilla","Antigua & Barbuda","Argentina","Armenia","Aruba","Australia","Austria","Azerbaijan",
  "Bahamas","Bahrain","Bangladesh","Barbados","Belarus","Belgium","Belize","Benin","Bermuda","Bhutan","Bolivia","Bosnia & Herzegovina","Botswana","Brazil","British Virgin Islands","Brunei","Bulgaria","Burkina Faso","Burundi",
  "Cambodia","Cameroon","Canada","Cape Verde","Cayman Islands","Central African Republic","Chad","Chile","China","Colombia","Comoros","Congo - Brazzaville","Congo - Kinshasa","Cook Islands","Costa Rica","Côte d’Ivoire","Croatia","Cuba","Curaçao","Cyprus","Czechia",
  "Denmark","Djibouti","Dominica","Dominican Republic",
  "Ecuador","Egypt","El Salvador","Equatorial Guinea","Eritrea","Estonia","Eswatini","Ethiopia",
  "Falkland Islands","Faroe Islands","Fiji","Finland","France","French Guiana","French Polynesia",
  "Gabon","Gambia","Georgia","Germany","Ghana","Gibraltar","Greece","Greenland","Grenada","Guadeloupe","Guam","Guatemala","Guinea","Guinea-Bissau","Guyana",
  "Haiti","Honduras","Hong Kong SAR China","Hungary",
  "Iceland","India","Indonesia","Iran","Iraq","Ireland","Israel","Italy",
  "Jamaica","Japan","Jordan",
  "Kazakhstan","Kenya","Kiribati","Kuwait","Kyrgyzstan",
  "Laos","Latvia","Lebanon","Lesotho","Liberia","Libya","Liechtenstein","Lithuania","Luxembourg",
  "Macao SAR China","Madagascar","Malawi","Malaysia","Maldives","Mali","Malta","Marshall Islands","Martinique","Mauritania","Mauritius","Mexico","Micronesia","Moldova","Monaco","Mongolia","Montenegro","Montserrat","Morocco","Mozambique","Myanmar (Burma)",
  "Namibia","Nauru","Nepal","Netherlands","New Caledonia","New Zealand","Nicaragua","Niger","Nigeria","North Korea","North Macedonia","Northern Mariana Islands","Norway",
  "Oman",
  "Pakistan","Palau","Palestinian Territories","Panama","Papua New Guinea","Paraguay","Peru","Philippines","Poland","Portugal","Puerto Rico",
  "Qatar",
  "Romania","Russia","Rwanda",
  "Samoa","San Marino","São Tomé & Príncipe","Saudi Arabia","Senegal","Serbia","Seychelles","Sierra Leone","Singapore","Sint Maarten","Slovakia","Slovenia","Solomon Islands","Somalia","South Africa","South Korea","South Sudan","Spain","Sri Lanka","St. Kitts & Nevis","St. Lucia","St. Vincent & Grenadines","Sudan","Suriname","Sweden","Switzerland","Syria",
  "Taiwan","Tajikistan","Tanzania","Thailand","Timor-Leste","Togo","Tonga","Trinidad & Tobago","Tunisia","Türkiye","Turkmenistan","Turks & Caicos Islands","Tuvalu",
  "U.S. Virgin Islands","Uganda","Ukraine","United Arab Emirates","United Kingdom","United States","Uruguay","Uzbekistan",
  "Vanuatu","Vatican City","Venezuela","Vietnam",
  "Western Sahara",
  "Yemen",
  "Zambia","Zimbabwe",
  "Other",
];

// Each COUNTRIES entry's real, official ISO 4217 currency code — used to pick
// the currency symbol shown throughout the forecast/report once a consultant
// selects a Target Country, instead of always defaulting to USD. This is
// factual reference data (which currency a country actually uses), not a
// business-specific claim. "Other" has no entry and falls back to USD in
// currencyForCountry() below.
export const COUNTRY_CURRENCY: Record<string, string> = {
  "Afghanistan": "AFN",
  "Albania": "ALL",
  "Algeria": "DZD",
  "American Samoa": "USD",
  "Andorra": "EUR",
  "Angola": "AOA",
  "Anguilla": "XCD",
  "Antigua & Barbuda": "XCD",
  "Argentina": "ARS",
  "Armenia": "AMD",
  "Aruba": "AWG",
  "Australia": "AUD",
  "Austria": "EUR",
  "Azerbaijan": "AZN",
  "Bahamas": "BSD",
  "Bahrain": "BHD",
  "Bangladesh": "BDT",
  "Barbados": "BBD",
  "Belarus": "BYN",
  "Belgium": "EUR",
  "Belize": "BZD",
  "Benin": "XOF",
  "Bermuda": "BMD",
  "Bhutan": "BTN",
  "Bolivia": "BOB",
  "Bosnia & Herzegovina": "BAM",
  "Botswana": "BWP",
  "Brazil": "BRL",
  "British Virgin Islands": "USD",
  "Brunei": "BND",
  "Bulgaria": "BGN",
  "Burkina Faso": "XOF",
  "Burundi": "BIF",
  "Cambodia": "KHR",
  "Cameroon": "XAF",
  "Canada": "CAD",
  "Cape Verde": "CVE",
  "Cayman Islands": "KYD",
  "Central African Republic": "XAF",
  "Chad": "XAF",
  "Chile": "CLP",
  "China": "CNY",
  "Colombia": "COP",
  "Comoros": "KMF",
  "Congo - Brazzaville": "XAF",
  "Congo - Kinshasa": "CDF",
  "Cook Islands": "NZD",
  "Costa Rica": "CRC",
  "Croatia": "EUR",
  "Cuba": "CUP",
  "Curaçao": "ANG",
  "Cyprus": "EUR",
  "Czechia": "CZK",
  "Côte d’Ivoire": "XOF",
  "Denmark": "DKK",
  "Djibouti": "DJF",
  "Dominica": "XCD",
  "Dominican Republic": "DOP",
  "Ecuador": "USD",
  "Egypt": "EGP",
  "El Salvador": "USD",
  "Equatorial Guinea": "XAF",
  "Eritrea": "ERN",
  "Estonia": "EUR",
  "Eswatini": "SZL",
  "Ethiopia": "ETB",
  "Falkland Islands": "FKP",
  "Faroe Islands": "DKK",
  "Fiji": "FJD",
  "Finland": "EUR",
  "France": "EUR",
  "French Guiana": "EUR",
  "French Polynesia": "XPF",
  "Gabon": "XAF",
  "Gambia": "GMD",
  "Georgia": "GEL",
  "Germany": "EUR",
  "Ghana": "GHS",
  "Gibraltar": "GIP",
  "Greece": "EUR",
  "Greenland": "DKK",
  "Grenada": "XCD",
  "Guadeloupe": "EUR",
  "Guam": "USD",
  "Guatemala": "GTQ",
  "Guinea": "GNF",
  "Guinea-Bissau": "XOF",
  "Guyana": "GYD",
  "Haiti": "HTG",
  "Honduras": "HNL",
  "Hong Kong SAR China": "HKD",
  "Hungary": "HUF",
  "Iceland": "ISK",
  "India": "INR",
  "Indonesia": "IDR",
  "Iran": "IRR",
  "Iraq": "IQD",
  "Ireland": "EUR",
  "Israel": "ILS",
  "Italy": "EUR",
  "Jamaica": "JMD",
  "Japan": "JPY",
  "Jordan": "JOD",
  "Kazakhstan": "KZT",
  "Kenya": "KES",
  "Kiribati": "AUD",
  "Kuwait": "KWD",
  "Kyrgyzstan": "KGS",
  "Laos": "LAK",
  "Latvia": "EUR",
  "Lebanon": "LBP",
  "Lesotho": "LSL",
  "Liberia": "LRD",
  "Libya": "LYD",
  "Liechtenstein": "CHF",
  "Lithuania": "EUR",
  "Luxembourg": "EUR",
  "Macao SAR China": "MOP",
  "Madagascar": "MGA",
  "Malawi": "MWK",
  "Malaysia": "MYR",
  "Maldives": "MVR",
  "Mali": "XOF",
  "Malta": "EUR",
  "Marshall Islands": "USD",
  "Martinique": "EUR",
  "Mauritania": "MRU",
  "Mauritius": "MUR",
  "Mexico": "MXN",
  "Micronesia": "USD",
  "Moldova": "MDL",
  "Monaco": "EUR",
  "Mongolia": "MNT",
  "Montenegro": "EUR",
  "Montserrat": "XCD",
  "Morocco": "MAD",
  "Mozambique": "MZN",
  "Myanmar (Burma)": "MMK",
  "Namibia": "NAD",
  "Nauru": "AUD",
  "Nepal": "NPR",
  "Netherlands": "EUR",
  "New Caledonia": "XPF",
  "New Zealand": "NZD",
  "Nicaragua": "NIO",
  "Niger": "XOF",
  "Nigeria": "NGN",
  "North Korea": "KPW",
  "North Macedonia": "MKD",
  "Northern Mariana Islands": "USD",
  "Norway": "NOK",
  "Oman": "OMR",
  "Pakistan": "PKR",
  "Palau": "USD",
  "Palestinian Territories": "ILS",
  "Panama": "PAB",
  "Papua New Guinea": "PGK",
  "Paraguay": "PYG",
  "Peru": "PEN",
  "Philippines": "PHP",
  "Poland": "PLN",
  "Portugal": "EUR",
  "Puerto Rico": "USD",
  "Qatar": "QAR",
  "Romania": "RON",
  "Russia": "RUB",
  "Rwanda": "RWF",
  "Samoa": "WST",
  "San Marino": "EUR",
  "Saudi Arabia": "SAR",
  "Senegal": "XOF",
  "Serbia": "RSD",
  "Seychelles": "SCR",
  "Sierra Leone": "SLL",
  "Singapore": "SGD",
  "Sint Maarten": "ANG",
  "Slovakia": "EUR",
  "Slovenia": "EUR",
  "Solomon Islands": "SBD",
  "Somalia": "SOS",
  "South Africa": "ZAR",
  "South Korea": "KRW",
  "South Sudan": "SSP",
  "Spain": "EUR",
  "Sri Lanka": "LKR",
  "St. Kitts & Nevis": "XCD",
  "St. Lucia": "XCD",
  "St. Vincent & Grenadines": "XCD",
  "Sudan": "SDG",
  "Suriname": "SRD",
  "Sweden": "SEK",
  "Switzerland": "CHF",
  "Syria": "SYP",
  "São Tomé & Príncipe": "STN",
  "Taiwan": "TWD",
  "Tajikistan": "TJS",
  "Tanzania": "TZS",
  "Thailand": "THB",
  "Timor-Leste": "USD",
  "Togo": "XOF",
  "Tonga": "TOP",
  "Trinidad & Tobago": "TTD",
  "Tunisia": "TND",
  "Turkmenistan": "TMT",
  "Turks & Caicos Islands": "USD",
  "Tuvalu": "AUD",
  "Türkiye": "TRY",
  "U.S. Virgin Islands": "USD",
  "Uganda": "UGX",
  "Ukraine": "UAH",
  "United Arab Emirates": "AED",
  "United Kingdom": "GBP",
  "United States": "USD",
  "Uruguay": "UYU",
  "Uzbekistan": "UZS",
  "Vanuatu": "VUV",
  "Vatican City": "EUR",
  "Venezuela": "VES",
  "Vietnam": "VND",
  "Western Sahara": "MAD",
  "Yemen": "YER",
  "Zambia": "ZMW",
  "Zimbabwe": "ZWL",
};

/** Currency code for a Target Country selection — falls back to USD for "Other" or an unrecognised value. */
export function currencyForCountry(country: string | undefined | null): string {
  return (country && COUNTRY_CURRENCY[country]) || "USD";
}

export const INDUSTRIES = [
  "Advocacy",
  "Apparel",
  "Auto",
  "B2B",
  "Beauty",
  "Consumer Services",
  "Dating & Personals",
  "E-Commerce",
  "Education",
  "Employment & Job Training",
  "Employment Services",
  "Finance & Insurance",
  "Fitness",
  "Health & Medical",
  "Healthcare",
  "Home Goods",
  "Home Improvement",
  "Industrial Services",
  "Legal",
  "Real Estate",
  "Retail",
  "Technology",
  "Travel & Hospitality",
];

export const AUDIT_CATEGORIES = [
  { key: "technicalSeo", label: "Technical SEO" },
  { key: "onPageSeo", label: "On-Page SEO" },
  { key: "content", label: "Content" },
  { key: "uxConversion", label: "UX & Conversion" },
  { key: "branding", label: "Branding" },
  { key: "localSeo", label: "Local SEO" },
  { key: "performance", label: "Performance" },
] as const;

export function auditStatusLabel(score: number): "Critical" | "Needs Improvement" | "Good" | "Excellent" {
  if (score < 40) return "Critical";
  if (score < 65) return "Needs Improvement";
  if (score < 85) return "Good";
  return "Excellent";
}

export const BENCHMARK_DISCLAIMER =
  "Industry benchmarks are indicative reference values. Actual advertising costs and conversion performance vary based on geography, competition, audience, offer, creative quality, landing-page experience, campaign optimisation and market conditions.";

export const DATA_UNAVAILABLE = "Data unavailable – requires external tool/account access.";
