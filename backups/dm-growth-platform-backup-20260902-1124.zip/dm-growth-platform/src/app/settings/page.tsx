"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api-client";
import { PageHeading, Card, Field, Input, Textarea, Button, Spinner, Select } from "@/components/ui";
import { CURRENCIES } from "@/lib/constants";

interface Settings {
  consultantName: string;
  companyName: string;
  phone: string;
  whatsapp: string;
  email: string;
  website: string;
  linkedin: string;
  address: string;
  reportFooter: string;
  ctaText: string;
  currency: string;
  defaultQualificationRate: number;
  aiImageApiKey: string | null;
}

export default function SettingsPage() {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    api.get<Settings>("/api/settings").then(setSettings);
  }, []);

  function set<K extends keyof Settings>(key: K, value: Settings[K]) {
    setSettings((s) => (s ? { ...s, [key]: value } : s));
    setSaved(false);
  }

  async function save() {
    if (!settings) return;
    setSaving(true);
    await api.patch("/api/settings", settings);
    setSaving(false);
    setSaved(true);
  }

  if (!settings) return <div className="flex justify-center py-20"><Spinner /></div>;

  return (
    <div className="max-w-2xl">
      <PageHeading title="Consultant Settings" subtitle="These details are automatically used on every generated PDF report." />
      <Card className="p-5 space-y-4">
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Consultant Name"><Input value={settings.consultantName} onChange={(e) => set("consultantName", e.target.value)} /></Field>
          <Field label="Company / Brand"><Input value={settings.companyName} onChange={(e) => set("companyName", e.target.value)} /></Field>
          <Field label="Phone"><Input value={settings.phone ?? ""} onChange={(e) => set("phone", e.target.value)} /></Field>
          <Field label="WhatsApp"><Input value={settings.whatsapp ?? ""} onChange={(e) => set("whatsapp", e.target.value)} /></Field>
          <Field label="Email"><Input type="email" value={settings.email ?? ""} onChange={(e) => set("email", e.target.value)} /></Field>
          <Field label="Website"><Input value={settings.website ?? ""} onChange={(e) => set("website", e.target.value)} /></Field>
          <Field label="LinkedIn"><Input value={settings.linkedin ?? ""} onChange={(e) => set("linkedin", e.target.value)} /></Field>
          <Field label="Currency">
            <Select value={settings.currency} onChange={(e) => set("currency", e.target.value)}>
              {CURRENCIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </Select>
          </Field>
          <Field label="Default Qualification Rate %">
            <Input type="number" value={settings.defaultQualificationRate} onChange={(e) => set("defaultQualificationRate", Number(e.target.value))} />
          </Field>
        </div>
        <Field label="Address"><Textarea value={settings.address ?? ""} onChange={(e) => set("address", e.target.value)} /></Field>
        <Field label="Report Footer"><Input value={settings.reportFooter ?? ""} onChange={(e) => set("reportFooter", e.target.value)} /></Field>
        <Field label="PDF Call-to-Action"><Textarea value={settings.ctaText} onChange={(e) => set("ctaText", e.target.value)} /></Field>
        <div className="flex items-center gap-3 pt-2">
          <Button onClick={save} disabled={saving}>{saving ? "Saving…" : "Save Settings"}</Button>
          {saved && <span className="text-sm text-emerald-600">Saved.</span>}
        </div>
      </Card>

      <Card className="p-5 space-y-3 mt-6">
        <div>
          <p className="text-sm font-semibold text-slate-900 dark:text-white">AI Image Generation (optional)</p>
          <p className="text-xs text-slate-400 mt-1">
            Powers real, generated Image Ad concepts in the Sample Ads step of the assessment wizard (using OpenAI&apos;s DALL·E 3).
            Left blank, image generation is simply unavailable there — nothing is faked in its place. Each image you
            generate is billed by OpenAI to this key; images are only generated when you click &quot;Generate Image&quot; on a
            specific ad concept, never automatically.
          </p>
        </div>
        <Field label="OpenAI API Key" hint="Starts with sk-… Get one at platform.openai.com/api-keys.">
          <Input
            type="password"
            value={settings.aiImageApiKey ?? ""}
            onChange={(e) => set("aiImageApiKey", e.target.value)}
            placeholder="sk-…"
            className="max-w-md"
            autoComplete="off"
          />
        </Field>
        <div className="flex items-center gap-3 pt-1">
          <Button onClick={save} disabled={saving}>{saving ? "Saving…" : "Save Settings"}</Button>
          {saved && <span className="text-sm text-emerald-600">Saved.</span>}
        </div>
      </Card>
    </div>
  );
}
