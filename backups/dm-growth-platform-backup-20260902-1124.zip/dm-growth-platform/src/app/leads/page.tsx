"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { api } from "@/lib/api-client";
import { PageHeading, Card, Badge, Input, Select, Spinner, LinkButton, EmptyState } from "@/components/ui";
import { LEAD_STATUSES, LEAD_STATUS_LABELS, LEAD_STATUS_COLORS, type LeadStatus } from "@/lib/constants";

interface Lead {
  id: string;
  customerId: string;
  customerName: string;
  businessName: string;
  city?: string | null;
  country?: string | null;
  status: string;
  leadSource: string;
  quoteValue?: number | null;
  createdAt: string;
}

export default function LeadsPage() {
  const [leads, setLeads] = useState<Lead[] | null>(null);
  const [statusFilter, setStatusFilter] = useState("");
  const [query, setQuery] = useState("");

  useEffect(() => {
    const url = statusFilter ? `/api/leads?status=${statusFilter}` : "/api/leads";
    api.get<Lead[]>(url).then(setLeads);
  }, [statusFilter]);

  const filtered = useMemo(() => {
    if (!leads) return [];
    if (!query.trim()) return leads;
    const q = query.toLowerCase();
    return leads.filter(
      (l) =>
        l.businessName.toLowerCase().includes(q) ||
        l.customerName.toLowerCase().includes(q) ||
        l.customerId.toLowerCase().includes(q)
    );
  }, [leads, query]);

  return (
    <div>
      <PageHeading
        title="Leads"
        subtitle="All prospects and customers."
        action={<LinkButton href="/leads/new">+ Add Lead</LinkButton>}
      />

      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <Input placeholder="Search by name, business or ID…" value={query} onChange={(e) => setQuery(e.target.value)} className="sm:max-w-xs" />
        <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="sm:max-w-xs">
          <option value="">All statuses</option>
          {LEAD_STATUSES.map((s) => (
            <option key={s} value={s}>
              {LEAD_STATUS_LABELS[s]}
            </option>
          ))}
        </Select>
      </div>

      {!leads ? (
        <div className="flex justify-center py-16">
          <Spinner />
        </div>
      ) : filtered.length === 0 ? (
        <EmptyState title="No leads found" subtitle="Try a different search or add a new lead." action={<LinkButton href="/leads/new">+ Add Lead</LinkButton>} />
      ) : (
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 dark:bg-slate-800/50 text-left text-xs text-slate-500 dark:text-slate-400">
                <tr>
                  <th className="px-4 py-3 font-medium">Business</th>
                  <th className="px-4 py-3 font-medium hidden sm:table-cell">Contact</th>
                  <th className="px-4 py-3 font-medium hidden md:table-cell">Location</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 font-medium hidden lg:table-cell">Quote Value</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filtered.map((lead) => (
                  <tr key={lead.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="px-4 py-3">
                      <Link href={`/leads/${lead.id}`} className="block">
                        <div className="font-medium text-slate-900 dark:text-white">{lead.businessName}</div>
                        <div className="text-xs text-slate-400">{lead.customerId}</div>
                      </Link>
                    </td>
                    <td className="px-4 py-3 hidden sm:table-cell text-slate-600 dark:text-slate-300">{lead.customerName}</td>
                    <td className="px-4 py-3 hidden md:table-cell text-slate-500">
                      {[lead.city, lead.country].filter(Boolean).join(", ") || "—"}
                    </td>
                    <td className="px-4 py-3">
                      <Badge className={LEAD_STATUS_COLORS[lead.status as LeadStatus]}>
                        {LEAD_STATUS_LABELS[lead.status as LeadStatus] ?? lead.status}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 hidden lg:table-cell text-slate-500">
                      {lead.quoteValue ? lead.quoteValue.toLocaleString() : "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}
