"use client";

import { useEffect, useState, useCallback } from "react";
import { useParams } from "next/navigation";
import { api } from "@/lib/api-client";
import { PageHeading, Card, CardHeader, Badge, Select, Button, Spinner, Input, LinkButton, Textarea } from "@/components/ui";
import { LEAD_STATUSES, LEAD_STATUS_LABELS, LEAD_STATUS_COLORS, type LeadStatus } from "@/lib/constants";
import { formatCurrency, formatRoas } from "@/lib/calculations";
import { CheckCircle2, Circle, Plus } from "lucide-react";

interface Lead {
  id: string;
  customerId: string;
  customerName: string;
  businessName: string;
  email?: string | null;
  phone?: string | null;
  whatsapp?: string | null;
  city?: string | null;
  state?: string | null;
  country?: string | null;
  websiteUrl?: string | null;
  businessVertical?: string | null;
  status: string;
  quoteValue?: number | null;
  notes?: string | null;
  hasWebsite?: string | null;
}

interface FollowUp {
  id: string;
  type: string;
  note?: string | null;
  dueDate?: string | null;
  completed: boolean;
  createdAt: string;
}

interface Scenario {
  id: string;
  name: string;
  tier: string;
  adBudget: number;
  results: string;
  createdAt: string;
}

interface ReportRow {
  id: string;
  createdAt: string;
  pdfFileName?: string | null;
}

interface LeadDetail {
  lead: Lead;
  followUps: FollowUp[];
  assessments: Array<{ id: string; createdAt: string }>;
  scenarios: Scenario[];
  reports: ReportRow[];
}

export default function LeadDetailPage() {
  const params = useParams();
  const id = params.id as string;
  const [data, setData] = useState<LeadDetail | null>(null);
  const [savingStatus, setSavingStatus] = useState(false);
  const [newFollowUp, setNewFollowUp] = useState({ type: "Call", note: "", dueDate: "" });
  const [addingFollowUp, setAddingFollowUp] = useState(false);
  const [notesDraft, setNotesDraft] = useState("");
  const [savingNotes, setSavingNotes] = useState(false);

  const load = useCallback(() => {
    api.get<LeadDetail>(`/api/leads/${id}`).then((d) => {
      setData(d);
      setNotesDraft(d.lead.notes ?? "");
    });
  }, [id]);

  useEffect(() => {
    if (id) load();
  }, [id, load]);

  if (!data) return <div className="flex justify-center py-20"><Spinner /></div>;
  const { lead, followUps, scenarios, reports } = data;

  async function updateStatus(status: string) {
    setSavingStatus(true);
    await api.patch(`/api/leads/${id}`, { status });
    await load();
    setSavingStatus(false);
  }

  async function saveNotes() {
    setSavingNotes(true);
    await api.patch(`/api/leads/${id}`, { notes: notesDraft });
    setSavingNotes(false);
  }

  async function addFollowUp(e: React.FormEvent) {
    e.preventDefault();
    setAddingFollowUp(true);
    await api.post(`/api/leads/${id}/follow-ups`, {
      type: newFollowUp.type,
      note: newFollowUp.note || undefined,
      dueDate: newFollowUp.dueDate || undefined,
    });
    setNewFollowUp({ type: "Call", note: "", dueDate: "" });
    setAddingFollowUp(false);
    await load();
  }

  async function toggleFollowUp(fu: FollowUp) {
    await api.patch(`/api/follow-ups/${fu.id}`, { completed: !fu.completed });
    await load();
  }

  const now = new Date();
  const sortedFollowUps = [...followUps].sort((a, b) => {
    const ad = a.dueDate ? new Date(a.dueDate).getTime() : Infinity;
    const bd = b.dueDate ? new Date(b.dueDate).getTime() : Infinity;
    return ad - bd;
  });

  return (
    <div>
      <PageHeading
        title={lead.businessName}
        subtitle={`${lead.customerId} · ${lead.customerName}`}
        action={
          <div className="flex flex-wrap gap-2">
            <LinkButton href={`/assessment/new?leadId=${id}`} variant="secondary" size="sm">Run Assessment</LinkButton>
            <LinkButton href={`/scenarios?leadId=${id}`} variant="secondary" size="sm">Scenarios</LinkButton>
          </div>
        }
      />

      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-4">
          <Card className="p-5">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
              <Badge className={LEAD_STATUS_COLORS[lead.status as LeadStatus]}>
                {LEAD_STATUS_LABELS[lead.status as LeadStatus] ?? lead.status}
              </Badge>
              <Select
                value={lead.status}
                disabled={savingStatus}
                onChange={(e) => updateStatus(e.target.value)}
                className="w-auto"
              >
                {LEAD_STATUSES.map((s) => (
                  <option key={s} value={s}>{LEAD_STATUS_LABELS[s]}</option>
                ))}
              </Select>
            </div>
            <dl className="grid sm:grid-cols-2 gap-x-6 gap-y-3 text-sm">
              <Info label="Email" value={lead.email} />
              <Info label="Phone" value={lead.phone} />
              <Info label="WhatsApp" value={lead.whatsapp} />
              <Info label="Website" value={lead.websiteUrl} />
              <Info label="Location" value={[lead.city, lead.state, lead.country].filter(Boolean).join(", ")} />
              <Info label="Industry" value={lead.businessVertical} />
              <Info label="Has Website" value={lead.hasWebsite === "YES" ? "Yes" : lead.hasWebsite === "NO" ? "No" : undefined} />
              <Info label="Quote Value" value={lead.quoteValue ? formatCurrency(lead.quoteValue) : undefined} />
            </dl>
          </Card>

          <Card>
            <CardHeader title="Notes" />
            <div className="p-4 space-y-3">
              <Textarea value={notesDraft} onChange={(e) => setNotesDraft(e.target.value)} rows={4} />
              <Button size="sm" onClick={saveNotes} disabled={savingNotes}>{savingNotes ? "Saving…" : "Save Notes"}</Button>
            </div>
          </Card>

          <Card>
            <CardHeader title="Follow-up Timeline" />
            <div className="p-4 space-y-3">
              {sortedFollowUps.length === 0 && <p className="text-sm text-slate-400">No follow-ups yet.</p>}
              {sortedFollowUps.map((fu) => {
                const overdue = fu.dueDate && !fu.completed && new Date(fu.dueDate) < now;
                return (
                  <div key={fu.id} className="flex items-start gap-3">
                    <button onClick={() => toggleFollowUp(fu)} className="mt-0.5 text-indigo-600 shrink-0">
                      {fu.completed ? <CheckCircle2 size={18} /> : <Circle size={18} className={overdue ? "text-red-500" : "text-slate-300"} />}
                    </button>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={`text-sm font-medium ${fu.completed ? "line-through text-slate-400" : "text-slate-800 dark:text-slate-200"}`}>
                          {fu.type}
                        </span>
                        {fu.dueDate && (
                          <span className={`text-xs ${overdue ? "text-red-500 font-medium" : "text-slate-400"}`}>
                            {overdue ? "Overdue: " : "Due "}
                            {new Date(fu.dueDate).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                      {fu.note && <p className="text-xs text-slate-500 mt-0.5">{fu.note}</p>}
                    </div>
                  </div>
                );
              })}

              <form onSubmit={addFollowUp} className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row gap-2">
                <Select
                  value={newFollowUp.type}
                  onChange={(e) => setNewFollowUp((f) => ({ ...f, type: e.target.value }))}
                  className="sm:w-40"
                >
                  {["Call", "WhatsApp", "Email", "Meeting", "Note", "Proposal", "Quote"].map((t) => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </Select>
                <Input
                  placeholder="Note (optional)"
                  value={newFollowUp.note}
                  onChange={(e) => setNewFollowUp((f) => ({ ...f, note: e.target.value }))}
                  className="flex-1"
                />
                <Input
                  type="date"
                  value={newFollowUp.dueDate}
                  onChange={(e) => setNewFollowUp((f) => ({ ...f, dueDate: e.target.value }))}
                  className="sm:w-40"
                />
                <Button type="submit" size="sm" disabled={addingFollowUp}>
                  <Plus size={14} /> Add
                </Button>
              </form>
            </div>
          </Card>
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader title="Scenarios" action={<LinkButton href={`/scenarios?leadId=${id}`} variant="ghost" size="sm">Manage →</LinkButton>} />
            <div className="p-4 space-y-2">
              {scenarios.length === 0 && <p className="text-sm text-slate-400">No scenarios saved yet.</p>}
              {scenarios.slice(0, 4).map((sc) => {
                const r = JSON.parse(sc.results);
                const paid = r.paid ?? r;
                return (
                  <div key={sc.id} className="flex items-center justify-between text-sm">
                    <span className="text-slate-700 dark:text-slate-300 truncate">{sc.name}</span>
                    <span className="text-slate-400 text-xs">{formatRoas(paid.roas ?? 0)} ROAS</span>
                  </div>
                );
              })}
            </div>
          </Card>

          <Card>
            <CardHeader title="Reports" />
            <div className="p-4 space-y-2">
              {reports.length === 0 && <p className="text-sm text-slate-400">No reports generated yet.</p>}
              {reports.map((r) => (
                <div key={r.id} className="text-sm text-slate-600 dark:text-slate-300">
                  {new Date(r.createdAt).toLocaleDateString()} — {r.pdfFileName ?? "report.pdf"}
                </div>
              ))}
              <LinkButton href={`/assessment/new?leadId=${id}`} size="sm" variant="secondary" className="mt-2 w-full">
                Generate New Report
              </LinkButton>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function Info({ label, value }: { label: string; value?: string | null }) {
  return (
    <div>
      <dt className="text-xs text-slate-400">{label}</dt>
      <dd className="text-slate-800 dark:text-slate-200">{value || "—"}</dd>
    </div>
  );
}
