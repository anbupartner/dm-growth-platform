import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { leads, followUps, assessments, scenarios, reportSnapshots } from "@/lib/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET(_req: NextRequest, ctx: RouteContext<"/api/leads/[id]">) {
  const { id } = await ctx.params;
  const lead = await db.query.leads.findFirst({ where: eq(leads.id, id) });
  if (!lead) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const [followUpRows, assessmentRows, scenarioRows, reportRows] = await Promise.all([
    db.select().from(followUps).where(eq(followUps.leadId, id)).orderBy(desc(followUps.createdAt)),
    db.select().from(assessments).where(eq(assessments.leadId, id)).orderBy(desc(assessments.createdAt)),
    db.select().from(scenarios).where(eq(scenarios.leadId, id)).orderBy(desc(scenarios.createdAt)),
    db.select().from(reportSnapshots).where(eq(reportSnapshots.leadId, id)).orderBy(desc(reportSnapshots.createdAt)),
  ]);

  return NextResponse.json({ lead, followUps: followUpRows, assessments: assessmentRows, scenarios: scenarioRows, reports: reportRows });
}

export async function PATCH(req: NextRequest, ctx: RouteContext<"/api/leads/[id]">) {
  const { id } = await ctx.params;
  const body = await req.json();

  const prev = await db.query.leads.findFirst({ where: eq(leads.id, id) });
  if (!prev) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const updateData: Record<string, unknown> = { ...body };
  delete updateData.id;
  delete updateData.customerId;
  if (updateData.nextFollowUpDate) updateData.nextFollowUpDate = new Date(updateData.nextFollowUpDate as string);

  const [updated] = await db.update(leads).set(updateData).where(eq(leads.id, id)).returning();

  if (body.status && body.status !== prev.status) {
    await db.insert(followUps).values({
      leadId: id,
      type: "Status Change",
      note: `Status changed from ${prev.status} to ${body.status}.`,
      completed: true,
    });
  }

  return NextResponse.json(updated);
}

export async function DELETE(_req: NextRequest, ctx: RouteContext<"/api/leads/[id]">) {
  const { id } = await ctx.params;
  await db.delete(leads).where(eq(leads.id, id));
  return NextResponse.json({ ok: true });
}
