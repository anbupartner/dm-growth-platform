import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { reportSnapshots } from "@/lib/db/schema";
import { eq } from "drizzle-orm";

// Historical snapshot metadata only (not a re-render). Per spec section 45,
// old reports must keep showing the numbers that were actually used at
// generation time — snapshot.clientInputs / scenarioResults capture that.
export async function GET(_req: NextRequest, ctx: RouteContext<"/api/reports/[id]">) {
  const { id } = await ctx.params;
  const row = await db.query.reportSnapshots.findFirst({ where: eq(reportSnapshots.id, id) });
  if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json(row);
}
