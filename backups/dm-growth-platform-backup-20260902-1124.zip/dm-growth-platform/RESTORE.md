# Restore point — 2026-09-02 11:24 UTC

This is a full snapshot of `dm-growth-platform` at this point in time: source code, the live SQLite database (including its WAL/SHM files, so no in-flight writes are lost), every generated PDF report, and the benchmark seed data — everything needed to put the app back exactly as it was, or to recover from a bad change.

Not included (by design — regenerate instead of restoring): `node_modules/` (reinstall with `npm install`) and `.next/` (rebuilt automatically by `npm run dev` / `npm run build`).

## What state this captures

- All the WhatsApp Marketing, Local Business, clickable Stepper, and richer Website Type / Profit Margin benchmark features delivered across the 2026-09-01 – 2026-09-02 sessions.
- The "Internal Server Error" root-cause fix (self-healing schema + benchmark auto-seed in `src/lib/db/index.ts`), so restoring this snapshot restores a *working* app, not just old files.
- The live lead/assessment data and PDF reports as they existed at backup time.

## How to restore

1. **Full restore (replace everything):**
   - Stop the running `npm run dev` server.
   - Delete (or rename aside) your current `dm-growth-platform` folder's `src/`, `data/`, `public/`, `scripts/`, and the root config files listed below.
   - Unzip this archive over the empty folder.
   - Run `npm install` (rebuilds `node_modules/` — not included in this backup).
   - Run `npm run dev` — the app boots straight from the restored `data/app.db`, no seeding needed.

2. **Partial restore (just the database):**
   - Stop the dev server.
   - Copy `data/app.db`, `data/app.db-shm` and `data/app.db-wal` from this backup over your current `data/` folder (all three together — SQLite needs them as a set).
   - Restart `npm run dev`.

3. **Partial restore (just one file):**
   - Copy the specific file from this backup's `src/...` path over the same path in your live project, then let the dev server pick it up (or restart it).

## Contents

- Root config: `.env`, `.env.example`, `.gitignore`, `AGENTS.md`, `CLAUDE.md`, `README.md`, `drizzle.config.ts`, `eslint.config.mjs`, `next-env.d.ts`, `next.config.ts`, `package.json`, `package-lock.json`, `postcss.config.mjs`, `tsconfig.json`
- `src/` — full application source (86 files total in this backup, including this manifest)
- `public/` — static assets
- `scripts/seed.ts` — first-run seed script
- `data/app.db`, `data/app.db-shm`, `data/app.db-wal` — the live database
- `data/benchmarks/*.json` — benchmark seed data (Google/Meta/LinkedIn/YouTube/Microsoft Ads + the new industry Profit Margin benchmarks)
- `data/reports/*.pdf` — every PDF report generated so far
