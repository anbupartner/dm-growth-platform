# DM Consultant Growth Platform

A web-based Business Growth, Audit, Strategy & Lead Management platform for digital marketing consultants — built from the attached project spec. Runs on any device with a browser (desktop, tablet, mobile) since it's a responsive web app, not a native install.

## What's here (MVP scope)

- **Lead capture wizard** — customer intake, the Yes/No website branch, a real (non-fabricated) website audit, branding notes, organic/PPC strategy, audience & platform recommendations, competitor notes, sample ad concepts, and a full marketing forecast — ending in a generated PDF.
- **Website audit** — fetches the live page and checks HTTPS, title/meta tags, viewport, H1s, canonical, schema, image ALT coverage, content depth, robots.txt and sitemap.xml. Anything that needs a paid API (Core Web Vitals, broken-link crawling) is explicitly marked "Data unavailable" rather than guessed, per the spec's "never fabricate" rule.
- **Calculation engine** (`src/lib/calculations.ts`) — every formula from the spec (Traffic, Leads, Qualified Leads, Customers, Revenue, CPL, CAC, ROAS, Gross Profit, Net Marketing Profit, ROI), centralized in one place. Conservative / Expected / Growth Opportunity scenarios are derived from it, each with its assumption deltas shown.
- **Benchmark database** — Google Ads and Meta CPC/CTR/CVR/CPA by industry, seeded from the spec's tables into `/data/benchmarks/*.json`, loaded into the database (never hard-coded into the frontend). Full admin screen: filter, add, disable, version, import/export CSV. Editing a benchmark creates a new version rather than overwriting history.
- **CRM** — leads with status pipeline, follow-up timeline (today/overdue/upcoming), notes, proposals/quotes tracking, dashboard with pipeline and revenue metrics.
- **PDF reports** — 8-page, client-ready report generated server-side (`@react-pdf/renderer`): executive summary, website recommendations, audit scorecard, branding + competitor insights, visual sample ads, budget/scenario projections, 30/60/90-day plan, and the final problem→solution→strategy→execution→result story with your contact details. Every generated PDF is saved to disk and re-downloads byte-for-byte identical later, even if benchmarks change afterward.
- **Settings** — your consultant profile, used automatically on every PDF.

## Tech stack

- **Next.js 16** (App Router, TypeScript) — React 19, Tailwind CSS 4
- **Drizzle ORM** over **SQLite** for local/dev — zero external services and zero native compilation needed to run it. It uses Node's built-in `node:sqlite` module (stable since Node 22.5) rather than a package like `better-sqlite3`, so `npm install` never needs to compile anything or download prebuilt binaries — it just works, including on machines with no C++ build tools or restricted network access.
- **@react-pdf/renderer** for PDF generation
- **Recharts** for the dashboard charts

We started with Prisma, then `better-sqlite3`, but both depend on downloading native binaries at install time (from Prisma's CDN or GitHub releases respectively) — fine on a typical internet connection, but a real failure mode on a locked-down network or a machine without build tools. Node's own `node:sqlite` module needs neither, so that's what this ships with. It's marked "experimental" by Node (a stability label, not a warning against production use) and you'll see a one-line warning in your terminal when the app starts — that's expected and harmless.

## Getting started

Requires Node.js 22.5 or later (for `node:sqlite`).

```bash
npm install
npm run setup     # creates the SQLite DB, seeds ~164 benchmark rows, consultant settings, and one demo lead
npm run dev        # http://localhost:3000
```

Open the app on your phone or tablet too — it's fully responsive (sidebar nav on desktop/tablet, bottom nav + menu on mobile). To use it from another device on your network, run `npm run dev -- -H 0.0.0.0` and visit `http://<your-computer's-LAN-IP>:3000` from that device.

To build for production:

```bash
npm run build
npm run start
```

## Going to production: cross-device sync

Out of the box this uses a local SQLite file (`data/app.db`) — great for trying it out or running it on one machine, but a lead you add on your laptop won't show up on your phone unless they're both pointed at the same running server.

To get real cross-device sync (the same leads/scenarios/benchmarks visible from your computer, tablet and phone, wherever they are), deploy the app to a host like Vercel and point it at a hosted Postgres database (e.g. [Neon](https://neon.tech) or [Supabase](https://supabase.com) both have generous free tiers):

1. Create a Postgres database with your provider of choice and copy its connection string.
2. Install the Postgres driver: `npm install pg && npm install -D @types/pg`
3. In `src/lib/db/index.ts`, replace the better-sqlite3 setup with:
   ```ts
   import { drizzle } from "drizzle-orm/node-postgres";
   import { Pool } from "pg";
   import * as schema from "./schema";

   const pool = new Pool({ connectionString: process.env.DATABASE_URL });
   export const db = drizzle(pool, { schema });
   ```
4. Set `DATABASE_URL` to your Postgres connection string (as an environment variable on your host, e.g. Vercel's Project Settings → Environment Variables).
5. Run `npx drizzle-kit push` once against that `DATABASE_URL` to create the tables, then `npx tsx scripts/seed.ts` to load the benchmark data.
6. Deploy (`vercel deploy`, or your host's equivalent). Every device that opens the deployed URL now shares the same data.

The schema in `src/lib/db/schema.ts` needs no changes for this — Drizzle's SQLite and Postgres column types map directly for everything used here.

If you'd like, a follow-up session can wire this up for you end-to-end once you've created the Postgres database and can share its connection string.

## Project structure

```
src/
  app/
    api/            Route handlers (leads, assessments, scenarios, benchmarks, audit, reports, settings, dashboard)
    assessment/new/ The 12-screen assessment wizard
    leads/          CRM list + detail
    scenarios/      Scenario management + comparison
    benchmarks/     Benchmark admin
    reports/        Generated report history
    follow-ups/     Follow-up timeline across all leads
    proposals/      Proposal/quote tracking
    settings/       Consultant profile
  components/       Shared UI (AppShell nav, form primitives)
  lib/
    calculations.ts       Marketing forecast formulas + benchmark priority resolution
    website-audit.ts      Live, honest website checks
    db/schema.ts           Drizzle schema
    pdf/                   PDF report document + data builder
data/
  benchmarks/*.json  Source-of-truth benchmark data (spec section 32 — never hard-coded)
  app.db             SQLite database file (created by `npm run setup`, gitignored)
  reports/           Saved PDF snapshots (gitignored)
```

## Notes on scope

This is a working MVP, not the full production spec verbatim — a few deliberate simplifications, all easy to extend:

- **No authentication.** This is built as a single-consultant tool. Add NextAuth or similar before exposing it beyond your own machine/team.
- **Website audit** covers everything checkable from a single page fetch (HTTPS, meta tags, viewport, headings, alt text, robots.txt, sitemap.xml, content depth). Core Web Vitals / page speed and full-site broken-link crawling need a paid API (e.g. Google PageSpeed Insights) — wire your API key into `src/lib/website-audit.ts` when you're ready.
- **Sample ad concepts** are templated cards populated from the lead's own business details, not AI-generated images. Swap in an image-generation API in the wizard's Sample Ads step if you want actual creative.
- **Competitor advertising** is captured as consultant notes rather than scraped — the spec explicitly warns against inventing competitor ad data, and there's no reliable, compliant public API for this.
