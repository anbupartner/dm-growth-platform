# Restore point — dm-growth-platform-backup-20260906-1312.zip

Taken: 2026-09-06 ~13:12 UTC (Asia/Calcutta ~18:42, 2026-09-06)
Source: E:\My Project\Dm Project\dm-growth-platform (live machine, via Claude's device bridge — not a shell snapshot)

## What this snapshot captures

Full application state as of this moment, including:

- **Source code**: `src/` (all routes, components, lib — including every fix logged in the project's build-summary doc through today's "Setup error handling" round: the shared `src/lib/api-handler.ts` error wrapper on all 34 API route files, `src/app/error.tsx`/`src/app/global-error.tsx` error boundaries, and the client-page error/retry fixes on `leads`/`proposals`/`reports`), `public/`, `scripts/seed.ts`.
- **Root config**: `.env`, `.env.example`, `.gitignore`, `AGENTS.md`, `CLAUDE.md`, `drizzle.config.ts`, `eslint.config.mjs`, `HOW_TO_APPLY.md`, `next-env.d.ts`, `next.config.ts`, `package.json`, `package-lock.json`, `postcss.config.mjs`, `README.md`, `tsconfig.json`.
- **Live database**: `data/app.db` + its `-wal`/`-shm` files (SQLite, includes any pending WAL-only writes at snapshot time) — this is your real business data: leads, proposals, settings, billing.
- **Benchmark seed data**: all 9 `data/benchmarks/*.json` files (Google, Meta, LinkedIn, YouTube, Instagram, Microsoft Ads, WhatsApp, Industry Benchmarks — 34 industries, plus benchmark metadata).
- **Generated PDFs on disk**: 9 report PDFs (`data/reports/*.pdf`) and 8 proposal PDFs (`data/proposals/*.pdf`).

**Not included** (deliberately, matching every prior backup in this project): `node_modules/` and `.next/` (regenerate with `npm install` and `npm run dev`/`npm run build`), the `backups/` folder itself (avoids nesting old zips inside new ones), and the `Claude outputs/` folder (delivery-only working files from prior sessions, not live app state — its content already exists inside `src/`).

## How to restore

### Full restore (replace everything)
1. Stop the dev server if it's running.
2. Unzip this archive somewhere temporary.
3. Copy every extracted file/folder over the corresponding path in your project root (`E:\My Project\Dm Project\dm-growth-platform`), overwriting what's there. This restores source, config, the database, benchmark data and generated PDFs to exactly this snapshot.
4. Run `npm install` (in case dependencies changed since this snapshot) and `npm run dev` (or `-- -p <port>` if you use a specific port).
5. On first request, the app's self-heal (`src/lib/db/index.ts`) will re-check schema/columns/tables/benchmark rows against the restored `app.db` — this is safe and a no-op if nothing's missing.

### Database-only restore (keep current code, roll back data)
1. Stop the dev server.
2. Replace `data/app.db`, `data/app.db-wal` and `data/app.db-shm` with the three files from this archive's `data/` folder.
3. Restart the dev server.

### Single-file restore
Extract just the one file you need from the archive (it mirrors the project's folder structure exactly — e.g. `src/lib/calculations.ts`) and copy it over the live file at the same relative path.

## Known state at this snapshot

- **"Setup error handling" (2026-09-06)**: every API route (34 files, 54 handlers) now wraps its logic in try/catch via a shared `src/lib/api-handler.ts` helper — every server-side error is logged (`console.error`, with the route in the message) and returns clean `{error}` JSON instead of a raw crash. `POST /api/reports` and `POST /api/proposals` now write their PDF to disk before inserting the database row, so a failed write can no longer leave a broken "editable" row with no matching PDF. The `leads`, `proposals`, and `reports` list pages now show a visible error with a "Try again" button instead of hanging on a spinner forever if their initial data load fails. New `src/app/error.tsx` (catches page-render crashes, keeps the sidebar usable) and `src/app/global-error.tsx` (last-resort fallback if the app shell itself breaks) are both present for the first time.
- **Deliverables (2026-09-06)**: moved off each pricing package and onto the proposal as one shared section — the generated PDF shows exactly one Monthly Deliverables table and one One-Time Deliverables table for the whole document, instead of one per package. Discount schedule is now also one shared section (gated by a "Discount available" checkbox), not per-package. The KPI & Measurement Framework is a simple editable list of platforms and the metrics tracked per platform (no projected numbers). Sections 1-6 of the proposal outline are fully numbered in both the builder sidebar and the PDF, matching the client's confirmed structure.
- **"Quick Proposal" flow (2026-09-06)**: a "+ Quick Proposal" button on the Proposals page lets a brand-new customer with no website/audit go straight from "doesn't exist as a lead yet" to "has a priced proposal" — packages can be added/removed manually in the builder rather than only ever being copied from audit scenarios.
- **Default currency for a brand-new install is INR**, though this real database's own settings row (already existing before that change) still stores whatever currency was last set in Settings — check there if you're unsure what's live right now.
- **"Always show every section" (2026-09-05)**: every optional proposal section is pre-filled with generic, freely-editable default text instead of silently disappearing when blank.
- Proposal-flow restructure (2026-09-05): Executive Summary, Challenges & Opportunities, and the 90-Day Growth Roadmap are editable in the proposal builder.
- Scenario tiers vary both CPC (±10%) and conversion rates across Conservative/Expected/Growth Opportunity (2026-09-03 fix).
- Self-heal is throttle-based (5s, request-triggered) — picks up code, schema, *and* pure-data-file changes automatically, no restart needed (2026-09-03 fix).
- 34 business verticals, full 8-channel benchmark coverage (including YouTube Ads), suggested-minimum-budget hints.
- Report/Proposal versioning, delete-with-confirmation for reports/proposals/leads, brand logo on PDFs, and the lead-billing feature (payments API + UI, including invoice/receipt generation) are all present in this snapshot's `src/`.
