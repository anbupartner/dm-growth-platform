// Database client.
//
// Local dev / single machine: Node's built-in `node:sqlite` (stable as of
// Node 22.5+, no native compilation and no external package required —
// this deliberately avoids better-sqlite3, whose native build can fail on
// machines without build tools or with restricted network access to
// download prebuilt binaries).
//
// Production / cross-device sync: swap this for a hosted Postgres driver so
// every device talking to the same deployed app shares the same data. Steps:
//   1. npm install drizzle-orm pg (or @neondatabase/serverless for Neon)
//   2. Replace the block below with:
//        import { drizzle } from "drizzle-orm/node-postgres";
//        import { Pool } from "pg";
//        const pool = new Pool({ connectionString: process.env.DATABASE_URL });
//        export const db = drizzle(pool, { schema });
//   3. Run `npx drizzle-kit push` against the Postgres DATABASE_URL.
// See README.md → "Going to production: cross-device sync" for the full walkthrough.

import { DatabaseSync, type StatementSync } from "node:sqlite";
import { drizzle } from "drizzle-orm/sqlite-proxy";
import { getTableColumns, getTableName } from "drizzle-orm";
import fs from "node:fs";
import path from "node:path";
import * as schema from "./schema";

const dbPath = process.env.DATABASE_URL ?? "./data/app.db";
const resolved = path.isAbsolute(dbPath)
  ? dbPath
  : path.join(process.cwd(), /* turbopackIgnore: true */ dbPath);
fs.mkdirSync(path.dirname(resolved), { recursive: true });

const globalForDb = globalThis as unknown as { __sqlite?: DatabaseSync; __schemaEnsured?: boolean };
const sqlite = globalForDb.__sqlite ?? new DatabaseSync(resolved);
sqlite.exec("PRAGMA journal_mode = WAL");
sqlite.exec("PRAGMA foreign_keys = ON");
if (process.env.NODE_ENV !== "production") globalForDb.__sqlite = sqlite;

// --- Lightweight auto-migration ---------------------------------------------
// This project syncs schema.ts to the SQLite file with `drizzle-kit push`
// (no migration files) — see package.json's `db:push`. That's a command the
// consultant has to remember to re-run by hand after every schema change,
// but the app itself is updated by copying source files over, not by running
// commands. If a shipped change adds a column (e.g. `target_country`) before
// `db:push` is re-run, every insert/update touching that column then fails
// with a raw "no such column" error — which surfaces to the consultant as an
// unexplained "Internal Server Error" on Save & Generate.
//
// To make that whole class of failure impossible, every startup reconciles
// each table in schema.ts against the actual columns in the SQLite file and
// ALTER TABLE ADD COLUMN's anything missing. This only ever adds columns to
// tables that already exist — it never creates tables (initial setup is
// still `npm run setup` / db:push) and never drops, renames, or changes an
// existing column — so it's safe to run unconditionally on every boot.
function quoteIdent(name: string): string {
  return `"${name.replace(/"/g, '""')}"`;
}

function formatSqlLiteral(value: unknown, sqlType: string): string {
  if (value === null) return "NULL";
  if (typeof value === "boolean") return value ? "1" : "0"; // sqlite has no bool type; drizzle stores as 0/1
  if (typeof value === "number") return String(value);
  if (sqlType === "integer" && value instanceof Date) return String(value.getTime());
  return `'${String(value).replace(/'/g, "''")}'`;
}

function ensureSchemaColumns(db: DatabaseSync) {
  for (const value of Object.values(schema)) {
    let tableName: string;
    let columns: Record<string, ReturnType<typeof getTableColumns>[string]>;
    try {
      tableName = getTableName(value as Parameters<typeof getTableName>[0]);
      columns = getTableColumns(value as Parameters<typeof getTableColumns>[0]);
    } catch {
      continue; // not a Drizzle table export (e.g. a type or helper)
    }

    const tableExists = db
      .prepare("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?")
      .get(tableName);
    if (!tableExists) continue; // brand-new install — `npm run setup` creates it

    const existingCols = new Set(
      (db.prepare(`PRAGMA table_info(${quoteIdent(tableName)})`).all() as Array<{ name: string }>).map(
        (r) => r.name
      )
    );

    for (const col of Object.values(columns)) {
      if (existingCols.has(col.name)) continue;
      const sqlType = col.getSQLType();
      let ddl = `ALTER TABLE ${quoteIdent(tableName)} ADD COLUMN ${quoteIdent(col.name)} ${sqlType}`;
      // Only literal defaults can be used in an ALTER ... ADD COLUMN; $defaultFn
      // callbacks (e.g. randomUUID/new Date for id/timestamps) can't be — those
      // columns are always present on table creation already, so this only
      // matters for the rare notNull column with a literal default.
      if (typeof col.default !== "function" && col.default !== undefined) {
        ddl += ` DEFAULT ${formatSqlLiteral(col.default, sqlType)}`;
        if (col.notNull) ddl += " NOT NULL";
      }
      try {
        db.exec(ddl);
        console.log(`[db] auto-migrated: added column "${tableName}"."${col.name}"`);
      } catch (err) {
        console.error(`[db] auto-migration failed for "${tableName}"."${col.name}":`, err);
      }
    }
  }
}

if (!globalForDb.__schemaEnsured) {
  ensureSchemaColumns(sqlite);
  globalForDb.__schemaEnsured = true;
}

const statementCache = new Map<string, StatementSync>();
function prepare(sql: string): StatementSync {
  let stmt = statementCache.get(sql);
  if (!stmt) {
    stmt = sqlite.prepare(sql);
    statementCache.set(sql, stmt);
  }
  return stmt;
}

// Bridges Drizzle's async sqlite-proxy contract onto node:sqlite's
// synchronous API. "all"/"get"/"values" all return rows as plain arrays
// (setReturnArrays) since that's what Drizzle's row mapper expects; "run" is
// used for statements where the caller doesn't need rows back.
export const db = drizzle(
  async (sqlText, params, method) => {
    const stmt = prepare(sqlText);
    if (method === "run") {
      stmt.run(...params);
      return { rows: [] };
    }
    stmt.setReturnArrays(true);
    if (method === "get") {
      const row = stmt.get(...params) as unknown as unknown[] | undefined;
      return { rows: (row ?? undefined) as unknown as unknown[] };
    }
    const rows = stmt.all(...params) as unknown as unknown[][];
    return { rows };
  },
  { schema }
);

export { sqlite };
