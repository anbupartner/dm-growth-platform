"use client";

import { Card, CardHeader, Field, Input, Textarea, Badge, Select } from "@/components/ui";
import type { ProposalPackage, ServicePackagesConfig } from "@/lib/pdf/proposal-types";
import { formatCurrencyDisplay } from "@/lib/calculations";
import { Star, Check } from "lucide-react";

// Generic defaults for the proposal-level Deliverables fields (Monthly/
// One-Time — shared once for the whole engagement, not per package) and a
// package's Discount Tiers field — same "always show every section"
// reasoning as the other default*Text() helpers in this file. The
// consultant can freely tailor this copy afterward.
export function defaultMonthlyDeliverablesText(): string {
  return [
    "Monthly Performance Report: campaign results, spend and key metrics.",
    "Ongoing Optimization: continuous management of live campaigns.",
  ].join("\n");
}
export function defaultOneTimeDeliverablesText(): string {
  return [
    "Onboarding & Account Setup: tracking, access and platform configuration.",
    "Initial Strategy Document: goals, audience and channel plan.",
  ].join("\n");
}
export function defaultDiscountTiersText(): string {
  return ["3 months: 5%", "6 months: 10%"].join("\n");
}

// Sorted, joined key used to test whether a package's checked services
// exactly match a configured tier's service list — order-independent set
// equality without pulling in a Set-comparison helper for one use.
function sortedKey(keys: string[]): string {
  return [...keys].sort().join("|");
}

function toggleKey(keys: string[], key: string): string[] {
  return keys.includes(key) ? keys.filter((k) => k !== key) : [...keys, key];
}

// The shared "priced packages + terms/validity" editing UI used by both the
// New Proposal flow (leads/[id]/proposal/new) and the Edit Proposal flow
// (leads/[id]/proposal/[proposalId]/edit) — kept as one component so the two
// flows can never drift apart on what "editable" means for a proposal
// (package name, price, description/scope, which one's recommended, terms
// text, and the valid-until date). The caller owns the actual `packages`
// array — this component only ever calls back with the same shape it was
// given, never invents or drops a field.

export function ProposalPackagesGrid({
  packages,
  onUpdate,
  onMarkRecommended,
  servicePackages,
}: {
  packages: ProposalPackage[];
  onUpdate: (index: number, patch: Partial<ProposalPackage>) => void;
  onMarkRecommended: (index: number) => void;
  // Optional — the consultant's Settings-configured "Recommended Services &
  // Scope" list (master services + named pricing tiers). When present, each
  // package card gets a services checklist plus a "Load a preset" picker;
  // when absent (or the consultant hasn't configured any services/tiers
  // yet), the checklist is simply not shown — nothing about the existing
  // package fields changes.
  servicePackages?: ServicePackagesConfig | null;
}) {
  // Applies a configured tier's name/price/description/services onto one
  // package in one step — the tier is just the current template in
  // Settings; the package keeps its own frozen copy from this point on, so
  // editing the tier later never changes an already-built package.
  function applyTier(i: number, tierKey: string) {
    const tier = servicePackages?.tiers.find((t) => t.key === tierKey);
    if (!tier) return;
    const labels = tier.serviceKeys
      .map((k) => servicePackages?.services.find((s) => s.key === k)?.label)
      .filter((l): l is string => !!l);
    onUpdate(i, {
      label: tier.name,
      price: tier.price,
      description: tier.descriptionOverride || (labels.length ? labels.join(" + ") : undefined),
      selectedServiceKeys: tier.serviceKeys,
      selectedServiceLabels: labels,
    });
  }

  function toggleService(i: number, pkg: ProposalPackage, key: string) {
    const nextKeys = toggleKey(pkg.selectedServiceKeys ?? [], key);
    const labels = nextKeys
      .map((k) => servicePackages?.services.find((s) => s.key === k)?.label)
      .filter((l): l is string => !!l);
    onUpdate(i, { selectedServiceKeys: nextKeys, selectedServiceLabels: labels });
  }

  return (
    <div className="grid md:grid-cols-3 gap-4 mb-4">
      {packages.map((pkg, i) => {
        // A live suggestion: if the services currently checked exactly match
        // one configured tier's own service list, offer to apply that
        // tier's name/price in one click — but only once something is
        // actually checked, so a brand-new package doesn't show a
        // suggestion before the consultant has touched the checklist.
        const matchedTier =
          servicePackages && (pkg.selectedServiceKeys?.length ?? 0) > 0
            ? servicePackages.tiers.find((t) => t.serviceKeys.length > 0 && sortedKey(t.serviceKeys) === sortedKey(pkg.selectedServiceKeys ?? []))
            : undefined;
        return (
          <Card key={pkg.key} className={pkg.recommended ? "p-4 border-indigo-400 border-2" : "p-4"}>
            <div className="flex items-center justify-between mb-3">
              {pkg.recommended ? (
                <Badge className="bg-indigo-600 text-white">Recommended</Badge>
              ) : (
                <button
                  type="button"
                  onClick={() => onMarkRecommended(i)}
                  className="text-xs text-slate-400 hover:text-indigo-600 flex items-center gap-1"
                >
                  <Star size={12} /> Mark recommended
                </button>
              )}
            </div>
            <Field label="Package name">
              <Input value={pkg.label} onChange={(e) => onUpdate(i, { label: e.target.value })} />
            </Field>
            <div className="mt-3">
              <Field label={`Monthly price (${pkg.currency})`}>
                <Input type="number" min={0} value={pkg.price || ""} onChange={(e) => onUpdate(i, { price: Number(e.target.value) || 0 })} />
              </Field>
            </div>
            <div className="mt-3">
              <Field label="Description" hint="What's included at this tier — add or edit points, adjust scope, freely.">
                <Textarea rows={3} value={pkg.description ?? ""} onChange={(e) => onUpdate(i, { description: e.target.value })} />
              </Field>
            </div>

            {servicePackages && servicePackages.services.length > 0 ? (
              <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                <div className="flex items-center justify-between mb-2 gap-2">
                  <p className="text-xs font-medium text-slate-600 dark:text-slate-300">Services Included</p>
                  {servicePackages.tiers.length > 0 && (
                    <Select value="" onChange={(e) => e.target.value && applyTier(i, e.target.value)} className="w-auto text-xs py-1">
                      <option value="">Load a preset…</option>
                      {servicePackages.tiers.map((t) => (
                        <option key={t.key} value={t.key}>
                          {t.name} — {formatCurrencyDisplay(t.price, pkg.currency)}
                        </option>
                      ))}
                    </Select>
                  )}
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {servicePackages.services.map((svc) => {
                    const checked = (pkg.selectedServiceKeys ?? []).includes(svc.key);
                    return (
                      <button
                        key={svc.key}
                        type="button"
                        onClick={() => toggleService(i, pkg, svc.key)}
                        className={
                          checked
                            ? "text-[11px] px-2 py-1 rounded-full bg-indigo-600 text-white flex items-center gap-1"
                            : "text-[11px] px-2 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center gap-1"
                        }
                      >
                        {checked && <Check size={10} />}
                        {svc.label}
                      </button>
                    );
                  })}
                </div>
                {matchedTier && (
                  <p className="text-xs text-emerald-600 mt-2">
                    Matches your &quot;{matchedTier.name}&quot; package ({formatCurrencyDisplay(matchedTier.price, pkg.currency)}/month).{" "}
                    <button type="button" className="underline" onClick={() => applyTier(i, matchedTier.key)}>
                      Use this price &amp; name
                    </button>
                  </p>
                )}
              </div>
            ) : null}

            {/* NOTE: Deliverables (Monthly/One-Time) intentionally has no
                fields on this card. It used to (below Services Included),
                but that meant the exact same scope-of-work text got typed
                once per package — confirmed from real proposal screenshots
                showing identical Monthly/One-Time Deliverables text repeated
                across all 3 pricing tiers. Deliverables is now one shared
                field for the whole proposal — see ProposalDeliverablesCard
                below — since every tier covers the same scope of work; only
                price and included services vary by package. */}
            <div className="mt-3">
              <Field
                label="Upfront-Commitment Discount Tiers"
                hint={`One per line as "N months: X%" — e.g. "3 months: 5%". The discounted monthly amount is calculated automatically. Pre-filled with a generic starting point — edit or clear to omit.`}
              >
                <Textarea rows={2} value={pkg.discountTiersText ?? ""} onChange={(e) => onUpdate(i, { discountTiersText: e.target.value })} />
              </Field>
            </div>
            <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800">
              <p className="text-xs font-medium text-slate-600 dark:text-slate-300 mb-2">
                KPI &amp; Measurement Framework (optional)
              </p>
              <p className="text-[11px] text-slate-400 mb-2">
                Seeded from the report scenario this package was built from — freely editable. Leave any field blank to omit that stat.
              </p>
              <div className="grid grid-cols-2 gap-2">
                <Field label="Traffic/mo">
                  <Input
                    type="number"
                    min={0}
                    value={pkg.trafficPerMonth ?? ""}
                    onChange={(e) => onUpdate(i, { trafficPerMonth: e.target.value === "" ? null : Number(e.target.value) })}
                  />
                </Field>
                <Field label="Leads/mo">
                  <Input
                    type="number"
                    min={0}
                    value={pkg.leadsPerMonth ?? ""}
                    onChange={(e) => onUpdate(i, { leadsPerMonth: e.target.value === "" ? null : Number(e.target.value) })}
                  />
                </Field>
                <Field label={`CPL (${pkg.currency})`}>
                  <Input
                    type="number"
                    min={0}
                    value={pkg.cpl ?? ""}
                    onChange={(e) => onUpdate(i, { cpl: e.target.value === "" ? null : Number(e.target.value) })}
                  />
                </Field>
                <Field label={`CAC (${pkg.currency})`}>
                  <Input
                    type="number"
                    min={0}
                    value={pkg.cac ?? ""}
                    onChange={(e) => onUpdate(i, { cac: e.target.value === "" ? null : Number(e.target.value) })}
                  />
                </Field>
                <Field label="ROAS (x)">
                  <Input
                    type="number"
                    min={0}
                    step="0.1"
                    value={pkg.roas ?? ""}
                    onChange={(e) => onUpdate(i, { roas: e.target.value === "" ? null : Number(e.target.value) })}
                  />
                </Field>
              </div>
            </div>
            {(pkg.customers != null || pkg.revenue != null || pkg.roi != null) && (
              <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 grid grid-cols-3 gap-2 text-xs">
                {pkg.customers != null && (
                  <div>
                    <div className="text-slate-400">Customers/mo</div>
                    <div className="font-semibold text-slate-700 dark:text-slate-200">{Math.round(pkg.customers)}</div>
                  </div>
                )}
                {pkg.revenue != null && (
                  <div>
                    <div className="text-slate-400">Revenue/mo</div>
                    <div className="font-semibold text-slate-700 dark:text-slate-200">{formatCurrencyDisplay(Math.round(pkg.revenue), pkg.currency)}</div>
                  </div>
                )}
                {pkg.roi != null && (
                  <div>
                    <div className="text-slate-400">ROI</div>
                    <div className="font-semibold text-slate-700 dark:text-slate-200">{Math.round(pkg.roi)}%</div>
                  </div>
                )}
              </div>
            )}
          </Card>
        );
      })}
    </div>
  );
}

// Optional per-proposal override of "prepared by" identity — consultant
// name, company, phone, WhatsApp, email, website. These normally come from
// the report version this proposal was quoted from (frozen at the time
// that report was generated from Settings), which means a later Settings
// correction never reaches an already-generated proposal, and there was
// previously no way to send one specific proposal from a different name/
// contact. A field left blank here falls back to that report's own value —
// shown as the input's placeholder so it's clear what will actually appear
// on the PDF if nothing is typed.
export interface ConsultantOverrideValue {
  consultantName?: string;
  companyName?: string;
  phone?: string;
  whatsapp?: string;
  email?: string;
  website?: string;
}

export function ProposalConsultantCard({
  override,
  defaults,
  onChange,
}: {
  override: ConsultantOverrideValue;
  defaults?: {
    consultantName?: string;
    companyName?: string;
    phone?: string | null;
    whatsapp?: string | null;
    email?: string | null;
    website?: string | null;
  };
  onChange: (patch: Partial<ConsultantOverrideValue>) => void;
}) {
  return (
    <Card className="p-5 mb-4">
      <CardHeader
        title="Prepared By (this proposal)"
        subtitle="Overrides the name/company/contact shown on this proposal's cover page, header, footer and closing section. Leave any field blank to use your Settings default for it."
      />
      <div className="pt-4 grid sm:grid-cols-2 gap-4">
        <Field label="Consultant Name">
          <Input
            value={override.consultantName ?? ""}
            placeholder={defaults?.consultantName || "Your Name"}
            onChange={(e) => onChange({ consultantName: e.target.value })}
          />
        </Field>
        <Field label="Company / Brand">
          <Input
            value={override.companyName ?? ""}
            placeholder={defaults?.companyName || "Your Consultancy"}
            onChange={(e) => onChange({ companyName: e.target.value })}
          />
        </Field>
        <Field label="Phone">
          <Input value={override.phone ?? ""} placeholder={defaults?.phone ?? ""} onChange={(e) => onChange({ phone: e.target.value })} />
        </Field>
        <Field label="WhatsApp">
          <Input
            value={override.whatsapp ?? ""}
            placeholder={defaults?.whatsapp ?? ""}
            onChange={(e) => onChange({ whatsapp: e.target.value })}
          />
        </Field>
        <Field label="Email">
          <Input
            type="email"
            value={override.email ?? ""}
            placeholder={defaults?.email ?? ""}
            onChange={(e) => onChange({ email: e.target.value })}
          />
        </Field>
        <Field label="Website">
          <Input value={override.website ?? ""} placeholder={defaults?.website ?? ""} onChange={(e) => onChange({ website: e.target.value })} />
        </Field>
      </div>
    </Card>
  );
}

// Whole-engagement policy sections shown once on the proposal (not per
// package) — modeled on a real reference SOW the consultant shared
// (Revision Policy / Client Responsibilities / Not Included / a short
// Communication line). Each is optional free text, one bullet per line;
// left blank, that section simply doesn't appear on the PDF — nothing is
// pre-filled or invented here.
export interface ProposalPolicyValue {
  revisionPolicyText: string;
  clientResponsibilitiesText: string;
  notIncludedText: string;
  pointOfContactText: string;
}

// Generic, non-client-specific boilerplate for the 3 whole-engagement policy
// sections — same reasoning as defaultNextStepsText() below: these describe
// a universal policy stance, not this client's data, so they're shown
// pre-filled rather than blank (a real proposal was otherwise shipping with
// these 3 sections silently missing whenever the consultant hadn't typed
// anything into them — see the "always show every section" decision this
// fixes). The consultant can edit or clear any of them freely; clearing one
// omits that section, exactly as before.
export function defaultRevisionPolicyText(): string {
  return ["Up to 2 rounds of revisions per deliverable are included.", "Additional revision rounds are billed at the standard hourly rate."].join("\n");
}
export function defaultClientResponsibilitiesText(): string {
  return [
    "Timely feedback and approvals on deliverables.",
    "Access to required accounts/assets (website, analytics, ad accounts, social pages).",
    "A single point of contact for coordination.",
  ].join("\n");
}
export function defaultNotIncludedText(): string {
  return [
    "Website design/development beyond what's listed above.",
    "Content or copywriting beyond what's listed above.",
    "Paid ad spend (billed separately, directly to the ad platform).",
  ].join("\n");
}

export function ProposalPolicyCard({
  value,
  onChange,
}: {
  value: ProposalPolicyValue;
  onChange: (patch: Partial<ProposalPolicyValue>) => void;
}) {
  return (
    <Card className="p-5 mb-4">
      <CardHeader
        title="Additional Terms"
        subtitle="Whole-engagement sections shown once on the proposal, not per package. Pre-filled with common defaults — edit freely, or clear a field to omit it from the PDF."
      />
      <div className="pt-4 space-y-4">
        <Field label="Revision Policy" hint="One bullet per line.">
          <Textarea
            rows={3}
            value={value.revisionPolicyText}
            onChange={(e) => onChange({ revisionPolicyText: e.target.value })}
            placeholder={"Blog/SEO optimization: 1 revision cycle where required\nWebpage creation: 2 revision rounds per page"}
          />
        </Field>
        <Field label="Client Responsibilities" hint="One bullet per line — what the client needs to provide.">
          <Textarea
            rows={3}
            value={value.clientResponsibilitiesText}
            onChange={(e) => onChange({ clientResponsibilitiesText: e.target.value })}
            placeholder={"Final content and images\nWebsite/CMS access where required\nBrand guidelines and logo assets"}
          />
        </Field>
        <Field label="Not Included" hint="One bullet per line — explicitly out of scope.">
          <Textarea
            rows={3}
            value={value.notIncludedText}
            onChange={(e) => onChange({ notIncludedText: e.target.value })}
            placeholder={"Paid advertising budget\nWebsite development beyond existing templates"}
          />
        </Field>
        <Field label="Communication" hint="A short line on how you'll stay in touch.">
          <Input
            value={value.pointOfContactText}
            onChange={(e) => onChange({ pointOfContactText: e.target.value })}
            placeholder="Communication through email / WhatsApp / online meetings as required."
          />
        </Field>
      </div>
    </Card>
  );
}

// "Requirements" and "Digital Growth Strategy" (Attract → Engage → Convert
// → Retain) — Stage 1 of the full proposal-flow restructure. All optional
// free text, one bullet per line; a stage or the Requirements field left
// blank simply doesn't appear on the PDF. No existing report data covers
// these, so — unlike Executive Summary/Challenges/the 90-Day Roadmap, which
// reuse the report's own data automatically — this is genuinely new content
// only the consultant can provide.
export interface ProposalStrategyValue {
  requirementsText: string;
  strategyAttractText: string;
  strategyEngageText: string;
  strategyConvertText: string;
  strategyRetainText: string;
}

// Generic starting-point text for Requirements and the 4 Digital Growth
// Strategy stages — same reasoning as defaultNextStepsText() below: this is
// a real proposal was otherwise silently dropping the entire Requirements
// page (misleadingly titled "Requirements & Understanding" with no
// Requirements in it — see the fix for that) and the whole Digital Growth
// Strategy page whenever the consultant hadn't typed anything in yet. Shown
// pre-filled so both always render by default; freely editable, and
// clearing a field back to blank omits that piece exactly as before.
export function defaultRequirementsText(): string {
  return [
    "A mobile-friendly website with clear calls to action.",
    "Consistent lead flow from Google Search and paid channels.",
    "Brand presence and consistent posting across key social platforms.",
  ].join("\n");
}
export function defaultStrategyAttractText(): string {
  return ["SEO content targeting high-intent search terms.", "Paid search and social ads for immediate visibility."].join("\n");
}
export function defaultStrategyEngageText(): string {
  return ["Social media content calendar.", "Email/SMS nurture sequence for new leads."].join("\n");
}
export function defaultStrategyConvertText(): string {
  return ["Landing page and offer optimization.", "Clear calls to action across the funnel."].join("\n");
}
export function defaultStrategyRetainText(): string {
  return ["Post-purchase email and remarketing flows.", "Loyalty, reviews and referral offers."].join("\n");
}

export function ProposalStrategyCard({
  value,
  onChange,
}: {
  value: ProposalStrategyValue;
  onChange: (patch: Partial<ProposalStrategyValue>) => void;
}) {
  return (
    <Card className="p-5 mb-4">
      <CardHeader
        title="Requirements & Strategy"
        subtitle="Confirms what the client needs and how you'll grow them — shown once on the proposal. Pre-filled with a generic starting point — edit freely, or clear a field to omit it from the PDF."
      />
      <div className="pt-4 space-y-4">
        <Field label="Requirements" hint="One bullet per line — clearly confirm what the client needs.">
          <Textarea
            rows={3}
            value={value.requirementsText}
            onChange={(e) => onChange({ requirementsText: e.target.value })}
            placeholder={"A mobile-friendly website with clear calls to action\nConsistent lead flow from Google Search\nBrand presence across Instagram and Facebook"}
          />
        </Field>
        <div>
          <p className="text-sm font-medium text-slate-700 dark:text-slate-200 mb-2">Digital Growth Strategy</p>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Attract" hint="One bullet per line.">
              <Textarea
                rows={2}
                value={value.strategyAttractText}
                onChange={(e) => onChange({ strategyAttractText: e.target.value })}
                placeholder={"SEO content targeting high-intent search terms\nGoogle Ads for immediate visibility"}
              />
            </Field>
            <Field label="Engage" hint="One bullet per line.">
              <Textarea
                rows={2}
                value={value.strategyEngageText}
                onChange={(e) => onChange({ strategyEngageText: e.target.value })}
                placeholder={"Social media content calendar\nEmail nurture sequence"}
              />
            </Field>
            <Field label="Convert" hint="One bullet per line.">
              <Textarea
                rows={2}
                value={value.strategyConvertText}
                onChange={(e) => onChange({ strategyConvertText: e.target.value })}
                placeholder={"Landing page optimization\nClear calls to action and offers"}
              />
            </Field>
            <Field label="Retain" hint="One bullet per line.">
              <Textarea
                rows={2}
                value={value.strategyRetainText}
                onChange={(e) => onChange({ strategyRetainText: e.target.value })}
                placeholder={"Post-purchase email flows\nLoyalty and referral offers"}
              />
            </Field>
          </div>
        </div>
      </div>
    </Card>
  );
}

// Executive Summary ("What We Understand" / "The Opportunity" / "What We
// Recommend" / "Our Approach") — used to be computed live from the report
// snapshot every time; now its own editable, proposal-level field. The
// caller seeds these from the report's own data the moment a report version
// is selected (see leads/[id]/proposal/new/page.tsx), so the consultant
// opens the builder to real, pre-filled text — never a blank page — but can
// freely rewrite any part of it before generating.
// NOTE: this card intentionally has no "Key Problems" field. It used to
// (seeded from the same website-audit findings as Challenges &
// Opportunities' "What We Found"), which meant the exact same bullet list
// rendered twice on two different pages of a real generated proposal —
// confirmed from a real client PDF where "Meta Description: No meta
// description found." etc. appeared under both "What We Understand" and
// "What We Found". Removed here rather than from Challenges & Opportunities
// since the audit findings belong more naturally under Challenges.
export interface ProposalSummaryValue {
  currentSituationText: string;
  opportunityText: string;
  recommendedDirectionText: string;
  approachText: string;
}

export function ProposalSummaryCard({
  value,
  onChange,
}: {
  value: ProposalSummaryValue;
  onChange: (patch: Partial<ProposalSummaryValue>) => void;
}) {
  return (
    <Card className="p-5 mb-4">
      <CardHeader
        title="Executive Summary"
        subtitle="Seeded from the report — edit any part of it freely. Clearing a block omits it from the PDF."
      />
      <div className="pt-4 space-y-4">
        <Field label="What We Understand">
          <Textarea rows={3} value={value.currentSituationText} onChange={(e) => onChange({ currentSituationText: e.target.value })} />
        </Field>
        <Field label="The Opportunity">
          <Textarea rows={3} value={value.opportunityText} onChange={(e) => onChange({ opportunityText: e.target.value })} />
        </Field>
        <Field label="What We Recommend">
          <Textarea rows={3} value={value.recommendedDirectionText} onChange={(e) => onChange({ recommendedDirectionText: e.target.value })} />
        </Field>
        <Field label="Our Approach">
          <Textarea rows={3} value={value.approachText} onChange={(e) => onChange({ approachText: e.target.value })} />
        </Field>
      </div>
    </Card>
  );
}

// "Challenges & Opportunities" — same seeded-then-editable pattern as
// Executive Summary above. Optional: left blank, that half (or the whole
// section) is omitted from the PDF.
export interface ProposalChallengesValue {
  topProblemsText: string;
  competitorInsightsText: string;
}

export function ProposalChallengesCard({
  value,
  onChange,
}: {
  value: ProposalChallengesValue;
  onChange: (patch: Partial<ProposalChallengesValue>) => void;
}) {
  return (
    <Card className="p-5 mb-4">
      <CardHeader
        title="Challenges & Opportunities (optional)"
        subtitle="Seeded from the report's website audit and competitor findings — edit freely. Leave blank to omit."
      />
      <div className="pt-4 space-y-4">
        <Field label="What We Found" hint="One bullet per line.">
          <Textarea rows={3} value={value.topProblemsText} onChange={(e) => onChange({ topProblemsText: e.target.value })} />
        </Field>
        <Field label="Competitive Landscape" hint="One bullet per line.">
          <Textarea rows={3} value={value.competitorInsightsText} onChange={(e) => onChange({ competitorInsightsText: e.target.value })} />
        </Field>
      </div>
    </Card>
  );
}

// 90-Day Growth Roadmap — a dynamic list of phases (title + bullet items
// each), seeded from the report's own growthPlan when a report version is
// selected, then fully editable: rewrite any phase, add a new one, or
// remove one entirely. Real phase names/items only when seeded; a phase
// added by the consultant is exactly what they type, never invented.
export interface ProposalRoadmapPhase {
  title: string;
  itemsText: string;
}

export function ProposalRoadmapCard({
  phases,
  onChange,
}: {
  phases: ProposalRoadmapPhase[];
  onChange: (phases: ProposalRoadmapPhase[]) => void;
}) {
  function updatePhase(i: number, patch: Partial<ProposalRoadmapPhase>) {
    onChange(phases.map((p, j) => (j === i ? { ...p, ...patch } : p)));
  }
  function removePhase(i: number) {
    onChange(phases.filter((_, j) => j !== i));
  }
  function addPhase() {
    onChange([...phases, { title: "", itemsText: "" }]);
  }

  return (
    <Card className="p-5 mb-4">
      <CardHeader
        title="90-Day Growth Roadmap"
        subtitle="Seeded from the report's growth plan — edit any phase, add one, or remove one. A phase left with no title is omitted."
      />
      <div className="pt-4 space-y-4">
        {phases.map((phase, i) => (
          <div key={i} className="border border-slate-200 dark:border-slate-800 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Phase {i + 1}</p>
              <button
                type="button"
                onClick={() => removePhase(i)}
                className="text-xs text-slate-400 hover:text-red-600"
              >
                Remove phase
              </button>
            </div>
            <Field label="Phase Title" hint='e.g. "0–30 Days – Foundation"'>
              <Input value={phase.title} onChange={(e) => updatePhase(i, { title: e.target.value })} />
            </Field>
            <div className="mt-3">
              <Field label="Items" hint="One bullet per line.">
                <Textarea rows={3} value={phase.itemsText} onChange={(e) => updatePhase(i, { itemsText: e.target.value })} />
              </Field>
            </div>
          </div>
        ))}
        <button
          type="button"
          onClick={addPhase}
          className="text-xs font-medium text-indigo-600 hover:text-indigo-700"
        >
          + Add phase
        </button>
      </div>
    </Card>
  );
}

// "Tools & Resource Plan" (platforms/tools/team required — sits under
// "Scope of the project") plus an optional "KPI & Measurement Framework"
// notes field (free-text commentary alongside the per-package stat cards
// entered above in ProposalPackagesGrid). Both optional free text, one
// bullet per line; left blank, that section/page simply doesn't appear on
// the PDF. No existing report data covers either, so — same as Requirements/
// Digital Growth Strategy above — these are new consultant-entered fields.
export interface ProposalScopeValue {
  toolsResourcePlanText: string;
  kpiFrameworkNotesText: string;
}

// Generic starting-point text — a real proposal was otherwise silently
// dropping the entire Tools & Resource Plan page whenever the consultant
// hadn't typed anything in yet (see the "always show every section" fix).
export function defaultToolsResourcePlanText(): string {
  return [
    "Google Analytics 4 & Search Console for tracking.",
    "Meta Business Suite for social content & ads.",
    "CRM for lead management.",
    "Dedicated account manager + content team.",
  ].join("\n");
}

export function ProposalScopeCard({
  value,
  onChange,
}: {
  value: ProposalScopeValue;
  onChange: (patch: Partial<ProposalScopeValue>) => void;
}) {
  return (
    <Card className="p-5 mb-4">
      <CardHeader
        title="Tools & Resource Plan"
        subtitle="Platforms, tools and team/resources required — shown once on the proposal. Pre-filled with a generic starting point — edit freely, or clear it to omit this section."
      />
      <div className="pt-4 space-y-4">
        <Field label="Tools & Resource Plan" hint="One bullet per line.">
          <Textarea
            rows={4}
            value={value.toolsResourcePlanText}
            onChange={(e) => onChange({ toolsResourcePlanText: e.target.value })}
          />
        </Field>
        <Field
          label="KPI & Measurement Framework — Notes (optional)"
          hint="One bullet per line — context alongside the per-package Traffic/Leads/CPL/CAC/ROAS numbers set above."
        >
          <Textarea
            rows={3}
            value={value.kpiFrameworkNotesText}
            onChange={(e) => onChange({ kpiFrameworkNotesText: e.target.value })}
            placeholder={"Reported monthly via a shared dashboard\nReviewed together in the monthly check-in call"}
          />
        </Field>
      </div>
    </Card>
  );
}

// Deliverables (outline section 3: 3.1 Monthly Deliverable / 3.2 One-Time
// Deliverable) — ONE shared field pair for the whole proposal, not one copy
// per pricing package. This used to live on each package card, which meant
// the exact same scope-of-work text got typed 3 times over (confirmed from a
// real proposal's screenshots showing identical Monthly/One-Time
// Deliverables text on every one of its 3 package cards) — every tier covers
// the same deliverables; only price and included services vary by package,
// and those already have their own place (the package card's price field and
// Services Included checklist). Pre-filled with a generic default (same
// pattern as Tools & Resource Plan/Next Steps) — edit freely, or clear a
// field to omit that half of the Deliverables page.
export interface ProposalDeliverablesValue {
  monthlyDeliverablesText: string;
  oneTimeDeliverablesText: string;
}

export function ProposalDeliverablesCard({
  value,
  onChange,
}: {
  value: ProposalDeliverablesValue;
  onChange: (patch: Partial<ProposalDeliverablesValue>) => void;
}) {
  return (
    <Card className="p-5 mb-4">
      <CardHeader
        title="Deliverables"
        subtitle="Shown once for the whole proposal — the same scope of work applies regardless of which package the client picks. Pre-filled with a generic starting point — edit freely, or clear a field to omit it."
      />
      <div className="pt-4 space-y-4">
        <Field
          label="Monthly Deliverable"
          hint={`One per line as "Item: details" — e.g. "Blog Publishing: 4 posts/month, on-page SEO, CMS upload." Rendered as a table on the Deliverables page.`}
        >
          <Textarea
            rows={3}
            value={value.monthlyDeliverablesText}
            onChange={(e) => onChange({ monthlyDeliverablesText: e.target.value })}
          />
        </Field>
        <Field
          label="One-Time Deliverable"
          hint={`One per line as "Item: details" — e.g. "Website Audit: technical + on-page review, findings report." Rendered as a table on the Deliverables page.`}
        >
          <Textarea
            rows={3}
            value={value.oneTimeDeliverablesText}
            onChange={(e) => onChange({ oneTimeDeliverablesText: e.target.value })}
          />
        </Field>
      </div>
    </Card>
  );
}

// "Next Steps" — the document's closing section (Approval -> Kickoff ->
// Onboarding -> Access -> Execution). Unlike every other optional field
// above, this one describes a universal process rather than client-specific
// data, so it's shown pre-filled with a generic default rather than blank —
// same pattern as defaultTermsText() in the New Proposal page. The
// consultant can edit or clear it freely; clearing it omits the section.
// NOTE: keep this arrow-free ("->" not "→") — a literal "→" falls outside
// react-pdf's Helvetica/WinAnsi font and renders as a garbled glyph on the
// PDF. This exact bug has already been fixed twice in this codebase
// (ReportDocument.tsx and this file's own Digital Growth Strategy subtitle)
// — don't reintroduce it a third time.
export function defaultNextStepsText(): string {
  return [
    "Proposal approval & sign-off",
    "Kickoff call to confirm goals, timelines and points of contact",
    "Onboarding: brand, business and existing-asset walkthrough",
    "Access setup: website, analytics, ad accounts and social pages",
    "Execution begins per the 90-Day Growth Roadmap",
  ].join("\n");
}

export function ProposalNextStepsCard({
  value,
  onChange,
}: {
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <Card className="p-5 mb-4">
      <CardHeader
        title="Next Steps"
        subtitle="Closing section of the proposal. Pre-filled with a generic process — edit freely, or clear it to omit this section."
      />
      <div className="pt-4">
        <Field label="Next Steps" hint="One bullet per line.">
          <Textarea rows={5} value={value} onChange={(e) => onChange(e.target.value)} />
        </Field>
      </div>
    </Card>
  );
}

export function ProposalTermsCard({
  validUntil,
  onValidUntilChange,
  termsText,
  onTermsTextChange,
}: {
  validUntil: string;
  onValidUntilChange: (value: string) => void;
  termsText: string;
  onTermsTextChange: (value: string) => void;
}) {
  return (
    <Card className="p-5 mb-4">
      <CardHeader title="Terms & Validity" />
      <div className="pt-4 space-y-4">
        <Field label="Valid until" hint="Leave blank for no expiry.">
          <Input type="date" value={validUntil} onChange={(e) => onValidUntilChange(e.target.value)} className="max-w-xs" />
        </Field>
        <Field label="Terms shown on the proposal">
          <Textarea rows={6} value={termsText} onChange={(e) => onTermsTextChange(e.target.value)} />
        </Field>
      </div>
    </Card>
  );
}
