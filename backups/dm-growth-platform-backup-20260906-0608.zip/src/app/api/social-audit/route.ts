import { NextRequest, NextResponse } from "next/server";
import { runSocialCheck } from "@/lib/social-audit";

export async function POST(req: NextRequest) {
  const body = await req.json();
  if (!body.url) return NextResponse.json({ error: "url is required" }, { status: 400 });
  const result = await runSocialCheck(body.url);
  return NextResponse.json(result);
}
