import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { leads, assessments, scenarios, consultantSettings, reportSnapshots, followUps } from "@/lib/db/schema";
import { eq, inArray, desc } from "drizzle-orm";
import { renderToBuffer } from "@react-pdf/renderer";
import { ReportDocument } from "@/lib/pdf/ReportDocument";
import { buildReportData } from "@/lib/pdf/build-report-data";
import { nextReportVersion } from "@/lib/versioning";
import fs from "node:fs";
import path from "node:path";

// PDFs are saved to disk so a re-download later returns the exact same
// bytes even if benchmarks or scenarios change afterwards (spec section 45:
// "If benchmarks are updated later, old reports must NOT change").
const REPORTS_DIR = path.join(process.cwd(), "data", "reports");

function parseJsonField<T>(value: string | null | undefined): T | null {
  if (!value) return null;
  try {
    return JSON.parse(value) as T;
  } catch {
    return null;
  }
}

export async function GET(req: NextRequest) {
  const leadId = req.nextUrl.searchParams.get("leadId");
  if (leadId) {
    const rows = await db.select().from(reportSnapshots).where(eq(reportSnapshots.leadId, leadId)).orderBy(desc(reportSnapshots.createdAt));
    return NextResponse.json(rows);
  }
  const rows = await db
    .select({
      id: reportSnapshots.id,
      leadId: reportSnapshots.leadId,
      pdfFileName: reportSnapshots.pdfFileName,
      createdAt: reportSnapshots.createdAt,
      businessName: leads.businessName,
      customerId: leads.customerId,
      customerName: leads.customerName,
      phone: leads.phone,
    })
    .from(reportSnapshots)
    .leftJoin(leads, eq(reportSnapshots.leadId, leads.id))
    .orderBy(desc(reportSnapshots.createdAt));
  return NextResponse.json(rows);
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { leadId, assessmentId, scenarioIds } = body as {
    leadId: string;
    assessmentId?: string;
    scenarioIds?: string[];
  };
  if (!leadId) return NextResponse.json({ error: "leadId is required" }, { status: 400 });

  const lead = await db.query.leads.findFirst({ where: eq(leads.id, leadId) });
  if (!lead) return NextResponse.json({ error: "Lead not found" }, { status: 404 });

  const settings =
    (await db.query.consultantSettings.findFirst({ where: eq(consultantSettings.id, "default") })) ?? {
      consultantName: "Your Name",
      companyName: "Your Consultancy",
      ctaText: "Let's discuss how we can build your digital growth strategy.",
      currency: "USD",
      phone: null,
      whatsapp: null,
      email: null,
      website: null,
      linkedin: null,
    };

  const assessment = assessmentId
    ? await db.query.assessments.findFirst({ where: eq(assessments.id, assessmentId) })
    : (await db.select().from(assessments).where(eq(assessments.leadId, leadId)))[0];

  const scenarioRows = scenarioIds?.length
    ? await db.select().from(scenarios).where(inArray(scenarios.id, scenarioIds))
    : await db.select().from(scenarios).where(eq(scenarios.leadId, leadId));

  const reportData = buildReportData({
    lead: { ...lead, hasWebsite: lead.hasWebsite as "YES" | "NO" | null },
    settings,
    assessment: assessment
      ? {
          executiveSummary: parseJsonField(assessment.executiveSummary),
          auditScores: parseJsonField(assessment.auditScores),
          websiteAudit: parseJsonField(assessment.websiteAudit),
          websiteRecommendation: parseJsonField(assessment.websiteRecommendation),
          competitorAnalysis: parseJsonField(assessment.competitorAnalysis),
          socialMedia: parseJsonField(assessment.socialMedia),
          audienceRecommendation: parseJsonField(assessment.audienceRecommendation),
          platformRecommendation: parseJsonField(assessment.platformRecommendation),
          sampleAds: parseJsonField(assessment.sampleAds),
          growthPlan: parseJsonField(assessment.growthPlan),
          problemSolution: parseJsonField(assessment.problemSolution),
        }
      : null,
    scenarioRows: scenarioRows.map((s) => ({ name: s.name, tier: s.tier, adBudget: s.adBudget, results: s.results })),
  });

  const buffer = await renderToBuffer(<ReportDocument data={reportData} />);

  const version = await nextReportVersion(leadId);
  const fileName = `${lead.customerId}-${lead.businessName.replace(/[^a-z0-9]+/gi, "-").toLowerCase()}-report-v${version}.pdf`;

  const [snapshot] = await db
    .insert(reportSnapshots)
    .values({
      leadId,
      scenarioResults: JSON.stringify(scenarioRows),
      benchmarksUsed: JSON.stringify({ note: "See scenario inputs — benchmark values used are captured at scenario save time." }),
      clientInputs: JSON.stringify(lead),
      assumptions: JSON.stringify(scenarioRows.map((s) => ({ name: s.name, tier: s.tier }))),
      version,
      reportData: JSON.stringify(reportData),
      pdfFileName: fileName,
    })
    .returning();

  fs.mkdirSync(REPORTS_DIR, { recursive: true });
  fs.writeFileSync(path.join(REPORTS_DIR, `${snapshot.id}.pdf`), buffer);

  await db.insert(followUps).values({
    leadId,
    type: "Report Sent",
    note: `PDF report generated (${fileName}).`,
    completed: true,
  });
  await db.update(leads).set({ status: lead.status === "NEW_LEAD" || lead.status === "CONTACTED" ? "AUDIT_SENT" : lead.status }).where(eq(leads.id, leadId));

  return new NextResponse(new Uint8Array(buffer), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${fileName}"`,
      "X-Report-Snapshot-Id": snapshot.id,
    },
  });
}
