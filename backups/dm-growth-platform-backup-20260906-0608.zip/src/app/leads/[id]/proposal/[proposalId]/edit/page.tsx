"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { api } from "@/lib/api-client";
import { PageHeading, Card, Button, LinkButton, Spinner } from "@/components/ui";
import {
  ProposalPackagesGrid,
  ProposalTermsCard,
  ProposalConsultantCard,
  type ConsultantOverrideValue,
  ProposalPolicyCard,
  type ProposalPolicyValue,
  defaultRevisionPolicyText,
  defaultClientResponsibilitiesText,
  defaultNotIncludedText,
  ProposalStrategyCard,
  type ProposalStrategyValue,
  defaultRequirementsText,
  defaultStrategyAttractText,
  defaultStrategyEngageText,
  defaultStrategyConvertText,
  defaultStrategyRetainText,
  ProposalScopeCard,
  type ProposalScopeValue,
  defaultToolsResourcePlanText,
  ProposalNextStepsCard,
  defaultNextStepsText,
  ProposalSummaryCard,
  type ProposalSummaryValue,
  ProposalChallengesCard,
  type ProposalChallengesValue,
  ProposalRoadmapCard,
  type ProposalRoadmapPhase,
  ProposalDeliverablesCard,
  type ProposalDeliverablesValue,
  defaultMonthlyDeliverablesText,
  defaultOneTimeDeliverablesText,
  defaultDiscountTiersText,
} from "@/components/ProposalBuilderFields";
import { DEFAULT_SERVICE_PACKAGES, type ProposalPackage, type ServicePackagesConfig } from "@/lib/pdf/proposal-types";
import type { ReportData } from "@/lib/pdf/types";
import { Download } from "lucide-react";

interface ProposalRow {
  id: string;
  leadId: string;
  reportSnapshotId: string | null;
  version: number;
  packages: string; // JSON
  termsText: string | null;
  validUntil: string | null;
  pdfFileName: string | null;
  consultantOverride: string | null; // JSON
  revisionPolicyText: string | null;
  clientResponsibilitiesText: string | null;
  notIncludedText: string | null;
  pointOfContactText: string | null;
  requirementsText: string | null;
  strategyAttractText: string | null;
  strategyEngageText: string | null;
  strategyConvertText: string | null;
  strategyRetainText: string | null;
  toolsResourcePlanText: string | null;
  kpiFrameworkNotesText: string | null;
  monthlyDeliverablesText: string | null;
  oneTimeDeliverablesText: string | null;
  nextStepsText: string | null;
  summaryCurrentSituationText: string | null;
  summaryOpportunityText: string | null;
  summaryRecommendedDirectionText: string | null;
  summaryApproachText: string | null;
  summaryProblemsText: string | null;
  challengesTopProblemsText: string | null;
  challengesCompetitorInsightsText: string | null;
  roadmapPhasesJson: string | null;
}

interface LeadDetail {
  lead: { id: string; businessName: string; customerName: string };
}

// Edit an already-generated proposal: pre-filled with exactly what was
// saved (package prices, descriptions/scope, terms, valid-until), so the
// consultant can add points, adjust cost, or change scope, then save.
// Mirrors leads/[id]/report/[reportId]/edit's philosophy exactly — saving
// never overwrites the version being edited from, it creates the next
// version instead, so a proposal already sent to a client keeps showing
// exactly what they were quoted, and every version stays downloadable from
// the Proposals list.
export default function EditProposalPage() {
  const params = useParams();
  const leadId = params.id as string;
  const proposalId = params.proposalId as string;

  const [leadDetail, setLeadDetail] = useState<LeadDetail | null>(null);
  const [source, setSource] = useState<ProposalRow | null>(null);
  // The next version number is the highest version across ALL of this
  // lead's proposals, plus one — not just source.version + 1. A lead can
  // have several proposal versions, and editing an older one (not
  // necessarily the latest) still produces the next number in that whole
  // sequence, same as nextProposalVersion() computes server-side — so this
  // is fetched rather than assumed, to avoid showing a version number here
  // that wouldn't match what actually gets saved.
  const [nextVersion, setNextVersion] = useState<number | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [packages, setPackages] = useState<ProposalPackage[]>([]);
  const [termsText, setTermsText] = useState("");
  const [validUntil, setValidUntil] = useState("");
  const [consultantOverride, setConsultantOverride] = useState<ConsultantOverrideValue>({});
  const [policy, setPolicy] = useState<ProposalPolicyValue>({
    revisionPolicyText: "",
    clientResponsibilitiesText: "",
    notIncludedText: "",
    pointOfContactText: "",
  });
  const [strategy, setStrategy] = useState<ProposalStrategyValue>({
    requirementsText: "",
    strategyAttractText: "",
    strategyEngageText: "",
    strategyConvertText: "",
    strategyRetainText: "",
  });
  const [scope, setScope] = useState<ProposalScopeValue>({
    toolsResourcePlanText: "",
    kpiFrameworkNotesText: "",
  });
  const [deliverables, setDeliverables] = useState<ProposalDeliverablesValue>({
    monthlyDeliverablesText: "",
    oneTimeDeliverablesText: "",
  });
  const [nextStepsText, setNextStepsText] = useState(defaultNextStepsText());
  const [summary, setSummary] = useState<ProposalSummaryValue>({
    currentSituationText: "",
    opportunityText: "",
    recommendedDirectionText: "",
    approachText: "",
  });
  const [challenges, setChallenges] = useState<ProposalChallengesValue>({
    topProblemsText: "",
    competitorInsightsText: "",
  });
  const [roadmapPhases, setRoadmapPhases] = useState<ProposalRoadmapPhase[]>([]);
  const [servicePackages, setServicePackages] = useState<ServicePackagesConfig>(DEFAULT_SERVICE_PACKAGES);
  // The report snapshot's own consultant block — shown only as placeholder
  // text in the override fields below, so the consultant can see what will
  // actually appear on the PDF for any field they leave blank.
  const [reportDefaults, setReportDefaults] = useState<ReportData["consultant"] | undefined>(undefined);

  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const [pdfFilename, setPdfFilename] = useState("");
  const [savedVersion, setSavedVersion] = useState<number | null>(null);

  useEffect(() => {
    api.get<LeadDetail>(`/api/leads/${leadId}`).then(setLeadDetail).catch((e) => setLoadError((e as Error).message));
  }, [leadId]);

  useEffect(() => {
    api
      .get<ProposalRow>(`/api/proposals/${proposalId}`)
      .then((row) => {
        setSource(row);
        // A saved package that predates the Discount Tiers field (or was
        // built before this fix) has it as undefined/null — fall back to
        // the same generic default New Proposal now seeds, same reasoning
        // as nextStepsText below, so re-saving an old proposal through Edit
        // also picks up the previously-missing section instead of carrying
        // the gap forward. (Monthly/One-Time Deliverables used to be
        // backfilled here too, per package — moved to the proposal-level
        // `deliverables` state below; see ProposalDeliverablesCard.)
        setPackages(
          (JSON.parse(row.packages) as ProposalPackage[]).map((p) => ({
            ...p,
            discountTiersText: p.discountTiersText ?? defaultDiscountTiersText(),
          }))
        );
        setTermsText(row.termsText ?? "");
        setValidUntil(row.validUntil ? new Date(row.validUntil).toISOString().slice(0, 10) : "");
        setConsultantOverride(row.consultantOverride ? (JSON.parse(row.consultantOverride) as ConsultantOverrideValue) : {});
        // Unlike a purely-optional field, these describe universal
        // policy/strategy content rather than this client's data, so a
        // never-saved value (null) falls back to the same generic default
        // shown on New Proposal — same reasoning as nextStepsText below —
        // rather than blank. A deliberately-cleared value (saved as "")
        // stays blank, which omits that section exactly as the consultant
        // left it.
        setPolicy({
          revisionPolicyText: row.revisionPolicyText ?? defaultRevisionPolicyText(),
          clientResponsibilitiesText: row.clientResponsibilitiesText ?? defaultClientResponsibilitiesText(),
          notIncludedText: row.notIncludedText ?? defaultNotIncludedText(),
          pointOfContactText: row.pointOfContactText ?? "",
        });
        setStrategy({
          requirementsText: row.requirementsText ?? defaultRequirementsText(),
          strategyAttractText: row.strategyAttractText ?? defaultStrategyAttractText(),
          strategyEngageText: row.strategyEngageText ?? defaultStrategyEngageText(),
          strategyConvertText: row.strategyConvertText ?? defaultStrategyConvertText(),
          strategyRetainText: row.strategyRetainText ?? defaultStrategyRetainText(),
        });
        setScope({
          toolsResourcePlanText: row.toolsResourcePlanText ?? defaultToolsResourcePlanText(),
          kpiFrameworkNotesText: row.kpiFrameworkNotesText ?? "",
        });
        // Same "never-saved (null) falls back to the generic default, a
        // deliberately-cleared value (saved as "") stays blank" pattern as
        // the fields above — now proposal-level rather than per-package.
        setDeliverables({
          monthlyDeliverablesText: row.monthlyDeliverablesText ?? defaultMonthlyDeliverablesText(),
          oneTimeDeliverablesText: row.oneTimeDeliverablesText ?? defaultOneTimeDeliverablesText(),
        });
        // Unlike every other field above, a never-saved nextStepsText (null —
        // this proposal predates the field, or was built before this
        // consultant ever touched it) falls back to the same generic default
        // shown on New Proposal, rather than blank — it describes a
        // universal process, not this client's data. A proposal where the
        // consultant deliberately cleared it (saved as "") stays blank, which
        // omits the section, exactly as they left it.
        setNextStepsText(row.nextStepsText ?? defaultNextStepsText());
        // Executive Summary / Challenges & Opportunities / 90-Day Roadmap:
        // use this proposal's own saved values if it ever saved any (even a
        // deliberately-blank one — every proposal built through the current
        // New Proposal flow always saves real values for the 4 required
        // summary fields, so "row.summaryCurrentSituationText != null" is a
        // reliable signal that this proposal has its own saved set). An
        // older proposal from before these columns existed has them all
        // null and gets seeded fresh from the report snapshot instead, once
        // it loads below.
        if (row.summaryCurrentSituationText != null) {
          setSummary({
            currentSituationText: row.summaryCurrentSituationText ?? "",
            opportunityText: row.summaryOpportunityText ?? "",
            recommendedDirectionText: row.summaryRecommendedDirectionText ?? "",
            approachText: row.summaryApproachText ?? "",
          });
        }
        if (row.challengesTopProblemsText != null || row.challengesCompetitorInsightsText != null) {
          setChallenges({
            topProblemsText: row.challengesTopProblemsText ?? "",
            competitorInsightsText: row.challengesCompetitorInsightsText ?? "",
          });
        }
        if (row.roadmapPhasesJson) {
          try {
            setRoadmapPhases(JSON.parse(row.roadmapPhasesJson) as ProposalRoadmapPhase[]);
          } catch {
            /* fall through to the report-seeded default below */
          }
        }
        if (row.reportSnapshotId) {
          api
            .get<{ reportData: string | null }>(`/api/reports/${row.reportSnapshotId}`)
            .then((snap) => {
              if (!snap.reportData) return;
              const parsed = JSON.parse(snap.reportData) as ReportData;
              setReportDefaults(parsed.consultant);
              // Only seed from the report when this proposal never saved its
              // own values — never overwrites a saved (possibly edited or
              // deliberately blanked) value already applied above.
              if (row.summaryCurrentSituationText == null) {
                setSummary({
                  currentSituationText: parsed.executiveSummary.currentSituation ?? "",
                  opportunityText: parsed.executiveSummary.biggestOpportunity ?? "",
                  recommendedDirectionText: parsed.executiveSummary.recommendedDirection ?? "",
                  approachText: parsed.problemSolutionStory?.strategy ?? "",
                });
              }
              if (row.challengesTopProblemsText == null && row.challengesCompetitorInsightsText == null) {
                setChallenges({
                  topProblemsText: (parsed.websiteRecommendations?.topProblems ?? []).join("\n"),
                  competitorInsightsText: (parsed.competitorInsights ?? []).join("\n"),
                });
              }
              if (!row.roadmapPhasesJson) {
                setRoadmapPhases((parsed.growthPlan ?? []).map((p) => ({ title: p.phase, itemsText: p.items.join("\n") })));
              }
            })
            .catch(() => {}); // defaults are just placeholder text/seeding — fine to skip if unavailable
        }
        return api.get<ProposalRow[]>(`/api/proposals?leadId=${row.leadId}`);
      })
      .then((allForLead) => {
        const maxVersion = Math.max(0, ...allForLead.map((p) => p.version));
        setNextVersion(maxVersion + 1);
      })
      .catch((e) => setLoadError((e as Error).message));
  }, [proposalId]);

  useEffect(() => {
    return () => {
      if (pdfUrl) URL.revokeObjectURL(pdfUrl);
    };
  }, [pdfUrl]);

  // Settings' Service Packages config, for the package cards' Services
  // Included checklist and "Load a preset" picker — falls back to the
  // starter template if the consultant hasn't configured their own yet.
  useEffect(() => {
    api
      .get<{ servicePackagesJson: string | null }>("/api/settings")
      .then((s) => {
        if (!s.servicePackagesJson) return;
        try {
          setServicePackages(JSON.parse(s.servicePackagesJson));
        } catch {
          /* keep the starter template if saved JSON is somehow invalid */
        }
      })
      .catch(() => {}); // purely a builder convenience — fine to skip if unavailable
  }, []);

  function updatePackage(i: number, patch: Partial<ProposalPackage>) {
    setPackages((prev) => prev.map((p, j) => (j === i ? { ...p, ...patch } : p)));
  }

  function markRecommended(i: number) {
    setPackages((prev) => prev.map((p, j) => ({ ...p, recommended: j === i })));
  }

  function downloadPdf() {
    if (!pdfUrl) return;
    const a = document.createElement("a");
    a.href = pdfUrl;
    a.download = pdfFilename || "proposal.pdf";
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  async function save() {
    setSaving(true);
    setSaveError(null);
    try {
      const res = await fetch(`/api/proposals/${proposalId}/edit`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          packages,
          termsText,
          validUntil: validUntil || null,
          consultantOverride,
          revisionPolicyText: policy.revisionPolicyText || null,
          clientResponsibilitiesText: policy.clientResponsibilitiesText || null,
          notIncludedText: policy.notIncludedText || null,
          pointOfContactText: policy.pointOfContactText || null,
          requirementsText: strategy.requirementsText || null,
          strategyAttractText: strategy.strategyAttractText || null,
          strategyEngageText: strategy.strategyEngageText || null,
          strategyConvertText: strategy.strategyConvertText || null,
          strategyRetainText: strategy.strategyRetainText || null,
          toolsResourcePlanText: scope.toolsResourcePlanText || null,
          kpiFrameworkNotesText: scope.kpiFrameworkNotesText || null,
          monthlyDeliverablesText: deliverables.monthlyDeliverablesText || null,
          oneTimeDeliverablesText: deliverables.oneTimeDeliverablesText || null,
          nextStepsText: nextStepsText || null,
          summaryCurrentSituationText: summary.currentSituationText,
          summaryOpportunityText: summary.opportunityText,
          summaryRecommendedDirectionText: summary.recommendedDirectionText,
          summaryApproachText: summary.approachText,
          challengesTopProblemsText: challenges.topProblemsText || null,
          challengesCompetitorInsightsText: challenges.competitorInsightsText || null,
          roadmapPhases,
        }),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => null);
        throw new Error(body?.error || "Save failed.");
      }
      const version = res.headers.get("X-Proposal-Version");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      setPdfUrl(url);
      setPdfFilename(`${leadDetail?.lead.businessName || "proposal"}-proposal-v${version ?? ""}.pdf`);
      setSavedVersion(version ? Number(version) : null);
    } catch (e) {
      setSaveError((e as Error).message);
    } finally {
      setSaving(false);
    }
  }

  if (loadError && (!leadDetail || !source)) {
    return (
      <div>
        <PageHeading title="Edit Proposal" />
        <Card className="p-5">
          <p className="text-sm text-red-600">{loadError}</p>
        </Card>
      </div>
    );
  }

  if (!leadDetail || !source || nextVersion === null) {
    return (
      <div className="flex justify-center py-20">
        <Spinner />
      </div>
    );
  }

  return (
    <div>
      <PageHeading
        title={`Edit Proposal v${source.version}`}
        subtitle={`${leadDetail.lead.businessName} · ${leadDetail.lead.customerName} · saving creates a new version (v${nextVersion}) — v${source.version} stays exactly as sent`}
        action={
          <LinkButton href={`/leads/${leadId}`} variant="secondary" size="sm">
            ← Back to Lead
          </LinkButton>
        }
      />

      {savedVersion ? (
        <Card className="p-4 mb-4 border-emerald-300 dark:border-emerald-700">
          <p className="text-sm text-emerald-600 font-medium mb-3">
            Proposal v{savedVersion} saved — ready to download and send to the client.
          </p>
          <div className="flex flex-wrap gap-2">
            <Button onClick={downloadPdf}>
              <Download size={16} /> Download Proposal v{savedVersion}
            </Button>
            <LinkButton href="/proposals" variant="secondary">
              Go to Proposals
            </LinkButton>
          </div>
        </Card>
      ) : null}

      <ProposalPackagesGrid
        packages={packages}
        onUpdate={updatePackage}
        onMarkRecommended={markRecommended}
        servicePackages={servicePackages}
      />

      <ProposalConsultantCard
        override={consultantOverride}
        defaults={reportDefaults}
        onChange={(patch) => setConsultantOverride((prev) => ({ ...prev, ...patch }))}
      />

      <ProposalSummaryCard value={summary} onChange={(patch) => setSummary((prev) => ({ ...prev, ...patch }))} />

      <ProposalChallengesCard value={challenges} onChange={(patch) => setChallenges((prev) => ({ ...prev, ...patch }))} />

      <ProposalStrategyCard value={strategy} onChange={(patch) => setStrategy((prev) => ({ ...prev, ...patch }))} />

      <ProposalRoadmapCard phases={roadmapPhases} onChange={setRoadmapPhases} />

      <ProposalScopeCard value={scope} onChange={(patch) => setScope((prev) => ({ ...prev, ...patch }))} />

      <ProposalDeliverablesCard
        value={deliverables}
        onChange={(patch) => setDeliverables((prev) => ({ ...prev, ...patch }))}
      />

      <ProposalNextStepsCard value={nextStepsText} onChange={setNextStepsText} />

      <ProposalTermsCard validUntil={validUntil} onValidUntilChange={setValidUntil} termsText={termsText} onTermsTextChange={setTermsText} />

      <ProposalPolicyCard value={policy} onChange={(patch) => setPolicy((prev) => ({ ...prev, ...patch }))} />

      {saveError && <p className="text-sm text-red-600 mb-3">{saveError}</p>}
      <div className="flex justify-end">
        <Button onClick={save} disabled={saving || packages.every((p) => !p.price)}>
          {saving ? "Saving…" : `Save as v${nextVersion}`}
        </Button>
      </div>
      {packages.every((p) => !p.price) && (
        <p className="text-xs text-amber-600 text-right mt-2">Set a price on at least one package to save.</p>
      )}
    </div>
  );
}
