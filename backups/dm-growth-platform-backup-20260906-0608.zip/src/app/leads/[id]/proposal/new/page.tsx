"use client";

import { useEffect, useMemo, useState } from "react";
import { useParams } from "next/navigation";
import { api } from "@/lib/api-client";
import { PageHeading, Card, Field, Select, Button, LinkButton, Spinner } from "@/components/ui";
import {
  ProposalPackagesGrid,
  ProposalTermsCard,
  ProposalConsultantCard,
  type ConsultantOverrideValue,
  ProposalPolicyCard,
  type ProposalPolicyValue,
  defaultRevisionPolicyText,
  defaultClientResponsibilitiesText,
  defaultNotIncludedText,
  ProposalStrategyCard,
  type ProposalStrategyValue,
  defaultRequirementsText,
  defaultStrategyAttractText,
  defaultStrategyEngageText,
  defaultStrategyConvertText,
  defaultStrategyRetainText,
  ProposalScopeCard,
  type ProposalScopeValue,
  defaultToolsResourcePlanText,
  ProposalNextStepsCard,
  defaultNextStepsText,
  ProposalSummaryCard,
  type ProposalSummaryValue,
  ProposalChallengesCard,
  type ProposalChallengesValue,
  ProposalRoadmapCard,
  type ProposalRoadmapPhase,
  ProposalDeliverablesCard,
  type ProposalDeliverablesValue,
  defaultMonthlyDeliverablesText,
  defaultOneTimeDeliverablesText,
  defaultDiscountTiersText,
} from "@/components/ProposalBuilderFields";
import type { ReportData } from "@/lib/pdf/types";
import { DEFAULT_SERVICE_PACKAGES, type ProposalPackage, type ServicePackagesConfig } from "@/lib/pdf/proposal-types";
import { Download } from "lucide-react";

interface ReportRow {
  id: string;
  version: number;
  createdAt: string;
  hasReportData: boolean;
}

interface LeadDetail {
  lead: { id: string; businessName: string; customerName: string; quoteValue?: number | null };
  reports: ReportRow[];
}

const TIER_ORDER = ["conservative", "expected", "growth opportunity"];

function defaultTermsText() {
  return [
    "Validity: this proposal is valid for 30 days from the date above.",
    "Payment terms: 50% advance to begin work, balance due monthly in advance for the selected plan.",
    "What's included: campaign setup, ongoing management and optimization, and a monthly performance report.",
    "Ad spend is billed separately, directly to the ad platform (Google/Meta/etc.) at cost — not included in the management fee above.",
    "Either party may cancel with 30 days' written notice.",
  ].join("\n");
}

export default function NewProposalPage() {
  const params = useParams();
  const leadId = params.id as string;

  const [leadDetail, setLeadDetail] = useState<LeadDetail | null>(null);
  const [selectedReportId, setSelectedReportId] = useState<string>("");
  const [reportData, setReportData] = useState<ReportData | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [packages, setPackages] = useState<ProposalPackage[]>([]);
  const [termsText, setTermsText] = useState(defaultTermsText());
  const [consultantOverride, setConsultantOverride] = useState<ConsultantOverrideValue>({});
  // Requirements/Strategy/Tools & Resource Plan/the 3 whole-engagement policy
  // fields all start pre-filled with a generic, editable default rather than
  // blank — otherwise these sections silently vanish from the generated PDF
  // whenever the consultant hasn't typed anything into them yet, which is
  // exactly what a real generated proposal was found to do (Digital Growth
  // Strategy, Tools & Resource Plan, Deliverables, Project Fee Discounts and
  // 3 of the 4 Policies subsections were all missing). Same "pre-filled but
  // freely editable/clearable" pattern already used for Terms and Next Steps.
  const [policy, setPolicy] = useState<ProposalPolicyValue>({
    revisionPolicyText: defaultRevisionPolicyText(),
    clientResponsibilitiesText: defaultClientResponsibilitiesText(),
    notIncludedText: defaultNotIncludedText(),
    pointOfContactText: "",
  });
  const [strategy, setStrategy] = useState<ProposalStrategyValue>({
    requirementsText: defaultRequirementsText(),
    strategyAttractText: defaultStrategyAttractText(),
    strategyEngageText: defaultStrategyEngageText(),
    strategyConvertText: defaultStrategyConvertText(),
    strategyRetainText: defaultStrategyRetainText(),
  });
  const [scope, setScope] = useState<ProposalScopeValue>({
    toolsResourcePlanText: defaultToolsResourcePlanText(),
    kpiFrameworkNotesText: "",
  });
  // Deliverables (Monthly/One-Time) — ONE shared field pair for the whole
  // proposal, not per package (see ProposalDeliverablesCard's own comment).
  // Same pre-filled-but-editable default pattern as the fields above.
  const [deliverables, setDeliverables] = useState<ProposalDeliverablesValue>({
    monthlyDeliverablesText: defaultMonthlyDeliverablesText(),
    oneTimeDeliverablesText: defaultOneTimeDeliverablesText(),
  });
  const [nextStepsText, setNextStepsText] = useState(defaultNextStepsText());
  // Executive Summary / Challenges & Opportunities / 90-Day Roadmap — used to
  // be computed live from the report; now seeded from it (below, whenever a
  // report version is selected) into their own editable proposal state, per
  // "each subsection want editable".
  const [summary, setSummary] = useState<ProposalSummaryValue>({
    currentSituationText: "",
    opportunityText: "",
    recommendedDirectionText: "",
    approachText: "",
  });
  const [challenges, setChallenges] = useState<ProposalChallengesValue>({
    topProblemsText: "",
    competitorInsightsText: "",
  });
  const [roadmapPhases, setRoadmapPhases] = useState<ProposalRoadmapPhase[]>([]);
  const [servicePackages, setServicePackages] = useState<ServicePackagesConfig>(DEFAULT_SERVICE_PACKAGES);
  const [validUntil, setValidUntil] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 30);
    return d.toISOString().slice(0, 10);
  });

  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const [pdfFilename, setPdfFilename] = useState("");
  const [savedVersion, setSavedVersion] = useState<number | null>(null);

  const editableReports = useMemo(
    () => (leadDetail?.reports ?? []).filter((r) => r.hasReportData).sort((a, b) => b.version - a.version),
    [leadDetail]
  );

  useEffect(() => {
    api
      .get<LeadDetail>(`/api/leads/${leadId}`)
      .then((d) => {
        setLeadDetail(d);
        const editable = (d.reports ?? []).filter((r) => r.hasReportData).sort((a, b) => b.version - a.version);
        if (editable.length > 0) setSelectedReportId(editable[0].id);
      })
      .catch((e) => setLoadError((e as Error).message));
  }, [leadId]);

  useEffect(() => {
    if (!selectedReportId) return;
    setReportData(null);
    api
      .get<{ reportData: string | null }>(`/api/reports/${selectedReportId}`)
      .then((row) => {
        if (!row.reportData) return;
        const parsed = JSON.parse(row.reportData) as ReportData;
        setReportData(parsed);
        const ordered = [...parsed.scenarios].sort((a, b) => {
          const ai = TIER_ORDER.indexOf(a.label.toLowerCase());
          const bi = TIER_ORDER.indexOf(b.label.toLowerCase());
          return (ai === -1 ? 99 : ai) - (bi === -1 ? 99 : bi);
        });
        setPackages(
          ordered.map((sc) => ({
            key: sc.label.toLowerCase().replace(/\s+/g, "-"),
            label: sc.label,
            description: "",
            price: 0,
            currency: parsed.consultant.currency,
            scenarioLabel: sc.label,
            customers: sc.customers,
            revenue: sc.revenue,
            roi: sc.roi,
            trafficPerMonth: sc.traffic,
            leadsPerMonth: sc.leads,
            cpl: sc.cpl,
            cac: sc.cac,
            roas: sc.roas,
            recommended: sc.label.toLowerCase().includes("expected"),
            // Pre-filled generic default, same "always show every section"
            // reasoning as the proposal-level fields below — otherwise the
            // Project Fee Discounts sub-section silently disappears until
            // the consultant types something in. (Deliverables used to be
            // seeded here too, per package — moved to the shared
            // `deliverables` state below; see ProposalDeliverablesCard.)
            discountTiersText: defaultDiscountTiersText(),
          }))
        );
        // Seed Executive Summary / Challenges & Opportunities / 90-Day
        // Roadmap from this report version's own data — real text/phases
        // only, nothing invented — then the consultant can freely rewrite
        // any of it below before generating.
        setSummary({
          currentSituationText: parsed.executiveSummary.currentSituation ?? "",
          opportunityText: parsed.executiveSummary.biggestOpportunity ?? "",
          recommendedDirectionText: parsed.executiveSummary.recommendedDirection ?? "",
          approachText: parsed.problemSolutionStory?.strategy ?? "",
        });
        setChallenges({
          topProblemsText: (parsed.websiteRecommendations?.topProblems ?? []).join("\n"),
          competitorInsightsText: (parsed.competitorInsights ?? []).join("\n"),
        });
        setRoadmapPhases((parsed.growthPlan ?? []).map((p) => ({ title: p.phase, itemsText: p.items.join("\n") })));
      })
      .catch((e) => setLoadError((e as Error).message));
  }, [selectedReportId]);

  useEffect(() => {
    return () => {
      if (pdfUrl) URL.revokeObjectURL(pdfUrl);
    };
  }, [pdfUrl]);

  // Settings' Service Packages config, for the package cards' Services
  // Included checklist and "Load a preset" picker — falls back to the
  // starter template if the consultant hasn't configured their own yet.
  useEffect(() => {
    api
      .get<{ servicePackagesJson: string | null }>("/api/settings")
      .then((s) => {
        if (!s.servicePackagesJson) return;
        try {
          setServicePackages(JSON.parse(s.servicePackagesJson));
        } catch {
          /* keep the starter template if saved JSON is somehow invalid */
        }
      })
      .catch(() => {}); // purely a builder convenience — fine to skip if unavailable
  }, []);

  function updatePackage(i: number, patch: Partial<ProposalPackage>) {
    setPackages((prev) => prev.map((p, j) => (j === i ? { ...p, ...patch } : p)));
  }

  function markRecommended(i: number) {
    setPackages((prev) => prev.map((p, j) => ({ ...p, recommended: j === i })));
  }

  function downloadPdf() {
    if (!pdfUrl) return;
    const a = document.createElement("a");
    a.href = pdfUrl;
    a.download = pdfFilename || "proposal.pdf";
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  async function generate() {
    if (!reportData || !selectedReportId) return;
    setSaving(true);
    setSaveError(null);
    try {
      const res = await fetch("/api/proposals", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          leadId,
          reportSnapshotId: selectedReportId,
          packages,
          termsText,
          validUntil: validUntil || null,
          consultantOverride,
          revisionPolicyText: policy.revisionPolicyText || null,
          clientResponsibilitiesText: policy.clientResponsibilitiesText || null,
          notIncludedText: policy.notIncludedText || null,
          pointOfContactText: policy.pointOfContactText || null,
          requirementsText: strategy.requirementsText || null,
          strategyAttractText: strategy.strategyAttractText || null,
          strategyEngageText: strategy.strategyEngageText || null,
          strategyConvertText: strategy.strategyConvertText || null,
          strategyRetainText: strategy.strategyRetainText || null,
          toolsResourcePlanText: scope.toolsResourcePlanText || null,
          kpiFrameworkNotesText: scope.kpiFrameworkNotesText || null,
          monthlyDeliverablesText: deliverables.monthlyDeliverablesText || null,
          oneTimeDeliverablesText: deliverables.oneTimeDeliverablesText || null,
          nextStepsText: nextStepsText || null,
          summaryCurrentSituationText: summary.currentSituationText,
          summaryOpportunityText: summary.opportunityText,
          summaryRecommendedDirectionText: summary.recommendedDirectionText,
          summaryApproachText: summary.approachText,
          challengesTopProblemsText: challenges.topProblemsText || null,
          challengesCompetitorInsightsText: challenges.competitorInsightsText || null,
          roadmapPhases,
        }),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => null);
        throw new Error(body?.error || "Generation failed.");
      }
      const version = res.headers.get("X-Proposal-Version");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      setPdfUrl(url);
      setPdfFilename(`${reportData.business.businessName || "proposal"}-proposal-v${version ?? ""}.pdf`);
      setSavedVersion(version ? Number(version) : null);
    } catch (e) {
      setSaveError((e as Error).message);
    } finally {
      setSaving(false);
    }
  }

  if (loadError && !leadDetail) {
    return (
      <div>
        <PageHeading title="Generate Proposal" />
        <Card className="p-5">
          <p className="text-sm text-red-600">{loadError}</p>
        </Card>
      </div>
    );
  }

  if (!leadDetail) {
    return (
      <div className="flex justify-center py-20">
        <Spinner />
      </div>
    );
  }

  if (editableReports.length === 0) {
    return (
      <div>
        <PageHeading title="Generate Proposal" subtitle={leadDetail.lead.businessName} />
        <Card className="p-5">
          <p className="text-sm text-amber-600">
            No editable report versions found for this lead yet. Generate a report first (Run Assessment → Save & Generate), then come back here to
            turn it into a priced proposal.
          </p>
          <LinkButton href={`/leads/${leadId}`} variant="secondary" className="mt-4">
            ← Back to Lead
          </LinkButton>
        </Card>
      </div>
    );
  }

  return (
    <div>
      <PageHeading
        title="Generate Proposal"
        subtitle={`${leadDetail.lead.businessName} · ${leadDetail.lead.customerName} · priced packages sent to the client for sign-off`}
        action={
          <LinkButton href={`/leads/${leadId}`} variant="secondary" size="sm">
            ← Back to Lead
          </LinkButton>
        }
      />

      {savedVersion ? (
        <Card className="p-4 mb-4 border-emerald-300 dark:border-emerald-700">
          <p className="text-sm text-emerald-600 font-medium mb-3">
            Proposal v{savedVersion} generated — ready to download and send to the client.
          </p>
          <div className="flex flex-wrap gap-2">
            <Button onClick={downloadPdf}>
              <Download size={16} /> Download Proposal v{savedVersion}
            </Button>
            <LinkButton href={`/leads/${leadId}`} variant="secondary">
              Go to Lead
            </LinkButton>
          </div>
        </Card>
      ) : null}

      <Card className="p-5 mb-4">
        <Field label="Based on report version" hint="Packages below are seeded from this version's scenarios — pick a different version to reseed them.">
          <Select value={selectedReportId} onChange={(e) => setSelectedReportId(e.target.value)} className="max-w-xs">
            {editableReports.map((r) => (
              <option key={r.id} value={r.id}>
                v{r.version} — {new Date(r.createdAt).toLocaleDateString()}
              </option>
            ))}
          </Select>
        </Field>
      </Card>

      {!reportData ? (
        <div className="flex justify-center py-10">
          <Spinner />
        </div>
      ) : (
        <>
          <ProposalPackagesGrid
            packages={packages}
            onUpdate={updatePackage}
            onMarkRecommended={markRecommended}
            servicePackages={servicePackages}
          />

          <ProposalConsultantCard
            override={consultantOverride}
            defaults={reportData.consultant}
            onChange={(patch) => setConsultantOverride((prev) => ({ ...prev, ...patch }))}
          />

          <ProposalSummaryCard value={summary} onChange={(patch) => setSummary((prev) => ({ ...prev, ...patch }))} />

          <ProposalChallengesCard value={challenges} onChange={(patch) => setChallenges((prev) => ({ ...prev, ...patch }))} />

          <ProposalStrategyCard value={strategy} onChange={(patch) => setStrategy((prev) => ({ ...prev, ...patch }))} />

          <ProposalRoadmapCard phases={roadmapPhases} onChange={setRoadmapPhases} />

          <ProposalScopeCard value={scope} onChange={(patch) => setScope((prev) => ({ ...prev, ...patch }))} />

          <ProposalDeliverablesCard
            value={deliverables}
            onChange={(patch) => setDeliverables((prev) => ({ ...prev, ...patch }))}
          />

          <ProposalNextStepsCard value={nextStepsText} onChange={setNextStepsText} />

          <ProposalTermsCard
            validUntil={validUntil}
            onValidUntilChange={setValidUntil}
            termsText={termsText}
            onTermsTextChange={setTermsText}
          />

          <ProposalPolicyCard value={policy} onChange={(patch) => setPolicy((prev) => ({ ...prev, ...patch }))} />

          {saveError && <p className="text-sm text-red-600 mb-3">{saveError}</p>}
          <div className="flex justify-end">
            <Button onClick={generate} disabled={saving || packages.every((p) => !p.price)}>
              {saving ? "Generating…" : "Generate Proposal PDF"}
            </Button>
          </div>
          {packages.every((p) => !p.price) && (
            <p className="text-xs text-amber-600 text-right mt-2">Set a price on at least one package to generate the proposal.</p>
          )}
        </>
      )}
    </div>
  );
}
