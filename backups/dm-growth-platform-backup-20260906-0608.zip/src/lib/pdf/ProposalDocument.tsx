import { Document, Page, Text, View, StyleSheet, Svg, Circle, Path, Image } from "@react-pdf/renderer";
import type { ProposalData } from "./proposal-types";
import { formatCurrency, formatNumber } from "@/lib/calculations";

const COLORS = {
  ink: "#111827",
  sub: "#4b5563",
  faint: "#9ca3af",
  brand: "#4f46e5",
  brandSoft: "#eef2ff",
  line: "#e5e7eb",
  good: "#059669",
  goodSoft: "#ecfdf5",
  slateSoft: "#f1f5f9",
};

const s = StyleSheet.create({
  page: { padding: 40, fontSize: 10, color: COLORS.ink, fontFamily: "Helvetica" },
  headerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 16 },
  brandTitle: { fontSize: 10, color: COLORS.brand, fontFamily: "Helvetica-Bold" },
  pageTitle: { fontSize: 20, fontFamily: "Helvetica-Bold", marginBottom: 4 },
  pageSubtitle: { fontSize: 10, color: COLORS.sub, marginBottom: 16 },
  sectionLabel: { fontSize: 12, fontFamily: "Helvetica-Bold", marginTop: 16, marginBottom: 8, color: COLORS.brand },
  bodyText: { fontSize: 10, color: COLORS.ink, lineHeight: 1.5 },
  calloutCard: { borderRadius: 6, padding: 10, marginBottom: 8 },
  calloutLabel: { fontSize: 9, fontFamily: "Helvetica-Bold", marginBottom: 3 },
  footer: { position: "absolute", bottom: 24, left: 40, right: 40, fontSize: 8, color: COLORS.faint, flexDirection: "row", justifyContent: "space-between" },
  packagesRow: { flexDirection: "row" },
  packageCard: { flex: 1, borderWidth: 1, borderColor: COLORS.line, borderRadius: 10, marginRight: 10, overflow: "hidden" },
  packageCardLast: { marginRight: 0 },
  packageCardRecommended: { borderColor: COLORS.brand, borderWidth: 2 },
  packageRibbon: { backgroundColor: COLORS.brand, paddingVertical: 3, alignItems: "center" },
  packageRibbonText: { fontSize: 7.5, fontFamily: "Helvetica-Bold", color: "#fff" },
  packageHead: { padding: 12, borderBottomWidth: 1, borderBottomColor: COLORS.line },
  packageLabel: { fontSize: 12, fontFamily: "Helvetica-Bold", marginBottom: 6 },
  packagePrice: { fontSize: 20, fontFamily: "Helvetica-Bold", color: COLORS.brand },
  packagePriceSub: { fontSize: 7, color: COLORS.sub, marginTop: 1 },
  packageBody: { padding: 12 },
  packageDesc: { fontSize: 8.5, color: COLORS.sub, lineHeight: 1.4, marginBottom: 8 },
  statRow: { flexDirection: "row", flexWrap: "wrap" },
  statItem: { width: "50%", marginBottom: 8 },
  statLabel: { fontSize: 6.5, color: COLORS.sub },
  statValue: { fontSize: 10.5, fontFamily: "Helvetica-Bold" },
  termsBlock: { borderWidth: 1, borderColor: COLORS.line, borderRadius: 8, padding: 14, marginBottom: 16 },
  termsText: { fontSize: 9.5, lineHeight: 1.6, color: COLORS.ink },
  acceptRow: { flexDirection: "row", marginTop: 30 },
  acceptCol: { flex: 1, marginRight: 20 },
  acceptColLast: { marginRight: 0 },
  acceptLine: { borderBottomWidth: 1, borderBottomColor: COLORS.ink, height: 30 },
  acceptLabel: { fontSize: 8, color: COLORS.sub, marginTop: 4 },

  // Cover page (page 1) — a dedicated title/prepared-for-and-by page, the
  // same structure Deevita's and NaryonTech's real client proposals both
  // use, rather than cramming the offer straight under the header.
  coverBody: { flex: 1, justifyContent: "center" },
  coverEyebrow: { fontSize: 10, color: COLORS.brand, fontFamily: "Helvetica-Bold", marginBottom: 10, letterSpacing: 1 },
  coverTitle: { fontSize: 26, fontFamily: "Helvetica-Bold", marginBottom: 6, maxWidth: 430 },
  coverSubtitle: { fontSize: 12, color: COLORS.sub, marginBottom: 36 },
  coverBlock: { marginBottom: 20 },
  coverBlockLabel: { fontSize: 8, color: COLORS.faint, marginBottom: 3, letterSpacing: 0.5 },
  coverBlockName: { fontSize: 12, fontFamily: "Helvetica-Bold", marginBottom: 2 },
  coverBlockSub: { fontSize: 9.5, color: COLORS.sub, marginBottom: 1 },
  coverMeta: { fontSize: 8, color: COLORS.faint, marginTop: 20 },

  // Itemized service-cost breakup, auto-detected from a package's own
  // description text (see parseServiceBreakup below) — never shown unless
  // the consultant actually typed it that way, so nothing here is invented.
  checkboxRow: { flexDirection: "row", marginBottom: 8 },
  checkboxWrap: { flexDirection: "row", alignItems: "center", marginRight: 12 },
  checkboxBoxOn: { width: 9, height: 9, borderRadius: 2, borderWidth: 1.2, borderColor: COLORS.brand, backgroundColor: COLORS.brand, alignItems: "center", justifyContent: "center", marginRight: 4 },
  checkboxBoxOff: { width: 9, height: 9, borderRadius: 2, borderWidth: 1.2, borderColor: COLORS.faint, backgroundColor: "#fff", marginRight: 4 },
  checkboxLabelOn: { fontSize: 6.5, fontFamily: "Helvetica-Bold", color: COLORS.ink },
  checkboxLabelOff: { fontSize: 6.5, color: COLORS.faint },
  breakupTable: { borderWidth: 1, borderColor: COLORS.line, borderRadius: 6, overflow: "hidden", marginBottom: 4 },
  breakupRow: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 5, paddingHorizontal: 8, borderBottomWidth: 1, borderBottomColor: COLORS.line, backgroundColor: "#fff" },
  breakupRowAlt: { backgroundColor: COLORS.slateSoft },
  breakupRowLast: { borderBottomWidth: 0 },
  breakupLabel: { fontSize: 8, color: COLORS.ink, flex: 1, paddingRight: 6 },
  breakupAmount: { fontSize: 8, fontFamily: "Helvetica-Bold", color: COLORS.ink },
  breakupCaption: { fontSize: 6.5, color: COLORS.faint, marginBottom: 8 },

  // Approval block on the final page — this document is what a client signs
  // to close the deal, so it gets its own labeled section rather than just
  // a signature line at the bottom of "Terms".
  approvalLineRow: { flexDirection: "row", alignItems: "flex-end", marginBottom: 14 },
  approvalLineLabel: { fontSize: 9, color: COLORS.sub, marginRight: 4 },
  approvalLineFill: { flex: 1, borderBottomWidth: 1, borderBottomColor: COLORS.line, height: 14 },
  authNote: { fontSize: 9.5, color: COLORS.ink, lineHeight: 1.5, marginBottom: 6 },

  // Per-package itemized deliverables table ("Item / Details"), and a
  // generic bullet list used both inside a package card (when its
  // deliverables/discount text doesn't parse into a table) and for the
  // whole-engagement policy sections on page 3 — all optional, all free
  // text the consultant typed, never invented. See parseDeliverables /
  // parseDiscountTiers / BulletList below.
  deliverablesTable: { borderWidth: 1, borderColor: COLORS.line, borderRadius: 6, overflow: "hidden", marginTop: 8, marginBottom: 4 },
  deliverablesRow: { flexDirection: "row", paddingVertical: 5, paddingHorizontal: 8, borderBottomWidth: 1, borderBottomColor: COLORS.line, backgroundColor: "#fff" },
  deliverablesRowAlt: { backgroundColor: COLORS.slateSoft },
  deliverablesRowLast: { borderBottomWidth: 0 },
  deliverablesLabel: { fontSize: 7.5, fontFamily: "Helvetica-Bold", color: COLORS.ink, width: "38%", paddingRight: 6 },
  deliverablesDetail: { fontSize: 7.5, color: COLORS.sub, flex: 1, lineHeight: 1.3 },
  miniSectionLabel: { fontSize: 7, fontFamily: "Helvetica-Bold", color: COLORS.ink, marginTop: 8, marginBottom: 3, textTransform: "uppercase", letterSpacing: 0.3 },
  discountLine: { fontSize: 7.5, color: COLORS.sub, marginBottom: 2 },
  bulletRow: { flexDirection: "row", marginBottom: 4, paddingRight: 4 },
  bulletDot: { width: 3, height: 3, borderRadius: 1.5, backgroundColor: COLORS.sub, marginTop: 5, marginRight: 6 },
  bulletText: { fontSize: 9, color: COLORS.ink, lineHeight: 1.5, flex: 1 },
  pointOfContact: { fontSize: 9.5, color: COLORS.ink, lineHeight: 1.5 },

  // Executive Summary page ("What We Understand" / "What We Recommend") —
  // reuses the same callout-card treatment already established for the
  // Opportunity/Approach cards, just with two extra plain-prose blocks.
  execBlock: { marginBottom: 16 },
  execBlockLabel: { fontSize: 11, fontFamily: "Helvetica-Bold", color: COLORS.ink, marginBottom: 6 },
  subSectionLabel: { fontSize: 9.5, fontFamily: "Helvetica-Bold", color: COLORS.sub, marginTop: 12, marginBottom: 6, textTransform: "uppercase", letterSpacing: 0.4 },

  // Digital Growth Strategy page — Attract/Engage/Convert/Retain rendered as
  // a 2x2 grid of stage cards, each an optional bullet list the consultant
  // typed; a stage with nothing typed is simply skipped (see the per-card
  // conditional in the component below), never padded with invented copy.
  strategyGrid: { flexDirection: "row", flexWrap: "wrap" },
  strategyCard: { width: "48%", marginRight: "4%", marginBottom: 16, borderWidth: 1, borderColor: COLORS.line, borderRadius: 8, padding: 12 },
  strategyCardEven: { marginRight: 0 },
  strategyStageLabel: { fontSize: 10.5, fontFamily: "Helvetica-Bold", color: COLORS.brand, marginBottom: 8, textTransform: "uppercase", letterSpacing: 0.5 },

  // 90-Day Growth Roadmap page — reuses the report's own growthPlan phases
  // (see build-proposal-data.ts), rendered as sequential cards. "MONTH N" is
  // just an honest sequence marker for whatever phase comes Nth — it never
  // asserts a specific calendar duration the underlying phase data doesn't
  // itself specify.
  roadmapCard: { borderWidth: 1, borderColor: COLORS.line, borderRadius: 8, padding: 12, marginBottom: 12 },
  roadmapMonthTag: { fontSize: 7, fontFamily: "Helvetica-Bold", color: COLORS.brand, marginBottom: 3, textTransform: "uppercase", letterSpacing: 0.5 },
  roadmapPhaseTitle: { fontSize: 12, fontFamily: "Helvetica-Bold", marginBottom: 6 },

  // Small "services included" chip row on a package card (Recommended
  // Services & Scope page) — a compact, scannable summary of which services
  // from the consultant's own Settings-configured list this package
  // includes. This page is scope-only (no price) — pricing/discounts moved
  // to the dedicated Commercial Terms page below.
  serviceChipsRow: { flexDirection: "row", flexWrap: "wrap", marginTop: 6, marginBottom: 2 },
  serviceChip: { fontSize: 6.5, fontFamily: "Helvetica-Bold", color: COLORS.brand, backgroundColor: COLORS.brandSoft, borderRadius: 8, paddingVertical: 2, paddingHorizontal: 6, marginRight: 4, marginBottom: 4 },
  scopeCard: { flex: 1, borderWidth: 1, borderColor: COLORS.line, borderRadius: 10, marginRight: 10, overflow: "hidden" },
  scopeCardLast: { marginRight: 0 },
  scopeCardRecommended: { borderColor: COLORS.brand, borderWidth: 2 },
  scopeHead: { padding: 12, borderBottomWidth: 1, borderBottomColor: COLORS.line },
  scopeBody: { padding: 12 },

  // Tools & Resource Plan page — a single proposal-wide optional section
  // (platforms/tools/team required), not per-package, since the tooling
  // and resourcing behind an engagement doesn't usually vary tier-to-tier.
  toolsBlock: { marginBottom: 8 },

  // KPI & Measurement Framework page — per-package stat grid reusing the
  // same Traffic/Leads/CPL/CAC/ROAS figures the report's own scenario
  // already computed (see ReportGrowthPlanItem/ReportData scenarios in
  // types.ts), carried onto the package at build time and fully editable
  // from there — never invented, always traceable back to the report.
  kpiCard: { flex: 1, borderWidth: 1, borderColor: COLORS.line, borderRadius: 10, marginRight: 10, padding: 12 },
  kpiCardLast: { marginRight: 0 },
  kpiCardLabel: { fontSize: 11, fontFamily: "Helvetica-Bold", marginBottom: 8 },
  kpiStatRow: { flexDirection: "row", flexWrap: "wrap" },
  kpiStatItem: { width: "50%", marginBottom: 8 },

  // Deliverables page — Monthly / One-Time tables per package, reusing the
  // same Item/Details table styling as everywhere else deliverables render.
  deliverablesPkgBlock: { marginBottom: 14 },
  deliverablesPkgLabel: { fontSize: 11, fontFamily: "Helvetica-Bold", marginBottom: 4 },

  // Commercial Terms page — compact pricing cards (name/price/recommended)
  // and Project Fee Discounts (reusing the existing per-package
  // discount-tier math), all pure rendering of numbers the consultant
  // already entered. (No Investment summary table — not part of the
  // consultant's specified Commercial Terms sub-sections.)
  commercialCard: { flex: 1, borderWidth: 1, borderColor: COLORS.line, borderRadius: 10, marginRight: 10, overflow: "hidden" },
  commercialCardLast: { marginRight: 0 },
  commercialCardRecommended: { borderColor: COLORS.brand, borderWidth: 2 },

  // Next Steps page — closing section: the generic process description,
  // Communication line, the existing confirm-instructions/Approval/
  // signature block and closing CTA all live here now (moved off the old
  // combined "Terms & Approval" page, which is now Policies & Terms only).
  nextStepsBlock: { marginBottom: 8 },
});

// Small check-mark badge, drawn as an SVG path rather than a Unicode glyph —
// react-pdf's built-in Helvetica font is WinAnsi/CP1252-only, so a text "✓"
// character silently renders as a garbled glyph (the same bug class fixed
// throughout ReportDocument.tsx — see its comments for the full history).
function CheckBadge({ color = COLORS.brand, size = 16 }: { color?: string; size?: number }) {
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: color, alignItems: "center", justifyContent: "center" }}>
      <Svg width={size * 0.6} height={size * 0.6} viewBox="0 0 24 24">
        <Path d="M4 12 L10 18 L20 6" stroke="#fff" strokeWidth={3.5} fill="none" strokeLinecap="round" strokeLinejoin="round" />
      </Svg>
    </View>
  );
}

// A tiny printed checkbox — same "draw it, don't type it" reasoning as
// CheckBadge above (no reliable Unicode ☑/☐ in WinAnsi). Used to show, per
// package, which pricing mode is active: an itemized cost breakup, or a
// single total project cost. This is a static indicator baked into the PDF
// output, not an interactive control — nothing in the app's UI changes.
function Checkbox({ checked, label }: { checked: boolean; label: string }) {
  return (
    <View style={s.checkboxWrap}>
      <View style={checked ? s.checkboxBoxOn : s.checkboxBoxOff}>
        {checked ? (
          <Svg width={6} height={6} viewBox="0 0 24 24">
            <Path d="M4 12 L10 18 L20 6" stroke="#fff" strokeWidth={5} fill="none" strokeLinecap="round" strokeLinejoin="round" />
          </Svg>
        ) : null}
      </View>
      <Text style={checked ? s.checkboxLabelOn : s.checkboxLabelOff}>{label}</Text>
    </View>
  );
}

interface BreakupItem {
  label: string;
  amount: number;
}

// Detects a per-service cost breakup living INSIDE a package's own
// "Description" text — e.g. a consultant typing:
//   SEO: ₹15,000
//   Social Media Management: ₹10,000
//   Content & Creatives: ₹8,000
// — so the PDF can render a real "digital marketing services" line-item
// table instead of one paragraph, built only from numbers the consultant
// already entered in the existing package editor. Nothing here is a new
// field or a new screen: the Description textarea has always been free
// text; this only changes how the PDF reads it.
//
// Deliberately strict, and fails safe: every comma/semicolon/newline chunk
// of the description must match "Label: amount" for this to activate. A
// normal prose description ("SEO, social media and content, all in one
// plan focused on measurable growth.") won't match and simply falls back
// to the plain paragraph, exactly as the PDF has always rendered it — so
// this can never mis-parse ordinary text into fabricated numbers.
const BREAKUP_LINE_PATTERN =
  /^([A-Za-z][A-Za-z0-9 /&()'+.-]{1,45}?)\s*[:\-–]\s*(?:₹|Rs\.?|INR|USD|AED|SAR|GBP|EUR|\$)?\s*([\d][\d,]*(?:\.\d{1,2})?)\s*(?:\/\s*mo(?:nth)?)?\.?$/i;

function parseServiceBreakup(description: string | undefined | null): BreakupItem[] | null {
  if (!description) return null;
  const chunks = description
    .split(/[\n,;]+/)
    .map((c) => c.trim())
    .filter(Boolean);
  if (chunks.length < 2) return null;

  const items: BreakupItem[] = [];
  for (const chunk of chunks) {
    const m = chunk.match(BREAKUP_LINE_PATTERN);
    if (!m) return null; // any one non-matching chunk means this isn't a breakup — bail entirely, show it as prose instead
    items.push({ label: m[1].trim(), amount: Number(m[2].replace(/,/g, "")) });
  }
  return items;
}

interface DeliverableItem {
  label: string;
  detail: string;
}

// Detects an "Item: Details" deliverables table inside a package's own
// dedicated Deliverables field — e.g. a consultant typing:
//   Blog / Case Study Publishing: 4 posts/month — formatting, on-page SEO, CMS upload
//   Image Formatting & Creating: 4 images/month — web + social-ready variants
// One pair per line (not comma-split like parseServiceBreakup, since a
// deliverable's own details routinely contain commas). Requires EVERY
// non-blank line to contain a label/detail split — a single line with no
// colon means this isn't structured that way, so the caller falls back to
// showing the raw text as a plain bullet list instead (nothing the
// consultant typed is ever dropped, and nothing is fabricated either way).
function parseDeliverables(text: string | undefined | null): DeliverableItem[] | null {
  if (!text) return null;
  const lines = text
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean);
  if (lines.length === 0) return null;

  const items: DeliverableItem[] = [];
  for (const line of lines) {
    const idx = line.indexOf(":");
    if (idx <= 0 || idx === line.length - 1) return null; // no "label:" prefix, or nothing after it
    const label = line.slice(0, idx).trim();
    const detail = line.slice(idx + 1).trim();
    if (!label || !detail) return null;
    items.push({ label, detail });
  }
  return items;
}

interface DiscountTier {
  months: number;
  percent: number;
  discountedAmount: number;
}

// Detects upfront-commitment discount tiers inside a package's own
// dedicated Discount Tiers field — one "N months: X%" line per tier (e.g.
// "3 months: 5%"). The discounted monthly amount shown is computed here
// from the package's own real price and the consultant's own entered
// percentage (price * (1 - percent/100)) — plain arithmetic on numbers the
// consultant already entered, not a fabricated figure. Requires every
// non-blank line to match the strict pattern; any line that doesn't means
// this isn't structured that way, so the caller falls back to the raw text
// as a plain bullet list instead of computing anything from malformed input.
const DISCOUNT_TIER_PATTERN = /^(\d+)\s*months?\s*:\s*(\d+(?:\.\d+)?)\s*%$/i;

function parseDiscountTiers(text: string | undefined | null, price: number): DiscountTier[] | null {
  if (!text) return null;
  const lines = text
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean);
  if (lines.length === 0) return null;

  const tiers: DiscountTier[] = [];
  for (const line of lines) {
    const m = line.match(DISCOUNT_TIER_PATTERN);
    if (!m) return null;
    const months = Number(m[1]);
    const percent = Number(m[2]);
    tiers.push({ months, percent, discountedAmount: Math.round(price * (1 - percent / 100)) });
  }
  return tiers;
}

// Generic bullet list for free text the consultant typed — one bullet per
// non-blank line. Used both as the fallback rendering for a package's
// Deliverables/Discount Tiers fields when they don't parse into a table,
// and for the whole-engagement policy sections (Revision Policy, Client
// Responsibilities, Not Included) on page 3. The dot is a small drawn
// square, not a typed bullet character — same "draw it, don't type it"
// reasoning as Checkbox/CheckBadge above.
function BulletList({ text, dotColor }: { text: string; dotColor?: string }) {
  const lines = text
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean);
  if (lines.length === 0) return null;
  return (
    <View>
      {lines.map((line, i) => (
        <View key={i} style={s.bulletRow}>
          <View style={[s.bulletDot, dotColor ? { backgroundColor: dotColor } : undefined]} />
          <Text style={s.bulletText}>{line}</Text>
        </View>
      ))}
    </View>
  );
}

function Header({ consultant }: { consultant: ProposalData["consultant"] }) {
  return (
    <View style={s.headerRow} fixed>
      <View style={{ flexDirection: "row", alignItems: "center" }}>
        {consultant.logoUrl && (
          // eslint-disable-next-line jsx-a11y/alt-text -- this is @react-pdf/renderer's Image, not an HTML <img>
          <Image src={consultant.logoUrl} style={{ width: 20, height: 20, marginRight: 6, objectFit: "contain" }} />
        )}
        <Text style={s.brandTitle}>{consultant.companyName}</Text>
      </View>
      <Text style={{ fontSize: 8, color: COLORS.faint }}>{consultant.consultantName}</Text>
    </View>
  );
}

// Page numbers are computed by react-pdf itself via the `render` prop
// (pageNumber/totalPages reflect the ACTUAL rendered page count), rather
// than a hardcoded constant — this document is normally 3 pages, but
// substantial optional content (long policy text, many deliverables) can
// legitimately push it to 4+ pages, and a hardcoded "Page X of 3" would
// then be wrong on every overflow page.
function Footer({ consultant }: { consultant: ProposalData["consultant"] }) {
  return (
    <View style={s.footer} fixed>
      <Text>
        {consultant.companyName} · {consultant.website || consultant.email || ""}
      </Text>
      <Text render={({ pageNumber, totalPages }) => `Page ${pageNumber} of ${totalPages}`} />
    </View>
  );
}

export function ProposalDocument({ data }: { data: ProposalData }) {
  const {
    consultant,
    business,
    summaryCurrentSituationText,
    summaryOpportunityText,
    summaryRecommendedDirectionText,
    summaryApproachText,
    challengesTopProblemsText,
    challengesCompetitorInsightsText,
    roadmapPhases,
    packages,
    monthlyDeliverablesText,
    oneTimeDeliverablesText,
    termsText,
    revisionPolicyText,
    clientResponsibilitiesText,
    notIncludedText,
    pointOfContactText,
    requirementsText,
    strategyAttractText,
    strategyEngageText,
    strategyConvertText,
    strategyRetainText,
    toolsResourcePlanText,
    kpiFrameworkNotesText,
    nextStepsText,
    validUntil,
    generatedDate,
    version,
  } = data;

  const hasExecutiveSummary =
    !!summaryCurrentSituationText || !!summaryOpportunityText || !!summaryRecommendedDirectionText || !!summaryApproachText;
  const hasRequirementsOrChallenges = !!requirementsText || !!challengesTopProblemsText || !!challengesCompetitorInsightsText;
  const strategyStages: Array<{ label: string; text: string | null | undefined }> = [
    { label: "Attract", text: strategyAttractText },
    { label: "Engage", text: strategyEngageText },
    { label: "Convert", text: strategyConvertText },
    { label: "Retain", text: strategyRetainText },
  ];
  const hasStrategy = strategyStages.some((stage) => !!stage.text);
  const hasKpiData = packages.some(
    (p) => p.trafficPerMonth != null || p.leadsPerMonth != null || p.cpl != null || p.cac != null || p.roas != null
  );
  const hasKpiSection = hasKpiData || !!kpiFrameworkNotesText;
  const hasDeliverables = !!monthlyDeliverablesText || !!oneTimeDeliverablesText;
  const hasDiscountTiers = packages.some((p) => !!p.discountTiersText);

  return (
    <Document title={`${business.businessName} — Growth Proposal v${version}`} author={consultant.companyName}>
      {/* PAGE 1 — COVER */}
      <Page size="A4" style={s.page}>
        <Header consultant={consultant} />
        <View style={s.coverBody}>
          <Text style={s.coverEyebrow}>GROWTH PROPOSAL</Text>
          <Text style={s.coverTitle}>{business.businessName}</Text>
          <Text style={s.coverSubtitle}>Digital Marketing Growth Engagement</Text>

          <View style={s.coverBlock}>
            <Text style={s.coverBlockLabel}>PREPARED FOR</Text>
            <Text style={s.coverBlockName}>{business.customerName}</Text>
            <Text style={s.coverBlockSub}>{business.businessName}</Text>
          </View>

          <View style={s.coverBlock}>
            <Text style={s.coverBlockLabel}>PREPARED BY</Text>
            <Text style={s.coverBlockName}>{consultant.consultantName}</Text>
            <Text style={s.coverBlockSub}>{consultant.companyName}</Text>
            {consultant.email ? <Text style={s.coverBlockSub}>{consultant.email}</Text> : null}
            {consultant.phone ? <Text style={s.coverBlockSub}>{consultant.phone}</Text> : null}
            {consultant.whatsapp ? <Text style={s.coverBlockSub}>WhatsApp: {consultant.whatsapp}</Text> : null}
          </View>

          <Text style={s.coverMeta}>
            Prepared on {generatedDate}
            {validUntil ? ` · Valid until ${validUntil}` : ""} · v{version}
          </Text>
        </View>
        <Footer consultant={consultant} />
      </Page>

      {/* PAGE — EXECUTIVE SUMMARY (each block independently editable/omittable
          on the proposal — see the summary*Text fields on ProposalData). */}
      {hasExecutiveSummary ? (
        <Page size="A4" style={s.page}>
          <Header consultant={consultant} />
          <Text style={s.pageTitle}>Executive Summary</Text>
          <Text style={s.pageSubtitle}>
            Prepared for {business.customerName} · {business.businessName} · {generatedDate}
            {validUntil ? ` · Valid until ${validUntil}` : ""}
          </Text>

          {summaryCurrentSituationText ? (
            <View style={s.execBlock}>
              <Text style={s.execBlockLabel}>What We Understand</Text>
              <Text style={s.bodyText}>{summaryCurrentSituationText}</Text>
            </View>
          ) : null}

          {summaryOpportunityText ? (
            <View style={[s.calloutCard, { backgroundColor: COLORS.goodSoft }]}>
              <Text style={[s.calloutLabel, { color: COLORS.good }]}>The Opportunity</Text>
              <Text style={s.bodyText}>{summaryOpportunityText}</Text>
            </View>
          ) : null}

          {summaryRecommendedDirectionText ? (
            <View style={s.execBlock}>
              <Text style={s.execBlockLabel}>What We Recommend</Text>
              <Text style={s.bodyText}>{summaryRecommendedDirectionText}</Text>
            </View>
          ) : null}

          {summaryApproachText ? (
            <View style={[s.calloutCard, { backgroundColor: COLORS.brandSoft }]}>
              <Text style={[s.calloutLabel, { color: COLORS.brand }]}>Our Approach</Text>
              <Text style={s.bodyText}>{summaryApproachText}</Text>
            </View>
          ) : null}

          <Footer consultant={consultant} />
        </Page>
      ) : null}

      {/* PAGE — REQUIREMENTS + CHALLENGES & OPPORTUNITIES (skipped entirely when there's nothing to show) */}
      {hasRequirementsOrChallenges ? (
        <Page size="A4" style={s.page}>
          <Header consultant={consultant} />
          <Text style={s.pageTitle}>Requirements &amp; Understanding</Text>
          <Text style={s.pageSubtitle}>{business.businessName}</Text>

          {requirementsText ? (
            <View wrap={false}>
              <Text style={s.sectionLabel}>Requirements</Text>
              <BulletList text={requirementsText} />
            </View>
          ) : null}

          {challengesTopProblemsText || challengesCompetitorInsightsText ? (
            <View wrap={false}>
              <Text style={s.sectionLabel}>Challenges &amp; Opportunities</Text>
              {challengesTopProblemsText ? (
                <>
                  <Text style={s.subSectionLabel}>What We Found</Text>
                  <BulletList text={challengesTopProblemsText} />
                </>
              ) : null}
              {challengesCompetitorInsightsText ? (
                <>
                  <Text style={s.subSectionLabel}>Competitive Landscape</Text>
                  <BulletList text={challengesCompetitorInsightsText} />
                </>
              ) : null}
            </View>
          ) : null}

          <Footer consultant={consultant} />
        </Page>
      ) : null}

      {/* PAGE — DIGITAL GROWTH STRATEGY (skipped entirely when no stage has been filled in) */}
      {hasStrategy ? (
        <Page size="A4" style={s.page}>
          <Header consultant={consultant} />
          <Text style={s.pageTitle}>Digital Growth Strategy</Text>
          {/* "->" not "→" — react-pdf's built-in Helvetica font is WinAnsi/CP1252
              only; a literal → arrow here renders as a garbled stray mark (see
              the same fix already applied in ReportDocument.tsx). */}
          <Text style={s.pageSubtitle}>Attract -&gt; Engage -&gt; Convert -&gt; Retain</Text>

          <View style={s.strategyGrid}>
            {strategyStages.map((stage, i) =>
              stage.text ? (
                <View key={stage.label} style={[s.strategyCard, i % 2 === 1 ? s.strategyCardEven : undefined]} wrap={false}>
                  <Text style={s.strategyStageLabel}>{stage.label}</Text>
                  <BulletList text={stage.text} />
                </View>
              ) : null
            )}
          </View>

          <Footer consultant={consultant} />
        </Page>
      ) : null}

      {/* PAGE — RECOMMENDED SERVICES & SCOPE (scope only — no pricing here;
          pricing/discounts moved to the dedicated Commercial Terms page
          under "Commercial Terms", per the full-flow section ordering). */}
      <Page size="A4" style={s.page}>
        <Header consultant={consultant} />
        <Text style={s.pageTitle}>Recommended Services &amp; Scope</Text>
        <Text style={s.pageSubtitle}>
          Prepared for {business.customerName} · {business.businessName} · {generatedDate}
        </Text>

        <Text style={s.sectionLabel}>Selected Services &amp; What&apos;s Included</Text>
        <View style={s.packagesRow}>
          {packages.map((pkg, i) => (
            <View
              key={pkg.key || i}
              style={[s.scopeCard, i === packages.length - 1 ? s.scopeCardLast : undefined, pkg.recommended ? s.scopeCardRecommended : undefined]}
            >
              {pkg.recommended ? (
                <View style={s.packageRibbon}>
                  <Text style={s.packageRibbonText}>RECOMMENDED</Text>
                </View>
              ) : null}
              <View style={s.scopeHead}>
                <Text style={s.packageLabel}>{pkg.label}</Text>
              </View>
              <View style={s.scopeBody}>
                {pkg.description ? <Text style={s.packageDesc}>{pkg.description}</Text> : null}
                {pkg.selectedServiceLabels && pkg.selectedServiceLabels.length > 0 ? (
                  <>
                    <Text style={s.miniSectionLabel}>Services Included</Text>
                    <View style={s.serviceChipsRow}>
                      {pkg.selectedServiceLabels.map((label, idx) => (
                        <Text key={idx} style={s.serviceChip}>
                          {label}
                        </Text>
                      ))}
                    </View>
                  </>
                ) : null}
              </View>
            </View>
          ))}
        </View>

        <Footer consultant={consultant} />
      </Page>

      {/* PAGE — TOOLS & RESOURCE PLAN (skipped entirely when blank) */}
      {toolsResourcePlanText ? (
        <Page size="A4" style={s.page}>
          <Header consultant={consultant} />
          <Text style={s.pageTitle}>Tools &amp; Resource Plan</Text>
          <Text style={s.pageSubtitle}>{business.businessName}</Text>
          <View style={s.toolsBlock}>
            <BulletList text={toolsResourcePlanText} />
          </View>
          <Footer consultant={consultant} />
        </Page>
      ) : null}

      {/* PAGE — 90-DAY GROWTH ROADMAP (skipped entirely when there are no
          phases — editable list, see roadmapPhases on ProposalData) */}
      {roadmapPhases.length > 0 ? (
        <Page size="A4" style={s.page}>
          <Header consultant={consultant} />
          <Text style={s.pageTitle}>90-Day Growth Roadmap</Text>
          <Text style={s.pageSubtitle}>{business.businessName}</Text>

          {roadmapPhases.map((phase, i) => (
            <View key={i} style={s.roadmapCard} wrap={false}>
              <Text style={s.roadmapMonthTag}>Month {i + 1}</Text>
              <Text style={s.roadmapPhaseTitle}>{phase.title}</Text>
              <BulletList text={phase.itemsText} />
            </View>
          ))}

          <Footer consultant={consultant} />
        </Page>
      ) : null}

      {/* PAGE — KPI & MEASUREMENT FRAMEWORK (skipped entirely when no package
          has any KPI figure and there's no framework note either) */}
      {hasKpiSection ? (
        <Page size="A4" style={s.page}>
          <Header consultant={consultant} />
          <Text style={s.pageTitle}>KPI &amp; Measurement Framework</Text>
          <Text style={s.pageSubtitle}>{business.businessName}</Text>

          {hasKpiData ? (
            <View style={s.packagesRow}>
              {packages.map((pkg, i) => (
                <View key={pkg.key || i} style={[s.kpiCard, i === packages.length - 1 ? s.kpiCardLast : undefined]}>
                  <Text style={s.kpiCardLabel}>{pkg.label}</Text>
                  <View style={s.kpiStatRow}>
                    {pkg.trafficPerMonth != null ? (
                      <View style={s.kpiStatItem}>
                        <Text style={s.statLabel}>Traffic/mo</Text>
                        <Text style={s.statValue}>{formatNumber(Math.round(pkg.trafficPerMonth))}</Text>
                      </View>
                    ) : null}
                    {pkg.leadsPerMonth != null ? (
                      <View style={s.kpiStatItem}>
                        <Text style={s.statLabel}>Leads/mo</Text>
                        <Text style={s.statValue}>{formatNumber(Math.round(pkg.leadsPerMonth))}</Text>
                      </View>
                    ) : null}
                    {pkg.cpl != null ? (
                      <View style={s.kpiStatItem}>
                        <Text style={s.statLabel}>CPL</Text>
                        <Text style={s.statValue}>{formatCurrency(pkg.cpl, pkg.currency)}</Text>
                      </View>
                    ) : null}
                    {pkg.cac != null ? (
                      <View style={s.kpiStatItem}>
                        <Text style={s.statLabel}>CAC</Text>
                        <Text style={s.statValue}>{formatCurrency(pkg.cac, pkg.currency)}</Text>
                      </View>
                    ) : null}
                    {pkg.roas != null ? (
                      <View style={s.kpiStatItem}>
                        <Text style={s.statLabel}>ROAS</Text>
                        <Text style={s.statValue}>{pkg.roas.toFixed(2)}x</Text>
                      </View>
                    ) : null}
                  </View>
                </View>
              ))}
            </View>
          ) : null}

          {hasKpiData ? (
            <Text style={{ fontSize: 7.5, color: COLORS.faint, marginTop: 10, marginBottom: 4 }}>
              Figures are scenario-based projections carried over from the growth report — see the full report for assumptions and methodology.
            </Text>
          ) : null}

          {kpiFrameworkNotesText ? (
            <View style={{ marginTop: hasKpiData ? 8 : 0 }} wrap={false}>
              <Text style={s.sectionLabel}>Measurement Framework</Text>
              <BulletList text={kpiFrameworkNotesText} />
            </View>
          ) : null}

          <Footer consultant={consultant} />
        </Page>
      ) : null}

      {/* PAGE — DELIVERABLES: Monthly / One-Time, ONE shared list for the
          whole engagement (not per package — every pricing tier gets the
          same scope of work; only price/services differ, and those are
          covered on the Services & Scope / Commercial Terms pages). Skipped
          entirely when both fields are blank. */}
      {hasDeliverables ? (
        <Page size="A4" style={s.page}>
          <Header consultant={consultant} />
          <Text style={s.pageTitle}>Deliverables</Text>
          <Text style={s.pageSubtitle}>{business.businessName}</Text>

          {monthlyDeliverablesText ? (
            <View wrap={false} style={s.deliverablesPkgBlock}>
              <Text style={s.miniSectionLabel}>Monthly Deliverable</Text>
              {(() => {
                const items = parseDeliverables(monthlyDeliverablesText);
                return items ? (
                  <View style={s.deliverablesTable}>
                    {items.map((item, idx) => (
                      <View
                        key={idx}
                        style={[s.deliverablesRow, idx % 2 === 1 ? s.deliverablesRowAlt : undefined, idx === items.length - 1 ? s.deliverablesRowLast : undefined]}
                      >
                        <Text style={s.deliverablesLabel}>{item.label}</Text>
                        <Text style={s.deliverablesDetail}>{item.detail}</Text>
                      </View>
                    ))}
                  </View>
                ) : (
                  <BulletList text={monthlyDeliverablesText} />
                );
              })()}
            </View>
          ) : null}
          {oneTimeDeliverablesText ? (
            <View wrap={false} style={s.deliverablesPkgBlock}>
              <Text style={s.miniSectionLabel}>One-Time / Project Deliverable</Text>
              {(() => {
                const items = parseDeliverables(oneTimeDeliverablesText);
                return items ? (
                  <View style={s.deliverablesTable}>
                    {items.map((item, idx) => (
                      <View
                        key={idx}
                        style={[s.deliverablesRow, idx % 2 === 1 ? s.deliverablesRowAlt : undefined, idx === items.length - 1 ? s.deliverablesRowLast : undefined]}
                      >
                        <Text style={s.deliverablesLabel}>{item.label}</Text>
                        <Text style={s.deliverablesDetail}>{item.detail}</Text>
                      </View>
                    ))}
                  </View>
                ) : (
                  <BulletList text={oneTimeDeliverablesText} />
                );
              })()}
            </View>
          ) : null}

          <Footer consultant={consultant} />
        </Page>
      ) : null}

      {/* PAGE — COMMERCIAL TERMS: pricing packages, Project Fee Discounts.
          Pricing (and the description-embedded cost breakup, when a
          package's Description is written that way) lives here rather than
          on Services & Scope, per the full-flow order. */}
      <Page size="A4" style={s.page}>
        <Header consultant={consultant} />
        <Text style={s.pageTitle}>Commercial Terms</Text>
        <Text style={s.pageSubtitle}>
          {business.businessName}
          {validUntil ? ` · Valid until ${validUntil}` : ""}
        </Text>

        <Text style={s.sectionLabel}>Pricing Packages</Text>
        <View style={s.packagesRow}>
          {packages.map((pkg, i) => {
            const breakup = parseServiceBreakup(pkg.description);
            return (
              <View
                key={pkg.key || i}
                style={[s.commercialCard, i === packages.length - 1 ? s.commercialCardLast : undefined, pkg.recommended ? s.commercialCardRecommended : undefined]}
              >
                {pkg.recommended ? (
                  <View style={s.packageRibbon}>
                    <Text style={s.packageRibbonText}>RECOMMENDED</Text>
                  </View>
                ) : null}
                <View style={s.packageHead}>
                  <Text style={s.packageLabel}>{pkg.label}</Text>
                  <Text style={s.packagePrice}>{formatCurrency(pkg.price, pkg.currency)}</Text>
                  <Text style={s.packagePriceSub}>{breakup ? "per month · itemized below" : "per month · total project cost"}</Text>
                </View>
                <View style={s.packageBody}>
                  <View style={s.checkboxRow}>
                    <Checkbox checked={!!breakup} label="Itemized Breakup" />
                    <Checkbox checked={!breakup} label="Total Project Cost" />
                  </View>
                  {breakup ? (
                    <>
                      <View style={s.breakupTable}>
                        {breakup.map((item, idx) => (
                          <View
                            key={idx}
                            style={[s.breakupRow, idx % 2 === 1 ? s.breakupRowAlt : undefined, idx === breakup.length - 1 ? s.breakupRowLast : undefined]}
                          >
                            <Text style={s.breakupLabel}>{item.label}</Text>
                            <Text style={s.breakupAmount}>{formatCurrency(item.amount, pkg.currency)}</Text>
                          </View>
                        ))}
                      </View>
                      <Text style={s.breakupCaption}>Itemized for reference — total investment shown above.</Text>
                    </>
                  ) : null}
                </View>
              </View>
            );
          })}
        </View>

        {hasDiscountTiers ? (
          <View wrap={false} style={{ marginTop: 8 }}>
            <Text style={s.sectionLabel}>Project Fee Discounts</Text>
            <View style={s.packagesRow}>
              {packages.map((pkg, i) =>
                pkg.discountTiersText ? (
                  <View key={pkg.key || i} style={[s.commercialCard, i === packages.length - 1 ? s.commercialCardLast : undefined, { padding: 12 }]}>
                    <Text style={[s.packageLabel, { fontSize: 10, marginBottom: 6 }]}>{pkg.label}</Text>
                    {(() => {
                      const tiers = parseDiscountTiers(pkg.discountTiersText, pkg.price);
                      return tiers ? (
                        tiers.map((tier, idx) => (
                          <Text key={idx} style={s.discountLine}>
                            {tier.months}-month upfront commitment: {tier.percent}% discount ({formatCurrency(tier.discountedAmount, pkg.currency)}/month)
                          </Text>
                        ))
                      ) : (
                        <BulletList text={pkg.discountTiersText} />
                      );
                    })()}
                  </View>
                ) : (
                  <View key={pkg.key || i} style={[s.commercialCard, i === packages.length - 1 ? s.commercialCardLast : undefined]} />
                )
              )}
            </View>
          </View>
        ) : null}

        <Footer consultant={consultant} />
      </Page>

      {/* PAGE — POLICIES & TERMS (Revision, Client Responsibilities, Not
          Included, Terms & conditions — this exact sub-order per the
          consultant's specified outline; no Approval/signature here, that
          now lives on the closing Next Steps page below). */}
      <Page size="A4" style={s.page}>
        <Header consultant={consultant} />
        <Text style={s.pageTitle}>Policies &amp; Terms</Text>
        <Text style={s.pageSubtitle}>{business.businessName}</Text>

        {revisionPolicyText ? (
          <View wrap={false}>
            <Text style={s.sectionLabel}>Revision Policy</Text>
            <BulletList text={revisionPolicyText} />
          </View>
        ) : null}

        {clientResponsibilitiesText ? (
          <View wrap={false}>
            <Text style={s.sectionLabel}>Client Responsibilities</Text>
            <BulletList text={clientResponsibilitiesText} />
          </View>
        ) : null}

        {notIncludedText ? (
          <View wrap={false}>
            <Text style={s.sectionLabel}>Not Included</Text>
            <BulletList text={notIncludedText} />
          </View>
        ) : null}

        <View wrap={false}>
          <Text style={s.sectionLabel}>Terms &amp; Conditions</Text>
          <View style={s.termsBlock}>
            <Text style={s.termsText}>{termsText}</Text>
          </View>
        </View>

        <Footer consultant={consultant} />
      </Page>

      {/* PAGE — NEXT STEPS (closing page: process description, how to reach
          us, confirm-instructions, the Approval/signature block, and the
          closing CTA — all moved here from the old combined "Terms &
          Approval" page). */}
      <Page size="A4" style={s.page}>
        <Header consultant={consultant} />
        <Text style={s.pageTitle}>Next Steps</Text>
        <Text style={s.pageSubtitle}>{business.businessName}{validUntil ? ` · Proposal valid until ${validUntil}` : ""}</Text>

        {nextStepsText ? (
          <View style={s.nextStepsBlock} wrap={false}>
            <BulletList text={nextStepsText} />
          </View>
        ) : null}

        {pointOfContactText ? (
          <View wrap={false}>
            <Text style={s.sectionLabel}>Communication</Text>
            <Text style={s.pointOfContact}>{pointOfContactText}</Text>
          </View>
        ) : null}

        <View style={{ flexDirection: "row", marginBottom: 16, marginTop: 8 }} wrap={false}>
          <CheckBadge />
          <Text style={{ marginLeft: 8, fontSize: 9.5, color: COLORS.ink, flex: 1 }}>
            Pick a plan from the Commercial Terms page and confirm by reply, call, or WhatsApp — work begins within 2 business days of a signed approval.
          </Text>
        </View>

        <Text style={s.sectionLabel}>Approval</Text>

        <View style={s.approvalLineRow}>
          <Text style={s.approvalLineLabel}>Selected Plan:</Text>
          <View style={s.approvalLineFill} />
        </View>

        <Text style={s.authNote}>
          By signing below, {business.customerName} authorizes {consultant.companyName} to proceed with the selected plan under the terms above.
        </Text>

        <View style={s.acceptRow}>
          <View style={s.acceptCol}>
            <View style={s.acceptLine} />
            <Text style={s.acceptLabel}>Client signature</Text>
          </View>
          <View style={[s.acceptCol, s.acceptColLast]}>
            <View style={s.acceptLine} />
            <Text style={s.acceptLabel}>Date</Text>
          </View>
        </View>

        <View style={{ marginTop: 40, alignItems: "center" }} wrap={false}>
          <Text style={{ fontSize: 14, fontFamily: "Helvetica-Bold", textAlign: "center", marginBottom: 12 }}>
            {consultant.ctaText}
          </Text>
          <Text style={{ fontSize: 10, fontFamily: "Helvetica-Bold" }}>{consultant.consultantName}</Text>
          <Text style={{ fontSize: 9, color: COLORS.sub }}>{consultant.companyName}</Text>
          {consultant.phone ? <Text style={{ fontSize: 9, color: COLORS.sub }}>{consultant.phone}</Text> : null}
          {consultant.whatsapp ? <Text style={{ fontSize: 9, color: COLORS.sub }}>WhatsApp: {consultant.whatsapp}</Text> : null}
          {consultant.email ? <Text style={{ fontSize: 9, color: COLORS.sub }}>{consultant.email}</Text> : null}
          {consultant.website ? <Text style={{ fontSize: 9, color: COLORS.sub }}>{consultant.website}</Text> : null}
        </View>

        <Footer consultant={consultant} />
      </Page>
    </Document>
  );
}
