import type { ReportConsultant } from "./types";

// One priced package on the Proposal PDF — normally seeded 1:1 from a report
// version's Conservative/Expected/Growth Opportunity scenarios (so the price
// sits next to the same projected customers/revenue/ROI the client already
// saw in the full report), but label/description/price are all
// consultant-editable before sending, and a package doesn't strictly need a
// backing scenario (a flat custom package is fine too).
export interface ProposalPackage {
  key: string;
  label: string;
  description?: string;
  price: number;
  currency: string;
  scenarioLabel?: string; // which report scenario this was seeded from, if any
  customers?: number | null;
  revenue?: number | null;
  roi?: number | null;
  recommended?: boolean;
  // NOTE: Monthly/One-Time Deliverables used to live here, one copy per
  // package — but the outline treats "Deliverables" (section 3) as a single
  // whole-engagement list, not one that varies by pricing tier, and having
  // it per-package meant the exact same text got typed 3 times (confirmed
  // from a real proposal's screenshots showing identical Monthly/One-Time
  // Deliverables text repeated across all 3 package cards). Moved to
  // `ProposalData.monthlyDeliverablesText`/`oneTimeDeliverablesText` (one
  // shared field for the whole proposal) below. Old saved proposals' package
  // JSON may still carry these two keys from before this change — harmless,
  // simply no longer read.
  // KPI & Measurement Framework numbers for this package — Traffic/Leads
  // per month, CPL, CAC, ROAS. Seeded from the same report scenario this
  // package was built from (every scenario already computes these exact
  // figures — see ReportData.scenarios in types.ts), but fully
  // consultant-editable afterward, same as price/customers/revenue/roi
  // above: real projected numbers by default, adjustable before sending.
  // Null/undefined for any one of these simply omits that stat, never a
  // fabricated placeholder.
  trafficPerMonth?: number | null;
  leadsPerMonth?: number | null;
  cpl?: number | null;
  cac?: number | null;
  roas?: number | null;
  // Optional upfront-commitment discount tiers for this package, one per
  // line as "N months: X%" (e.g. "3 months: 5%"). The discounted monthly
  // amount is computed from this package's own price — pure arithmetic on
  // consultant-entered numbers, never a fabricated figure. Omitted entirely
  // when blank.
  discountTiersText?: string | null;
  // Which individual services (from Settings' Service Packages master list,
  // see ServicePackagesConfig below) this package includes — set via the
  // "Services Included" checklist in the package editor. Stored as the
  // service KEYS at the time this package was built, so a proposal keeps
  // showing exactly what was selected even if the consultant later edits
  // the master service list or a tier's own definition in Settings. Purely
  // a builder convenience (drives the checklist UI and the tier-match
  // suggestion) — the actual PDF still only ever shows what's already in
  // `description`/`deliverablesText`, nothing new is rendered from this
  // field alone.
  selectedServiceKeys?: string[] | null;
  // Human-readable labels for the keys above, resolved and frozen at the
  // moment the package was built (not looked up again from Settings at PDF
  // render time) — same "snapshot, not a live reference" principle this app
  // uses for a report's consultant block. Rendered as a small chip row on
  // the Recommended Services & Scope page when present.
  selectedServiceLabels?: string[] | null;
}

export interface ProposalData {
  consultant: ReportConsultant;
  business: {
    businessName: string;
    customerName: string;
  };
  // Executive Summary ("What We Understand" / "The Opportunity" / "What We
  // Recommend" / "Our Approach") — seeded from the report snapshot's own
  // data (executiveSummary.currentSituation/biggestOpportunity/
  // recommendedDirection/problems, problemSolutionStory.strategy) when a
  // proposal is first built, then a fully editable, consultant-owned field
  // from that point on ("each subsection want editable" — no longer a live
  // pass-through of the report). Required (never fabricated blank) because
  // build-proposal-data.ts always falls back to the report's own non-empty
  // default text when nothing has been seeded yet; summaryProblemsText is
  // the one optional part (a bullet list that can be genuinely empty).
  summaryCurrentSituationText: string;
  summaryOpportunityText: string;
  summaryRecommendedDirectionText: string;
  summaryApproachText: string;
  summaryProblemsText?: string | null; // one bullet per line
  // "Challenges & Opportunities" section — demonstrates understanding of the
  // client's business using data the report already gathered (website audit
  // problems, competitor findings). Same seeded-then-editable pattern as
  // Executive Summary above; optional (omitted from the PDF when both blank).
  challengesTopProblemsText?: string | null; // one bullet per line
  challengesCompetitorInsightsText?: string | null; // one bullet per line
  // "90-Day Growth Roadmap" — phase title + bullet items per phase. Seeded
  // from the report's own growthPlan (real phase names/items only, never
  // invented) when a proposal is first built, then a fully editable list —
  // the consultant can rewrite any phase, add one, or remove one.
  roadmapPhases: { title: string; itemsText: string }[];
  packages: ProposalPackage[];
  // Deliverables (section 3 of the outline: 3.1 Monthly Deliverable / 3.2
  // One-Time Deliverable) — ONE shared list for the whole engagement, not
  // per pricing package (moved here from ProposalPackage; see the note on
  // that interface above). Each is optional itemized text, one "Item:
  // details" pair per line, rendered as its own real Item/Details table when
  // provided; omitted entirely when blank. Free text the consultant types —
  // never auto-generated. Shown pre-filled with a generic default in the
  // builder UI (same pattern as Next Steps/Terms) since it describes a
  // typical engagement's deliverables, not client-specific data.
  monthlyDeliverablesText?: string | null;
  oneTimeDeliverablesText?: string | null;
  termsText: string;
  // Whole-engagement policy sections, shared across every package rather
  // than repeated per-tier — each is optional free text, one bullet per
  // line, rendered only when non-empty. Never auto-generated.
  revisionPolicyText?: string | null;
  clientResponsibilitiesText?: string | null;
  notIncludedText?: string | null;
  pointOfContactText?: string | null;
  // Stage 1 additions — "Requirements" and the 4 "Digital Growth Strategy"
  // stages (Attract → Engage → Convert → Retain). Optional free text, one
  // bullet per line, omitted from the PDF entirely when blank. No existing
  // report field captures these, so — per the "reuse existing data where
  // possible, else a new field" rule this project has followed throughout —
  // these are new consultant-entered fields, same non-fabrication pattern
  // as the policy sections above (nothing pre-filled or invented).
  requirementsText?: string | null;
  strategyAttractText?: string | null;
  strategyEngageText?: string | null;
  strategyConvertText?: string | null;
  strategyRetainText?: string | null;
  // Remaining full-flow sections. "Tools & Resource Plan" (platforms, tools,
  // team/resources required) and an optional "KPI & Measurement Framework"
  // notes field sit under "Scope of the project"; "Next Steps" is the
  // document's closing section (Approval -> Kickoff -> Onboarding -> Access
  // -> Execution). All optional free text, one bullet per line, omitted
  // from the PDF entirely when blank — same non-fabrication pattern as
  // every other optional field above. Unlike the others, Next Steps is
  // shown pre-filled with a generic default in the builder UI (see
  // ProposalBuilderFields.tsx) since it describes a universal process, not
  // client-specific data — the consultant can edit or clear it freely.
  toolsResourcePlanText?: string | null;
  kpiFrameworkNotesText?: string | null;
  nextStepsText?: string | null;
  validUntil?: string | null;
  generatedDate: string;
  version: number;
}

// --- Recommended Services & Scope: reusable service-tier configuration ----
// Configured once in Settings (see ServicePackagesCard there), then read by
// every proposal's package editor. Lets the consultant define a master list
// of individual services (e.g. SEO, Social, Paid) and named pricing tiers
// (Foundation/Growth/Performance) built from combinations of those services,
// so building a proposal becomes "check the services this client needs" with
// a live suggestion of which configured tier matches, rather than retyping
// name/price/description from scratch every time. A tier's price/services
// here are just the current template — once a package is built from them,
// the package stores its own frozen copy (price, selectedServiceKeys), so
// editing a tier in Settings later never changes an already-sent proposal.
export interface ServiceOption {
  key: string;
  label: string;
}

export interface ServiceTierConfig {
  key: string;
  name: string;
  price: number;
  serviceKeys: string[];
  // For a tier that isn't just a list of services (e.g. "Small business /
  // focused execution") — shown instead of the auto-joined service labels
  // when applying this tier's preset. Optional; falls back to the joined
  // service list when blank.
  descriptionOverride?: string | null;
}

export interface ServicePackagesConfig {
  services: ServiceOption[];
  tiers: ServiceTierConfig[];
}

// Starter template shown the first time a consultant opens the new "Service
// Packages" Settings section, before they've saved their own configuration —
// exactly the 3 tiers/prices/descriptions given as an example, kept as an
// editable starting point rather than baked-in, uneditable business logic.
export const DEFAULT_SERVICE_PACKAGES: ServicePackagesConfig = {
  services: [
    { key: "seo", label: "SEO" },
    { key: "social", label: "Social" },
    { key: "paid", label: "Paid" },
    { key: "lead-generation", label: "Lead Generation" },
    { key: "strategy", label: "Strategy" },
    { key: "cro", label: "CRO" },
    { key: "crm", label: "CRM" },
    { key: "analytics", label: "Analytics" },
  ],
  tiers: [
    {
      key: "foundation",
      name: "Foundation",
      price: 30000,
      serviceKeys: [],
      descriptionOverride: "Small business / focused execution",
    },
    {
      key: "growth",
      name: "Growth",
      price: 50000,
      serviceKeys: ["seo", "social", "paid", "lead-generation"],
      descriptionOverride: null,
    },
    {
      key: "performance",
      name: "Performance",
      price: 65000,
      serviceKeys: ["strategy", "paid", "seo", "cro", "crm", "analytics"],
      descriptionOverride: null,
    },
  ],
};
