# Restore point — dm-growth-platform-backup-20260906-0608.zip

Taken: 2026-09-06 ~06:08 UTC (Asia/Calcutta ~11:38, 2026-09-06)
Source: E:\My Project\Dm Project\dm-growth-platform (live machine, via Claude's device bridge — not a shell snapshot)

## What this snapshot captures

Full application state as of this moment, including:

- **Source code**: `src/` (all routes, components, lib — including every fix logged in the project's build-summary doc through the 2026-09-06 "Deliverables moved from per-package to one shared section" fix), `public/`, `scripts/seed.ts`.
- **Root config**: `.env`, `.env.example`, `.gitignore`, `AGENTS.md`, `CLAUDE.md`, `drizzle.config.ts`, `eslint.config.mjs`, `HOW_TO_APPLY.md`, `next-env.d.ts`, `next.config.ts`, `package.json`, `package-lock.json`, `postcss.config.mjs`, `README.md`, `tsconfig.json`.
- **Live database**: `data/app.db` + its `-wal`/`-shm` files (SQLite, includes any pending WAL-only writes at snapshot time).
- **Benchmark seed data**: all 9 `data/benchmarks/*.json` files (Google, Meta, LinkedIn, YouTube, Instagram, Microsoft Ads, WhatsApp, Industry Benchmarks — 34 industries, plus benchmark metadata).
- **Generated PDFs on disk**: 8 report PDFs (`data/reports/*.pdf`) and 6 proposal PDFs (`data/proposals/*.pdf`).

**Not included** (deliberately, matching every prior backup in this project): `node_modules/` and `.next/` (regenerate with `npm install` and `npm run dev`/`npm run build`), the `backups/` folder itself (avoids nesting old zips inside new ones), and the `Claude outputs/` folder (delivery-only working files from prior sessions, not live app state — its content already exists inside `src/`).

## How to restore

### Full restore (replace everything)
1. Stop the dev server if it's running.
2. Unzip this archive somewhere temporary.
3. Copy every extracted file/folder over the corresponding path in your project root (`E:\My Project\Dm Project\dm-growth-platform`), overwriting what's there. This restores source, config, the database, benchmark data and generated PDFs to exactly this snapshot.
4. Run `npm install` (in case dependencies changed since this snapshot) and `npm run dev` (or `-- -p <port>` if you use a specific port).
5. On first request, the app's self-heal (`src/lib/db/index.ts`) will re-check schema/columns/tables/benchmark rows against the restored `app.db` — this is safe and a no-op if nothing's missing.

### Database-only restore (keep current code, roll back data)
1. Stop the dev server.
2. Replace `data/app.db`, `data/app.db-wal` and `data/app.db-shm` with the three files from this archive's `data/` folder.
3. Restart the dev server.

### Single-file restore
Extract just the one file you need from the archive (it mirrors the project's folder structure exactly — e.g. `src/lib/calculations.ts`) and copy it over the live file at the same relative path.

## Known state at this snapshot

- **Deliverables (2026-09-06)**: moved off each pricing package and onto the proposal as one shared section — the generated PDF now shows exactly one Monthly Deliverables table and one One-Time Deliverables table for the whole document, instead of one per package. Discount Tiers and the KPI & Measurement Framework numbers remain per-package (they genuinely vary by tier). A shared `ProposalDeliverablesCard` sits in the builder right after Scope of the Project. `proposals` gained 2 new nullable columns (`monthly_deliverables_text`, `one_time_deliverables_text`), auto-migrated via the existing self-healing `ensureSchemaColumns()`.
- **"Always show every section" (2026-09-05)**: every optional proposal section (Requirements, Digital Growth Strategy sub-sections, Tools & Resource Plan, per-package Deliverables at the time, Project Fee Discounts, and all 4 Policies & Terms sub-sections) is now pre-filled with generic, freely-editable default text instead of silently disappearing when blank. The duplicated website-audit-findings block was fixed by removing the "Key Problems" field from Executive Summary entirely (the audit findings now show exactly once, under Challenges & Opportunities).
- Proposal-flow restructure (2026-09-05): Executive Summary, Challenges & Opportunities, and the 90-Day Growth Roadmap are now editable in the proposal builder (previously computed live from the report snapshot with no edit capability) via `ProposalSummaryCard`, `ProposalChallengesCard`, `ProposalRoadmapCard`. The Investment table was removed from Commercial Terms (Pricing Packages + Project Fee Discounts only), matching the user's exact outline.
- Scenario tiers vary both CPC (±10%) and conversion rates across Conservative/Expected/Growth Opportunity (2026-09-03 fix).
- Self-heal is throttle-based (5s, request-triggered) — picks up code, schema, *and* pure-data-file changes automatically, no restart needed (2026-09-03 fix).
- 34 business verticals, full 8-channel benchmark coverage (including YouTube Ads), suggested-minimum-budget hints (with vertical-fallback for the 5 verticals whose usual channels lack lead-based benchmarks).
- Report/Proposal versioning, delete-with-confirmation for reports/proposals/leads, brand logo on PDFs, and the lead-billing feature (payments API + UI, including invoice/receipt generation) are all present in this snapshot's `src/`.
